// Script to help you get the actual price IDs from Stripe
// Run this to get your price IDs: node scripts/get-stripe-prices.js

const Stripe = require("stripe")

// Replace with your secret key
const stripe = new Stripe(
  "sk_test_51RXwLjRrbGbUFaw4MDYMoqHLl462VEln3gzif78xmex3uSEgaYAxWIpzS1ppT8Xd1pPp5yMJy9K2s1kYBJq2T5l9002nlkBizv",
  {
    apiVersion: "2024-06-20",
  },
)

async function getPriceIds() {
  try {
    console.log("Fetching prices from Stripe...\n")

    const prices = await stripe.prices.list({
      limit: 100,
      expand: ["data.product"],
    })

    const productIds = {
      starter: "prod_SSsFu4AsGI7SNy",
      pro: "prod_SSsCk4SnLK47w5",
      growth: "prod_SSsGm02p67BVi8",
    }

    console.log("Your Price IDs:")
    console.log("================")

    for (const [tier, productId] of Object.entries(productIds)) {
      const price = prices.data.find((p) => p.product.id === productId)
      if (price) {
        console.log(`${tier}: "${price.id}",`)
      } else {
        console.log(`${tier}: "No price found for product ${productId}",`)
      }
    }

    console.log("\nCopy these price IDs to your STRIPE_PRICES object in lib/stripe.ts")
  } catch (error) {
    console.error("Error fetching prices:", error.message)
  }
}

getPriceIds()
