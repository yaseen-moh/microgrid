"use client"

import React from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertTriangle, RefreshCw } from "lucide-react"

interface ErrorBoundaryState {
  hasError: boolean
  error?: Error
}

export class ErrorBoundary extends React.Component<React.PropsWithChildren<{}>, ErrorBoundaryState> {
  constructor(props: React.PropsWithChildren<{}>) {
    super(props)
    this.state = { hasError: false }
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error }
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    // Log error but don't break the app
    console.warn("Error caught by boundary:", error, errorInfo)

    // Filter out browser extension errors
    if (
      error.message.includes("Receiving end does not exist") ||
      error.message.includes("Extension context invalidated") ||
      error.message.includes("Could not establish connection")
    ) {
      // These are browser extension errors, ignore them
      this.setState({ hasError: false })
      return
    }
  }

  render() {
    if (this.state.hasError && this.state.error) {
      // Don't show error UI for browser extension errors
      if (
        this.state.error.message.includes("Receiving end does not exist") ||
        this.state.error.message.includes("Extension context invalidated") ||
        this.state.error.message.includes("Could not establish connection")
      ) {
        return this.props.children
      }

      return (
        <div className="min-h-screen flex items-center justify-center p-4">
          <Card className="max-w-md w-full">
            <CardHeader className="text-center">
              <div className="mx-auto w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mb-4">
                <AlertTriangle className="h-6 w-6 text-red-600" />
              </div>
              <CardTitle className="text-xl">Something went wrong</CardTitle>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <p className="text-gray-600">We encountered an unexpected error. Please try refreshing the page.</p>
              <Button onClick={() => window.location.reload()} className="w-full">
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh Page
              </Button>
            </CardContent>
          </Card>
        </div>
      )
    }

    return this.props.children
  }
}
