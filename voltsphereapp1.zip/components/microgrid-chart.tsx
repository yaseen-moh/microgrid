"use client"

import { useState } from "react"
import { Line, LineChart, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip } from "recharts"
import { Button } from "@/components/ui/button"
import { ChartContainer } from "@/components/ui/chart"
import { Sun, Battery, Zap, Activity, Eye, EyeOff } from "lucide-react"

interface MicrogridChartProps {
  data: any
  showSolar?: boolean
}

export function MicrogridChart({ data, showSolar = true }: MicrogridChartProps) {
  const [visibleLines, setVisibleLines] = useState({
    solar: showSolar,
    consumption: true,
    battery: true,
    grid: true,
  })

  if (!data || !data.data) {
    return (
      <div className="h-96 flex items-center justify-center text-gray-500">
        <p>No data available</p>
      </div>
    )
  }

  const toggleLine = (lineKey: keyof typeof visibleLines) => {
    setVisibleLines((prev) => ({
      ...prev,
      [lineKey]: !prev[lineKey],
    }))
  }

  const chartConfig = {
    solar: {
      label: "Solar Generation",
      color: "#f59e0b", // amber-500
    },
    consumption: {
      label: "Energy Consumption",
      color: "#ef4444", // red-500
    },
    battery: {
      label: "Battery Storage",
      color: "#10b981", // emerald-500
    },
    grid: {
      label: "Grid Usage",
      color: "#6366f1", // indigo-500
    },
  }

  const lineControls = [
    { key: "solar" as const, label: "Solar", icon: Sun, color: "bg-amber-500", show: showSolar },
    { key: "consumption" as const, label: "Consumption", icon: Activity, color: "bg-red-500", show: true },
    { key: "battery" as const, label: "Battery", icon: Battery, color: "bg-emerald-500", show: true },
    { key: "grid" as const, label: "Grid", icon: Zap, color: "bg-indigo-500", show: true },
  ]

  return (
    <div className="space-y-6">
      {/* Line Controls */}
      <div className="flex flex-wrap gap-3 justify-center">
        {lineControls.map(({ key, label, icon: Icon, color, show }) => {
          if (!show) return null

          const isVisible = visibleLines[key]
          return (
            <Button
              key={key}
              onClick={() => toggleLine(key)}
              variant={isVisible ? "default" : "outline"}
              className={`flex items-center gap-2 h-10 px-4 rounded-xl transition-all duration-200 ${
                isVisible ? `${color} text-white hover:opacity-90` : "hover:bg-gray-100"
              }`}
            >
              <Icon className="h-4 w-4" />
              <span className="font-medium">{label}</span>
              {isVisible ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
            </Button>
          )
        })}
      </div>

      {/* Chart */}
      <div className="w-full">
        <ChartContainer config={chartConfig} className="h-[400px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={data.data.slice(0, 24)}
              margin={{
                top: 20,
                right: 30,
                left: 20,
                bottom: 20,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" className="stroke-gray-200" opacity={0.5} />
              <XAxis
                dataKey="time"
                className="text-sm"
                tick={{ fontSize: 12, fill: "#6b7280" }}
                axisLine={{ stroke: "#d1d5db" }}
                tickLine={{ stroke: "#d1d5db" }}
              />
              <YAxis
                className="text-sm"
                tick={{ fontSize: 12, fill: "#6b7280" }}
                axisLine={{ stroke: "#d1d5db" }}
                tickLine={{ stroke: "#d1d5db" }}
                label={{
                  value: "Power (kW)",
                  angle: -90,
                  position: "insideLeft",
                  style: { textAnchor: "middle", fill: "#6b7280", fontSize: "12px" },
                }}
              />
              <Tooltip
                content={({ active, payload, label }) => {
                  if (!active || !payload || !payload.length) return null

                  return (
                    <div className="bg-white p-4 border border-gray-200 rounded-xl shadow-lg">
                      <p className="font-semibold text-gray-800 mb-2">{`Time: ${label}`}</p>
                      {payload.map((entry, index) => {
                        const lineKey = entry.dataKey as keyof typeof visibleLines
                        if (!visibleLines[lineKey]) return null

                        return (
                          <div key={index} className="flex items-center gap-2 text-sm">
                            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: entry.color }} />
                            <span className="text-gray-600">{entry.name}:</span>
                            <span className="font-semibold">{Number(entry.value).toFixed(2)} kW</span>
                          </div>
                        )
                      })}
                    </div>
                  )
                }}
              />

              {/* Conditional Lines */}
              {showSolar && visibleLines.solar && (
                <Line
                  type="monotone"
                  dataKey="solar"
                  stroke={chartConfig.solar.color}
                  strokeWidth={3}
                  dot={false}
                  name="Solar Generation"
                  connectNulls={false}
                />
              )}

              {visibleLines.consumption && (
                <Line
                  type="monotone"
                  dataKey="consumption"
                  stroke={chartConfig.consumption.color}
                  strokeWidth={3}
                  dot={false}
                  name="Energy Consumption"
                  connectNulls={false}
                />
              )}

              {visibleLines.battery && (
                <Line
                  type="monotone"
                  dataKey="battery"
                  stroke={chartConfig.battery.color}
                  strokeWidth={3}
                  dot={false}
                  name="Battery Storage"
                  connectNulls={false}
                />
              )}

              {visibleLines.grid && (
                <Line
                  type="monotone"
                  dataKey="grid"
                  stroke={chartConfig.grid.color}
                  strokeWidth={3}
                  dot={false}
                  name="Grid Usage"
                  connectNulls={false}
                />
              )}
            </LineChart>
          </ResponsiveContainer>
        </ChartContainer>
      </div>

      {/* Legend Info */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
        {lineControls.map(({ key, label, icon: Icon, color, show }) => {
          if (!show || !visibleLines[key]) return null

          return (
            <div key={key} className="flex flex-col items-center gap-2">
              <div className={`p-2 ${color} rounded-lg text-white`}>
                <Icon className="h-5 w-5" />
              </div>
              <div className="text-sm font-medium text-gray-700">{label}</div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
