"use client"

import { Line, LineChart, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Legend } from "recharts"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

interface ProChartProps {
  data: any
  config: any
}

export function ProChart({ data, config }: ProChartProps) {
  if (!data || !data.data) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle>Energy Flow Analysis</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-96 flex items-center justify-center text-gray-500">
            Run a simulation to see the energy flow chart
          </div>
        </CardContent>
      </Card>
    )
  }

  const chartConfig = {
    solar: {
      label: "Solar Generation",
      color: "hsl(var(--chart-1))",
    },
    consumption: {
      label: "Energy Consumption",
      color: "hsl(var(--chart-2))",
    },
    battery: {
      label: "Battery Storage",
      color: "hsl(var(--chart-3))",
    },
    grid: {
      label: "Grid Usage",
      color: "hsl(var(--chart-4))",
    },
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          Energy Flow Analysis
          {config.useRealWeather && (
            <span className="text-sm font-normal text-gray-500">({config.weatherLocation})</span>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig} className="h-96 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={data.data.slice(0, 24)}
              margin={{
                top: 5,
                right: 30,
                left: 20,
                bottom: 5,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis dataKey="time" className="text-xs" tick={{ fontSize: 12 }} />
              <YAxis
                className="text-xs"
                tick={{ fontSize: 12 }}
                label={{ value: "Power (kW)", angle: -90, position: "insideLeft" }}
              />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Legend />

              {config.solarEnabled && (
                <Line
                  type="monotone"
                  dataKey="solar"
                  stroke="var(--color-solar)"
                  strokeWidth={2}
                  dot={false}
                  name="Solar Generation"
                />
              )}

              <Line
                type="monotone"
                dataKey="consumption"
                stroke="var(--color-consumption)"
                strokeWidth={2}
                dot={false}
                name="Energy Consumption"
              />

              <Line
                type="monotone"
                dataKey="battery"
                stroke="var(--color-battery)"
                strokeWidth={2}
                dot={false}
                name="Battery Storage"
              />

              <Line
                type="monotone"
                dataKey="grid"
                stroke="var(--color-grid)"
                strokeWidth={2}
                dot={false}
                name="Grid Usage"
              />
            </LineChart>
          </ResponsiveContainer>
        </ChartContainer>
      </CardContent>
    </Card>
  )
}
