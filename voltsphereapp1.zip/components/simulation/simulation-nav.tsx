"use client"

import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { Card } from "@/components/ui/card"
import { Zap, Crown, Code, Building, Star, Globe } from "lucide-react"

interface SimulationNavProps {
  userTier: string
}

export function SimulationNav({ userTier }: SimulationNavProps) {
  // Function to check if a user has access to a specific tier
  const hasAccess = (requiredTier: string): boolean => {
    // Admin always has access to everything (treat as having bought all 4 simulations)
    if (userTier === "admin") return true

    // Tier hierarchy - each tier includes access to all lower tiers
    const tierHierarchy: { [key: string]: string[] } = {
      free: ["free"],
      pro: ["free", "pro"],
      starter: ["free", "pro", "starter"],
      growth: ["free", "pro", "starter", "growth"],
      enterprise: ["free", "pro", "starter", "growth", "enterprise"],
    }

    const userAccess = tierHierarchy[userTier] || ["free"]
    return userAccess.includes(requiredTier)
  }

  const simulations = [
    {
      id: "free",
      name: "Free Simulation",
      description: "Basic energy modeling",
      icon: <Zap className="h-5 w-5" />,
      href: "/simulation",
      badge: "Free",
      badgeColor: "gradient-success",
      requiredTier: "free",
      features: ["24h simulation", "Basic profiles", "2 battery types"],
    },
    {
      id: "pro",
      name: "Pro Simulation",
      description: "Advanced features & analytics",
      icon: <Star className="h-5 w-5" />,
      href: "/simulation/pro",
      badge: "Pro",
      badgeColor: "gradient-secondary",
      requiredTier: "pro",
      features: ["Multi-duration", "Weather data", "4 battery types", "Cost analysis"],
    },
    {
      id: "starter",
      name: "Starter API",
      description: "Basic API automation",
      icon: <Code className="h-5 w-5" />,
      href: "/simulation/starter",
      badge: "API",
      badgeColor: "gradient-primary",
      requiredTier: "starter",
      features: ["5K calls/month", "6 examples", "Basic automation", "Up to 100kWh"],
    },
    {
      id: "growth",
      name: "Growth API",
      description: "Advanced API features",
      icon: <Building className="h-5 w-5" />,
      href: "/simulation/growth",
      badge: "Growth",
      badgeColor: "gradient-warning",
      requiredTier: "growth",
      features: ["50K calls/month", "10 examples", "Multi-site", "Peak shaving"],
    },
    {
      id: "enterprise",
      name: "Enterprise Suite",
      description: "Industrial-scale modeling",
      icon: <Crown className="h-5 w-5" />,
      href: "/simulation/enterprise",
      badge: "Enterprise",
      badgeColor: "gradient-accent",
      requiredTier: "enterprise",
      features: ["Unlimited calls", "AI optimization", "Multi-MW", "5-year sims"],
    },
  ]

  return (
    <div className="w-full">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 lg:gap-8">
        {simulations.map((sim) => {
          const available = hasAccess(sim.requiredTier)

          return (
            <Card
              key={sim.id}
              className={`relative overflow-hidden transition-all duration-300 rounded-xl border-0 shadow-lg ${
                available
                  ? "bg-white hover:shadow-xl hover:scale-105 cursor-pointer"
                  : "bg-gray-50/80 opacity-60 cursor-not-allowed"
              }`}
            >
              <Link href={available ? sim.href : "/pricing"} className="block p-6 lg:p-8 h-full">
                {/* Header */}
                <div className="flex items-center justify-between mb-6">
                  <div className={`p-3 lg:p-4 rounded-xl ${available ? "bg-gray-100" : "bg-gray-200"}`}>
                    <div className={available ? "text-gray-700" : "text-gray-400"}>{sim.icon}</div>
                  </div>
                  <Badge
                    className={`${sim.badgeColor} text-white text-xs font-semibold px-3 py-1 rounded-xl shadow-sm`}
                  >
                    {sim.badge}
                  </Badge>
                </div>

                {/* Content */}
                <div className="space-y-4">
                  <h3 className={`font-bold text-lg leading-tight ${available ? "text-gray-900" : "text-gray-500"}`}>
                    {sim.name}
                  </h3>
                  <p className={`text-sm leading-relaxed ${available ? "text-gray-600" : "text-gray-400"}`}>
                    {sim.description}
                  </p>

                  {/* Features */}
                  <div className="space-y-3 pt-2">
                    {sim.features.slice(0, 2).map((feature, index) => (
                      <div key={index} className="flex items-center gap-3">
                        <div className={`w-2 h-2 rounded-full ${available ? "bg-green-500" : "bg-gray-400"}`} />
                        <span className={`text-xs ${available ? "text-gray-600" : "text-gray-400"}`}>{feature}</span>
                      </div>
                    ))}
                    {sim.features.length > 2 && (
                      <div className="flex items-center gap-3">
                        <div className={`w-2 h-2 rounded-full ${available ? "bg-green-500" : "bg-gray-400"}`} />
                        <span className={`text-xs ${available ? "text-gray-600" : "text-gray-400"}`}>
                          +{sim.features.length - 2} more
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Upgrade indicator for locked features */}
                {!available && (
                  <div className="absolute inset-0 bg-gradient-to-t from-gray-900/20 to-transparent flex items-end justify-center pb-6 rounded-xl">
                    <Badge className="bg-white/90 text-gray-700 text-xs font-medium rounded-lg flex items-center px-3 py-1">
                      Upgrade Required
                    </Badge>
                  </div>
                )}
              </Link>
            </Card>
          )
        })}
      </div>

      {/* Current Tier Indicator */}
      <div className="mt-12 text-center">
        <Card className="inline-flex items-center gap-4 px-8 py-4 gradient-primary text-white rounded-xl shadow-lg">
          <Globe className="h-6 w-6" />
          <span className="font-medium text-lg">
            Current Plan:{" "}
            <span className="font-bold capitalize">
              {userTier === "admin" ? "Enterprise (Admin Access)" : userTier}
            </span>
          </span>
        </Card>
      </div>
    </div>
  )
}
