"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import type { Project } from "@/lib/simulation/projects"
import { Save, FolderOpen, Trash2, Calendar, Tag } from "lucide-react"

interface ProjectPanelProps {
  projects: Project[]
  currentProject: Project | null
  onSave: (name: string, description?: string) => void
  onLoad: (project: Project) => void
  onDelete: (id: string) => void
}

export function ProjectPanel({ projects, currentProject, onSave, onLoad, onDelete }: ProjectPanelProps) {
  const [showSaveDialog, setShowSaveDialog] = useState(false)
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)
  const [projectToDelete, setProjectToDelete] = useState<Project | null>(null)
  const [projectName, setProjectName] = useState("")
  const [projectDescription, setProjectDescription] = useState("")

  const handleSave = () => {
    if (projectName.trim()) {
      onSave(projectName, projectDescription)
      setShowSaveDialog(false)
      setProjectName("")
      setProjectDescription("")
    }
  }

  const handleDelete = () => {
    if (projectToDelete) {
      onDelete(projectToDelete.id)
      setShowDeleteDialog(false)
      setProjectToDelete(null)
    }
  }

  const confirmDelete = (project: Project) => {
    setProjectToDelete(project)
    setShowDeleteDialog(true)
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-1">
        <Card className="card-enhanced">
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <Save className="h-5 w-5 text-blue-600" />
              Save Project
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-gray-600">
              Save your current simulation configuration and results for future reference or sharing.
            </p>

            <Button
              onClick={() => setShowSaveDialog(true)}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
            >
              <Save className="h-4 w-4 mr-2" />
              Save Current Configuration
            </Button>

            {currentProject && (
              <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                <p className="font-medium">Current Project:</p>
                <p className="text-blue-700 font-bold">{currentProject.name}</p>
                <p className="text-sm text-gray-600 mt-1">
                  Last updated: {new Date(currentProject.updatedAt).toLocaleString()}
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="lg:col-span-2">
        <Card className="card-enhanced">
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <FolderOpen className="h-5 w-5 text-green-600" />
              Saved Projects
            </CardTitle>
          </CardHeader>
          <CardContent>
            {projects.length === 0 ? (
              <div className="text-center py-12">
                <FolderOpen className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                <p className="text-gray-500">No saved projects yet. Save your first project to see it here.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {projects.map((project) => (
                  <div
                    key={project.id}
                    className={`p-4 rounded-lg border-2 transition-all ${
                      currentProject?.id === project.id
                        ? "border-blue-500 bg-blue-50"
                        : "border-gray-200 hover:border-blue-300 hover:bg-gray-50"
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-bold text-lg">{project.name}</h3>
                          {project.isPublic && <Badge variant="outline">Public</Badge>}
                        </div>
                        <p className="text-gray-600 text-sm mt-1">{project.description}</p>
                        <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
                          <div className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            <span>{new Date(project.createdAt).toLocaleDateString()}</span>
                          </div>
                          {project.tags && project.tags.length > 0 && (
                            <div className="flex items-center gap-1">
                              <Tag className="h-3 w-3" />
                              <span>{project.tags.join(", ")}</span>
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onLoad(project)}
                          className="text-blue-600 border-blue-200 hover:bg-blue-50"
                        >
                          Load
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => confirmDelete(project)}
                          className="text-red-600 border-red-200 hover:bg-red-50"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="mt-3 grid grid-cols-3 gap-2 text-xs">
                      <div className="p-2 bg-gray-100 rounded">
                        <span className="font-medium">Battery:</span> {project.config.batteryCapacity} kWh
                      </div>
                      <div className="p-2 bg-gray-100 rounded">
                        <span className="font-medium">Solar:</span>{" "}
                        {project.config.solarEnabled ? "Enabled" : "Disabled"}
                      </div>
                      <div className="p-2 bg-gray-100 rounded">
                        <span className="font-medium">Weather:</span>{" "}
                        {project.config.useRealWeather ? "Real" : "Default"}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Save Dialog */}
      <Dialog open={showSaveDialog} onOpenChange={setShowSaveDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Save Project</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="project-name">Project Name</Label>
              <Input
                id="project-name"
                placeholder="My Simulation Project"
                value={projectName}
                onChange={(e) => setProjectName(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="project-description">Description (Optional)</Label>
              <Textarea
                id="project-description"
                placeholder="Brief description of this simulation setup"
                value={projectDescription}
                onChange={(e) => setProjectDescription(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowSaveDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleSave} disabled={!projectName.trim()}>
              Save Project
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Delete Project</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <p>Are you sure you want to delete "{projectToDelete?.name}"? This action cannot be undone.</p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDelete}>
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
