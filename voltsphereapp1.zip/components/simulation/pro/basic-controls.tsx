"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { SimulationConfig } from "@/lib/simulation/engine"
import { Battery, Sun, Zap, Settings } from "lucide-react"

interface BasicControlsProps {
  config: SimulationConfig
  onChange: (config: SimulationConfig) => void
  onRun: () => void
  isLoading: boolean
}

export function BasicControls({ config, onChange, onRun, isLoading }: BasicControlsProps) {
  const updateConfig = (updates: Partial<SimulationConfig>) => {
    onChange({ ...config, ...updates })
  }

  return (
    <Card className="card-enhanced">
      <CardHeader>
        <CardTitle className="flex items-center gap-3">
          <Settings className="h-5 w-5 text-blue-600" />
          Basic Controls
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Battery Capacity */}
        <div className="space-y-3">
          <Label className="flex items-center gap-2 font-semibold">
            <Battery className="h-4 w-4 text-green-600" />
            Battery Capacity: {config.batteryCapacity} kWh
          </Label>
          <Slider
            value={[config.batteryCapacity]}
            onValueChange={([value]) => updateConfig({ batteryCapacity: value })}
            max={50}
            min={0}
            step={1}
            className="w-full"
          />
          <div className="flex justify-between text-sm text-gray-500">
            <span>0 kWh</span>
            <span>50 kWh</span>
          </div>
        </div>

        {/* Battery Type */}
        <div className="space-y-3">
          <Label className="font-semibold">Battery Type</Label>
          <Select value={config.batteryType} onValueChange={(value: any) => updateConfig({ batteryType: value })}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="lithium">Lithium-ion (High efficiency)</SelectItem>
              <SelectItem value="lead-acid">Lead-acid (Budget friendly)</SelectItem>
              <SelectItem value="flow">Flow Battery (Long duration)</SelectItem>
              <SelectItem value="sodium">Sodium-ion (Sustainable)</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Battery Efficiency */}
        <div className="space-y-3">
          <Label className="flex items-center gap-2 font-semibold">
            <Zap className="h-4 w-4 text-yellow-600" />
            Battery Efficiency: {config.batteryEfficiency}%
          </Label>
          <Slider
            value={[config.batteryEfficiency]}
            onValueChange={([value]) => updateConfig({ batteryEfficiency: value })}
            max={98}
            min={70}
            step={1}
            className="w-full"
          />
          <div className="flex justify-between text-sm text-gray-500">
            <span>70%</span>
            <span>98%</span>
          </div>
        </div>

        {/* Load Profile Type */}
        <div className="space-y-3">
          <Label className="font-semibold">Load Profile</Label>
          <Select
            value={config.loadProfileType}
            onValueChange={(value: any) => updateConfig({ loadProfileType: value })}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="default">Default Profile</SelectItem>
              <SelectItem value="residential">Residential Home</SelectItem>
              <SelectItem value="commercial">Commercial Building</SelectItem>
              <SelectItem value="custom">Custom Upload</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Solar Power Toggle */}
        <div className="flex items-center justify-between p-4 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-xl border-2 border-yellow-200">
          <Label htmlFor="solar-toggle" className="flex items-center gap-2 cursor-pointer">
            <Sun className="h-4 w-4 text-yellow-600" />
            <span className="font-semibold text-yellow-800">Enable Solar Power</span>
          </Label>
          <Switch
            id="solar-toggle"
            checked={config.solarEnabled}
            onCheckedChange={(checked) => updateConfig({ solarEnabled: checked })}
            className="data-[state=checked]:bg-yellow-600"
          />
        </div>

        {/* Time of Use Rates */}
        <div className="flex items-center justify-between p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl border-2 border-blue-200">
          <Label htmlFor="tou-toggle" className="flex items-center gap-2 cursor-pointer">
            <Zap className="h-4 w-4 text-blue-600" />
            <span className="font-semibold text-blue-800">Time-of-Use Rates</span>
          </Label>
          <Switch
            id="tou-toggle"
            checked={config.timeOfUseRates}
            onCheckedChange={(checked) => updateConfig({ timeOfUseRates: checked })}
            className="data-[state=checked]:bg-blue-600"
          />
        </div>

        {/* Run Simulation Button */}
        <div className="pt-4">
          <Button
            onClick={onRun}
            disabled={isLoading}
            className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 mobile-btn mobile-rounded font-semibold"
          >
            {isLoading ? "Running..." : "⚡ Run Simulation"}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
