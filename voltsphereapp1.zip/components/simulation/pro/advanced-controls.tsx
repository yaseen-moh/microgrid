"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"
import type { SimulationConfig } from "@/lib/simulation/engine"
import { Upload, DollarSign, Wrench, FileText } from "lucide-react"

interface AdvancedControlsProps {
  config: SimulationConfig
  onChange: (config: SimulationConfig) => void
  onRun: () => void
  isLoading: boolean
}

export function AdvancedControls({ config, onChange, onRun, isLoading }: AdvancedControlsProps) {
  const [customLoadFile, setCustomLoadFile] = useState<File | null>(null)

  const updateConfig = (updates: Partial<SimulationConfig>) => {
    onChange({ ...config, ...updates })
  }

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    setCustomLoadFile(file)

    try {
      const text = await file.text()
      const lines = text.split("\n")
      const data: number[] = []

      for (const line of lines) {
        const value = Number.parseFloat(line.trim())
        if (!isNaN(value)) {
          data.push(value)
        }
      }

      if (data.length === 24) {
        updateConfig({
          customLoadData: data,
          loadProfileType: "custom",
        })
        alert("Load profile uploaded successfully!")
      } else {
        alert("Please upload a CSV file with exactly 24 hourly values")
      }
    } catch (error) {
      alert("Error reading file. Please ensure it's a valid CSV.")
    }
  }

  const handlePasteData = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const values = e.target.value
      .split(",")
      .map((v) => Number.parseFloat(v.trim()))
      .filter((v) => !isNaN(v))

    if (values.length === 24) {
      updateConfig({
        customLoadData: values,
        loadProfileType: "custom",
      })
      alert("Load profile data updated successfully!")
    } else if (values.length > 0) {
      alert(`Please provide exactly 24 values. You provided ${values.length} values.`)
    }
  }

  const economicParams = config.economicParams || {
    gridCostPerKwh: 0.12,
    solarCostPerWatt: 3.0,
    batteryCostPerKwh: 500,
    discountRate: 0.06,
    systemLifespan: 25,
  }

  const equipmentSpecs = config.equipmentSpecs || {
    solarPanelEfficiency: 20,
    inverterEfficiency: 96,
    systemLosses: 14,
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Custom Load Profile */}
      <Card className="card-enhanced">
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <Upload className="h-5 w-5 text-green-600" />
            Custom Load Profile
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="load-file" className="font-semibold">
              Upload 24-hour Load Data (CSV)
            </Label>
            <Input id="load-file" type="file" accept=".csv,.txt" onChange={handleFileUpload} className="mt-2" />
            <p className="text-sm text-gray-500 mt-1">Upload a CSV file with 24 hourly load values (kW)</p>
          </div>

          {customLoadFile && (
            <div className="p-3 bg-green-50 rounded-lg border border-green-200">
              <p className="text-sm text-green-700 font-medium">✓ Loaded: {customLoadFile.name}</p>
            </div>
          )}

          {config.customLoadData && (
            <div>
              <Label className="font-semibold">Preview (first 12 hours):</Label>
              <div className="grid grid-cols-6 gap-2 mt-2">
                {config.customLoadData.slice(0, 12).map((value, i) => (
                  <div key={i} className="text-center p-2 bg-gray-100 rounded text-sm">
                    <div className="font-medium">{i}h</div>
                    <div>{value.toFixed(1)}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <Textarea
            placeholder="Or paste comma-separated values here (24 values)..."
            className="min-h-[100px]"
            onChange={handlePasteData}
          />
        </CardContent>
      </Card>

      {/* Equipment Specifications */}
      <Card className="card-enhanced">
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <Wrench className="h-5 w-5 text-blue-600" />
            Equipment Specifications
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label className="font-semibold">Solar Panel Efficiency: {equipmentSpecs.solarPanelEfficiency}%</Label>
            <Slider
              value={[equipmentSpecs.solarPanelEfficiency]}
              onValueChange={([value]) =>
                updateConfig({
                  equipmentSpecs: { ...equipmentSpecs, solarPanelEfficiency: value },
                })
              }
              max={25}
              min={15}
              step={0.5}
              className="mt-2"
            />
          </div>

          <div>
            <Label className="font-semibold">Inverter Efficiency: {equipmentSpecs.inverterEfficiency}%</Label>
            <Slider
              value={[equipmentSpecs.inverterEfficiency]}
              onValueChange={([value]) =>
                updateConfig({
                  equipmentSpecs: { ...equipmentSpecs, inverterEfficiency: value },
                })
              }
              max={99}
              min={90}
              step={0.5}
              className="mt-2"
            />
          </div>

          <div>
            <Label className="font-semibold">System Losses: {equipmentSpecs.systemLosses}%</Label>
            <Slider
              value={[equipmentSpecs.systemLosses]}
              onValueChange={([value]) =>
                updateConfig({
                  equipmentSpecs: { ...equipmentSpecs, systemLosses: value },
                })
              }
              max={25}
              min={5}
              step={1}
              className="mt-2"
            />
          </div>
        </CardContent>
      </Card>

      {/* Economic Parameters */}
      <Card className="card-enhanced">
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <DollarSign className="h-5 w-5 text-green-600" />
            Economic Parameters
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="font-semibold">Grid Cost ($/kWh)</Label>
              <Input
                type="number"
                step="0.01"
                value={economicParams.gridCostPerKwh}
                onChange={(e) =>
                  updateConfig({
                    economicParams: { ...economicParams, gridCostPerKwh: Number.parseFloat(e.target.value) || 0.12 },
                  })
                }
                className="mt-1"
              />
            </div>

            <div>
              <Label className="font-semibold">Solar Cost ($/W)</Label>
              <Input
                type="number"
                step="0.1"
                value={economicParams.solarCostPerWatt}
                onChange={(e) =>
                  updateConfig({
                    economicParams: { ...economicParams, solarCostPerWatt: Number.parseFloat(e.target.value) || 3.0 },
                  })
                }
                className="mt-1"
              />
            </div>

            <div>
              <Label className="font-semibold">Battery Cost ($/kWh)</Label>
              <Input
                type="number"
                step="10"
                value={economicParams.batteryCostPerKwh}
                onChange={(e) =>
                  updateConfig({
                    economicParams: { ...economicParams, batteryCostPerKwh: Number.parseFloat(e.target.value) || 500 },
                  })
                }
                className="mt-1"
              />
            </div>

            <div>
              <Label className="font-semibold">Discount Rate (%)</Label>
              <Input
                type="number"
                step="0.1"
                value={economicParams.discountRate * 100}
                onChange={(e) =>
                  updateConfig({
                    economicParams: { ...economicParams, discountRate: (Number.parseFloat(e.target.value) || 6) / 100 },
                  })
                }
                className="mt-1"
              />
            </div>
          </div>

          <div>
            <Label className="font-semibold">System Lifespan: {economicParams.systemLifespan} years</Label>
            <Slider
              value={[economicParams.systemLifespan]}
              onValueChange={([value]) =>
                updateConfig({
                  economicParams: { ...economicParams, systemLifespan: value },
                })
              }
              max={30}
              min={15}
              step={1}
              className="mt-2"
            />
          </div>
        </CardContent>
      </Card>

      {/* Location Settings */}
      <Card className="card-enhanced">
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <FileText className="h-5 w-5 text-purple-600" />
            Location & Weather
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label className="font-semibold">Weather Location</Label>
            <Input
              placeholder="e.g., Chicago, IL"
              value={config.weatherLocation || ""}
              onChange={(e) => updateConfig({ weatherLocation: e.target.value })}
              className="mt-1"
            />
          </div>

          <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
            <Label htmlFor="real-weather" className="font-semibold">
              Use Real Weather Data
            </Label>
            <Switch
              id="real-weather"
              checked={config.useRealWeather}
              onCheckedChange={(checked) => updateConfig({ useRealWeather: checked })}
            />
          </div>

          {config.location && (
            <div className="p-3 bg-gray-50 rounded-lg">
              <p className="text-sm font-medium">Coordinates:</p>
              <p className="text-sm text-gray-600">
                Lat: {config.location.lat.toFixed(4)}, Lng: {config.location.lng.toFixed(4)}
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Run Advanced Simulation */}
      <div className="lg:col-span-2">
        <Button
          onClick={onRun}
          disabled={isLoading}
          className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 mobile-btn mobile-rounded font-semibold"
        >
          {isLoading ? "Running Advanced Simulation..." : "🚀 Run Advanced Simulation"}
        </Button>
      </div>
    </div>
  )
}
