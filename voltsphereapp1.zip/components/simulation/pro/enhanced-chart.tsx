"use client"

import { useEffect, useRef, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import type { SimulationResult, SimulationConfig } from "@/lib/simulation/engine"
import { Sun, Cloud, Battery, Zap, TrendingUp } from "lucide-react"

interface EnhancedChartProps {
  data: SimulationResult
  config: SimulationConfig
  showWeather?: boolean
}

export function EnhancedChart({ data, config, showWeather = false }: EnhancedChartProps) {
  const chartRef = useRef<HTMLCanvasElement>(null)
  const [activeTab, setActiveTab] = useState("energy")

  useEffect(() => {
    if (!chartRef.current || !data) return

    const ctx = chartRef.current.getContext("2d")
    if (!ctx) return

    // Clear previous chart
    ctx.clearRect(0, 0, chartRef.current.width, chartRef.current.height)

    // Chart dimensions
    const width = chartRef.current.width
    const height = chartRef.current.height
    const padding = { top: 40, right: 30, bottom: 60, left: 60 }
    const chartWidth = width - padding.left - padding.right
    const chartHeight = height - padding.top - padding.bottom

    // Find max value for scaling
    const allValues = data.data.flatMap((point) => [point.solar, point.consumption, point.grid])
    const maxValue = Math.max(...allValues) * 1.2 // Add 20% headroom

    // Draw axes
    ctx.beginPath()
    ctx.strokeStyle = "#94a3b8" // slate-400
    ctx.lineWidth = 1
    ctx.moveTo(padding.left, padding.top)
    ctx.lineTo(padding.left, height - padding.bottom)
    ctx.lineTo(width - padding.right, height - padding.bottom)
    ctx.stroke()

    // Draw grid lines
    ctx.beginPath()
    ctx.strokeStyle = "#e2e8f0" // slate-200
    ctx.lineWidth = 0.5
    for (let i = 0; i <= 5; i++) {
      const y = padding.top + (chartHeight * i) / 5
      ctx.moveTo(padding.left, y)
      ctx.lineTo(width - padding.right, y)
    }
    ctx.stroke()

    // Draw y-axis labels
    ctx.fillStyle = "#64748b" // slate-500
    ctx.font = "12px Inter, sans-serif"
    ctx.textAlign = "right"
    for (let i = 0; i <= 5; i++) {
      const value = maxValue - (maxValue * i) / 5
      const y = padding.top + (chartHeight * i) / 5
      ctx.fillText(`${Math.round(value)} kW`, padding.left - 10, y + 4)
    }

    // Draw x-axis labels (hours)
    ctx.textAlign = "center"
    const hourStep = Math.ceil(data.data.length / 12) // Show fewer labels on small screens
    for (let i = 0; i < data.data.length; i += hourStep) {
      const x = padding.left + (chartWidth * i) / (data.data.length - 1)
      ctx.fillText(data.data[i].time, x, height - padding.bottom + 20)
    }

    // Draw title
    ctx.fillStyle = "#1e293b" // slate-800
    ctx.font = "bold 16px Inter, sans-serif"
    ctx.textAlign = "center"
    ctx.fillText("Energy Flow Over Time", width / 2, 20)

    // Draw legend
    const legendItems = [
      { label: "Solar", color: "#eab308" }, // yellow-500
      { label: "Consumption", color: "#ef4444" }, // red-500
      { label: "Grid", color: "#3b82f6" }, // blue-500
    ]

    ctx.font = "12px Inter, sans-serif"
    ctx.textAlign = "left"
    let legendX = padding.left
    legendItems.forEach((item) => {
      ctx.fillStyle = item.color
      ctx.fillRect(legendX, height - padding.bottom + 40, 12, 12)
      ctx.fillStyle = "#64748b" // slate-500
      ctx.fillText(item.label, legendX + 16, height - padding.bottom + 50)
      legendX += 100
    })

    // Draw data lines
    if (activeTab === "energy") {
      // Draw solar generation
      if (config.solarEnabled) {
        drawLine(
          ctx,
          data.data.map((point) => point.solar),
          "#eab308", // yellow-500
          padding,
          chartWidth,
          chartHeight,
          maxValue,
          data.data.length,
        )
      }

      // Draw consumption
      drawLine(
        ctx,
        data.data.map((point) => point.consumption),
        "#ef4444", // red-500
        padding,
        chartWidth,
        chartHeight,
        maxValue,
        data.data.length,
      )

      // Draw grid usage
      drawLine(
        ctx,
        data.data.map((point) => point.grid),
        "#3b82f6", // blue-500
        padding,
        chartWidth,
        chartHeight,
        maxValue,
        data.data.length,
      )
    } else if (activeTab === "battery") {
      // Draw battery state
      drawLine(
        ctx,
        data.data.map((point) => (point.battery / 100) * maxValue), // Scale to match chart
        "#22c55e", // green-500
        padding,
        chartWidth,
        chartHeight,
        maxValue,
        data.data.length,
        true,
      )

      // Update legend for battery
      ctx.clearRect(padding.left, height - padding.bottom + 35, width - padding.left - padding.right, 25)
      ctx.fillStyle = "#22c55e" // green-500
      ctx.fillRect(padding.left, height - padding.bottom + 40, 12, 12)
      ctx.fillStyle = "#64748b" // slate-500
      ctx.fillText("Battery State (%)", padding.left + 16, height - padding.bottom + 50)
    } else if (activeTab === "weather" && showWeather) {
      // Draw weather factors
      drawLine(
        ctx,
        data.data.map((point) => (point.weather || 0) * maxValue * 0.8), // Scale to match chart
        "#8b5cf6", // purple-500
        padding,
        chartWidth,
        chartHeight,
        maxValue,
        data.data.length,
        true,
      )

      // Update legend for weather
      ctx.clearRect(padding.left, height - padding.bottom + 35, width - padding.left - padding.right, 25)
      ctx.fillStyle = "#8b5cf6" // purple-500
      ctx.fillRect(padding.left, height - padding.bottom + 40, 12, 12)
      ctx.fillStyle = "#64748b" // slate-500
      ctx.fillText("Weather Factor", padding.left + 16, height - padding.bottom + 50)
    }
  }, [data, activeTab, showWeather, config.solarEnabled])

  // Helper function to draw a line
  const drawLine = (
    ctx: CanvasRenderingContext2D,
    values: number[],
    color: string,
    padding: { top: number; right: number; bottom: number; left: number },
    chartWidth: number,
    chartHeight: number,
    maxValue: number,
    dataLength: number,
    fill = false,
  ) => {
    ctx.beginPath()
    ctx.strokeStyle = color
    ctx.fillStyle = color + "33" // Add transparency for fill
    ctx.lineWidth = 2

    for (let i = 0; i < values.length; i++) {
      const x = padding.left + (chartWidth * i) / (dataLength - 1)
      const y = padding.top + chartHeight - (chartHeight * values[i]) / maxValue

      if (i === 0) {
        ctx.moveTo(x, y)
      } else {
        ctx.lineTo(x, y)
      }
    }

    ctx.stroke()

    if (fill) {
      // Complete the path for filling
      ctx.lineTo(padding.left + chartWidth, padding.top + chartHeight)
      ctx.lineTo(padding.left, padding.top + chartHeight)
      ctx.closePath()
      ctx.fill()
    }
  }

  // Calculate summary statistics
  const totalSolar = data.summary.totalSolar.toFixed(1)
  const totalConsumption = data.summary.totalConsumption.toFixed(1)
  const totalGrid = data.summary.totalGrid.toFixed(1)
  const avgBattery = Math.round(data.summary.avgBattery)
  const solarPercentage = ((data.summary.totalSolar / data.summary.totalConsumption) * 100).toFixed(1)

  return (
    <Card className="card-enhanced mobile-rounded">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-blue-600" />
            Pro Energy Analysis
          </CardTitle>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-auto">
            <TabsList className="mobile-rounded">
              <TabsTrigger value="energy" className="flex items-center gap-1">
                <Zap className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Energy</span>
              </TabsTrigger>
              <TabsTrigger value="battery" className="flex items-center gap-1">
                <Battery className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Battery</span>
              </TabsTrigger>
              {showWeather && (
                <TabsTrigger value="weather" className="flex items-center gap-1">
                  <Cloud className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">Weather</span>
                </TabsTrigger>
              )}
            </TabsList>
          </Tabs>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-80 w-full">
          <canvas ref={chartRef} width={800} height={400} className="w-full h-full"></canvas>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-2 mt-4">
          <div className="bg-yellow-50 p-3 rounded-lg border border-yellow-100">
            <div className="flex items-center gap-2">
              <Sun className="h-4 w-4 text-yellow-600" />
              <span className="text-sm font-medium text-yellow-800">Solar</span>
            </div>
            <p className="text-lg font-bold text-yellow-700 mt-1">{totalSolar} kWh</p>
            <p className="text-xs text-yellow-600">{solarPercentage}% of usage</p>
          </div>

          <div className="bg-red-50 p-3 rounded-lg border border-red-100">
            <div className="flex items-center gap-2">
              <Zap className="h-4 w-4 text-red-600" />
              <span className="text-sm font-medium text-red-800">Usage</span>
            </div>
            <p className="text-lg font-bold text-red-700 mt-1">{totalConsumption} kWh</p>
            <p className="text-xs text-red-600">Total consumption</p>
          </div>

          <div className="bg-blue-50 p-3 rounded-lg border border-blue-100">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-blue-600" />
              <span className="text-sm font-medium text-blue-800">Grid</span>
            </div>
            <p className="text-lg font-bold text-blue-700 mt-1">{totalGrid} kWh</p>
            <p className="text-xs text-blue-600">From utility</p>
          </div>

          <div className="bg-green-50 p-3 rounded-lg border border-green-100">
            <div className="flex items-center gap-2">
              <Battery className="h-4 w-4 text-green-600" />
              <span className="text-sm font-medium text-green-800">Battery</span>
            </div>
            <p className="text-lg font-bold text-green-700 mt-1">{avgBattery}%</p>
            <p className="text-xs text-green-600">Avg charge</p>
          </div>

          <div className="bg-purple-50 p-3 rounded-lg border border-purple-100">
            <div className="flex items-center gap-2">
              <Badge className="bg-gradient-to-r from-purple-600 to-pink-600 text-white text-xs">PRO</Badge>
              <span className="text-sm font-medium text-purple-800">Type</span>
            </div>
            <p className="text-lg font-bold text-purple-700 mt-1 capitalize">{config.batteryType || "Standard"}</p>
            <p className="text-xs text-purple-600">{config.batteryEfficiency}% efficient</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
