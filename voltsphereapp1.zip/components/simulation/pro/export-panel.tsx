"use client"

import { useState } from "react"
import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import type { SimulationConfig, SimulationResult } from "@/lib/simulation/engine"
import type { Project } from "@/lib/simulation/projects"
import { Download, FileText, ImageIcon, Table, Share2, Copy } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

interface ExportPanelProps {
  results: SimulationResult | null
  config: SimulationConfig
  project: Project | null
}

export function ExportPanel({ results, config, project }: ExportPanelProps) {
  const [exportFormat, setExportFormat] = useState("csv")
  const [includeConfig, setIncludeConfig] = useState(true)
  const [includeCostAnalysis, setIncludeCostAnalysis] = useState(true)
  const [includeWeatherData, setIncludeWeatherData] = useState(true)

  const handleExport = () => {
    if (!results) return

    switch (exportFormat) {
      case "csv":
        exportCSV()
        break
      case "json":
        exportJSON()
        break
      case "pdf":
        alert("PDF export feature coming soon!")
        break
      case "png":
        alert("PNG export feature coming soon!")
        break
    }
  }

  const handleCopyLink = () => {
    if (project) {
      const shareUrl = `${window.location.origin}/simulation/shared/${project.id}`
      navigator.clipboard
        .writeText(shareUrl)
        .then(() => {
          alert("Share link copied to clipboard!")
        })
        .catch(() => {
          alert("Failed to copy link. Please copy manually.")
        })
    }
  }

  const exportCSV = () => {
    if (!results) return

    const rows = [["Hour", "Solar Generation (kW)", "Load Demand (kW)", "Battery Level (kWh)", "Grid Usage (kW)"]]

    // Add hourly data
    results.hours.forEach((hour, i) => {
      rows.push([
        hour.toString(),
        results.solarProfile[i].toFixed(2),
        results.loadProfile[i].toFixed(2),
        results.batteryStorage[i].toFixed(2),
        results.gridUsage[i].toFixed(2),
      ])
    })

    // Add empty row as separator
    rows.push([])

    // Add cost analysis if selected
    if (includeCostAnalysis && results.costAnalysis) {
      rows.push(["Cost Analysis"])
      rows.push(["Total Grid Cost", `$${results.costAnalysis.totalGridCost.toFixed(2)}`])
      rows.push(["Solar Savings", `$${results.costAnalysis.solarSavings.toFixed(2)}`])
      rows.push(["Battery Savings", `$${results.costAnalysis.batterySavings.toFixed(2)}`])
      rows.push(["Net Daily Cost", `$${results.costAnalysis.netCost.toFixed(2)}`])
      rows.push(["Payback Period", `${results.costAnalysis.paybackPeriod.toFixed(1)} years`])

      // Add advanced metrics if available
      if ("lcoe" in results.costAnalysis) {
        rows.push(["LCOE", `$${results.costAnalysis.lcoe.toFixed(4)} per kWh`])
      }
      if ("npv" in results.costAnalysis) {
        rows.push(["NPV", `$${results.costAnalysis.npv.toFixed(2)}`])
      }
      if ("irr" in results.costAnalysis) {
        rows.push(["IRR", `${(results.costAnalysis.irr * 100).toFixed(2)}%`])
      }
    }

    // Add weather data if selected
    if (includeWeatherData && results.weatherData) {
      rows.push([])
      rows.push(["Weather Data"])
      rows.push(["Hour", "Temperature (°C)", "Irradiance (W/m²)", "Cloud Cover (%)"])
      results.hours.forEach((hour, i) => {
        rows.push([
          hour.toString(),
          results.weatherData!.temperature[i].toFixed(1),
          results.weatherData!.irradiance[i].toFixed(0),
          results.weatherData!.cloudCover[i].toFixed(0),
        ])
      })
    }

    // Add configuration if selected
    if (includeConfig) {
      rows.push([])
      rows.push(["Simulation Configuration"])
      rows.push(["Battery Capacity", `${config.batteryCapacity} kWh`])
      rows.push(["Battery Efficiency", `${config.batteryEfficiency}%`])
      rows.push(["Solar Enabled", config.solarEnabled ? "Yes" : "No"])
      if (config.batteryType) {
        rows.push(["Battery Type", config.batteryType])
      }
      if (config.loadProfileType) {
        rows.push(["Load Profile Type", config.loadProfileType])
      }
      if (config.weatherLocation) {
        rows.push(["Weather Location", config.weatherLocation])
      }
      if (config.timeOfUseRates !== undefined) {
        rows.push(["Time-of-Use Rates", config.timeOfUseRates ? "Enabled" : "Disabled"])
      }
    }

    // Convert to CSV
    const csvContent = rows.map((row) => row.join(",")).join("\n")

    // Create and download file
    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `voltsphere-simulation-${new Date().toISOString().split("T")[0]}.csv`
    a.click()
    window.URL.revokeObjectURL(url)
  }

  const exportJSON = () => {
    if (!results) return

    // Create export object
    const exportData: any = {
      simulationResults: {
        hours: results.hours,
        solarProfile: results.solarProfile,
        loadProfile: results.loadProfile,
        batteryStorage: results.batteryStorage,
        gridUsage: results.gridUsage,
      },
    }

    // Add cost analysis if selected
    if (includeCostAnalysis && results.costAnalysis) {
      exportData.costAnalysis = results.costAnalysis
    }

    // Add weather data if selected
    if (includeWeatherData && results.weatherData) {
      exportData.weatherData = results.weatherData
    }

    // Add configuration if selected
    if (includeConfig) {
      exportData.configuration = config
    }

    // Add project metadata if available
    if (project) {
      exportData.project = {
        id: project.id,
        name: project.name,
        description: project.description,
        createdAt: project.createdAt,
        updatedAt: project.updatedAt,
      }
    }

    // Convert to JSON
    const jsonContent = JSON.stringify(exportData, null, 2)

    // Create and download file
    const blob = new Blob([jsonContent], { type: "application/json" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `voltsphere-simulation-${new Date().toISOString().split("T")[0]}.json`
    a.click()
    window.URL.revokeObjectURL(url)
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-1">
        <Card className="card-enhanced">
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <Download className="h-5 w-5 text-blue-600" />
              Export Options
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label className="font-semibold">Export Format</Label>
              <Tabs value={exportFormat} onValueChange={setExportFormat} className="mt-2">
                <TabsList className="grid grid-cols-4 w-full">
                  <TabsTrigger value="csv" className="flex items-center gap-1">
                    <FileText className="h-4 w-4" />
                    <span className="hidden sm:inline">CSV</span>
                  </TabsTrigger>
                  <TabsTrigger value="json" className="flex items-center gap-1">
                    <Table className="h-4 w-4" />
                    <span className="hidden sm:inline">JSON</span>
                  </TabsTrigger>
                  <TabsTrigger value="pdf" className="flex items-center gap-1">
                    <FileText className="h-4 w-4" />
                    <span className="hidden sm:inline">PDF</span>
                  </TabsTrigger>
                  <TabsTrigger value="png" className="flex items-center gap-1">
                    <ImageIcon className="h-4 w-4" />
                    <span className="hidden sm:inline">PNG</span>
                  </TabsTrigger>
                </TabsList>
              </Tabs>
            </div>

            <div className="space-y-3">
              <Label className="font-semibold">Include in Export</Label>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="include-config"
                    checked={includeConfig}
                    onCheckedChange={(checked) => setIncludeConfig(checked as boolean)}
                  />
                  <Label htmlFor="include-config" className="cursor-pointer">
                    Simulation Configuration
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="include-cost"
                    checked={includeCostAnalysis}
                    onCheckedChange={(checked) => setIncludeCostAnalysis(checked as boolean)}
                  />
                  <Label htmlFor="include-cost" className="cursor-pointer">
                    Cost Analysis
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="include-weather"
                    checked={includeWeatherData}
                    onCheckedChange={(checked) => setIncludeWeatherData(checked as boolean)}
                    disabled={!results?.weatherData}
                  />
                  <Label
                    htmlFor="include-weather"
                    className={`cursor-pointer ${!results?.weatherData ? "text-gray-400" : ""}`}
                  >
                    Weather Data
                  </Label>
                </div>
              </div>
            </div>

            <Button
              onClick={handleExport}
              disabled={!results}
              className="w-full bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700"
            >
              <Download className="h-4 w-4 mr-2" />
              Export {exportFormat.toUpperCase()}
            </Button>
          </CardContent>
        </Card>
      </div>

      <div className="lg:col-span-2">
        <Card className="card-enhanced">
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <Share2 className="h-5 w-5 text-purple-600" />
              Share & Embed
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label className="font-semibold">Share Link</Label>
              <div className="flex gap-2 mt-2">
                <Input
                  readOnly
                  value={
                    project
                      ? `${window.location.origin}/simulation/shared/${project.id}`
                      : "Save your project first to generate a share link"
                  }
                  disabled={!project}
                />
                <Button variant="outline" disabled={!project} onClick={handleCopyLink}>
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
              <p className="text-sm text-gray-500 mt-1">
                {project?.isPublic
                  ? "This link is public and can be accessed by anyone"
                  : "Save and make your project public to share it"}
              </p>
            </div>

            <div>
              <Label className="font-semibold">Embed Code</Label>
              <div className="mt-2">
                <Textarea
                  readOnly
                  value={
                    project
                      ? `<iframe src="${window.location.origin}/simulation/embed/${project.id}" width="800" height="600" frameborder="0"></iframe>`
                      : "Save your project first to generate embed code"
                  }
                  disabled={!project}
                  rows={3}
                />
              </div>
              <p className="text-sm text-gray-500 mt-1">Copy this code to embed the simulation on your website</p>
            </div>

            <div className="p-4 bg-gray-50 rounded-lg">
              <h3 className="font-semibold mb-2">API Access</h3>
              <p className="text-sm text-gray-600 mb-4">
                Access this simulation programmatically via our API. Upgrade to an API tier for full access.
              </p>
              <div className="flex gap-2">
                <Button variant="outline" className="flex-1" onClick={() => alert("API documentation coming soon!")}>
                  View API Docs
                </Button>
                <Link href="/pricing" className="flex-1">
                  <Button className="w-full bg-purple-600 hover:bg-purple-700">Upgrade to API Tier</Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
