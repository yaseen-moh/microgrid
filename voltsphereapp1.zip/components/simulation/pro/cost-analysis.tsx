"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import type { SimulationResult, SimulationConfig } from "@/lib/simulation/engine"
import { DollarSign, TrendingUp, Calendar, BarChart3 } from "lucide-react"

interface CostAnalysisProps {
  data: SimulationResult
  config: SimulationConfig
}

export function CostAnalysis({ data, config }: CostAnalysisProps) {
  const { costAnalysis } = data

  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(value)
  }

  // Calculate annual values
  const annualGridCost = costAnalysis.totalGridCost * 365
  const annualSolarSavings = costAnalysis.solarSavings * 365
  const annualBatterySavings = costAnalysis.batterySavings * 365
  const annualNetCost = costAnalysis.netCost * 365

  // Calculate 10-year values
  const tenYearGridCost = annualGridCost * 10
  const tenYearSolarSavings = annualSolarSavings * 10
  const tenYearBatterySavings = annualBatterySavings * 10
  const tenYearNetCost = annualNetCost * 10

  return (
    <Card className="card-enhanced mobile-rounded">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <DollarSign className="h-5 w-5 text-green-600" />
          Pro Cost Analysis
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <Tabs defaultValue="daily" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mobile-rounded">
            <TabsTrigger value="daily" className="flex items-center gap-2">
              <DollarSign className="h-4 w-4" />
              Daily
            </TabsTrigger>
            <TabsTrigger value="annual" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Annual
            </TabsTrigger>
            <TabsTrigger value="tenyear" className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              10-Year
            </TabsTrigger>
          </TabsList>

          <TabsContent value="daily" className="pt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <Card className="bg-red-50 border-red-100">
                    <CardContent className="p-4">
                      <p className="text-sm font-medium text-red-800">Grid Cost</p>
                      <p className="text-2xl font-bold text-red-700">{formatCurrency(costAnalysis.totalGridCost)}</p>
                    </CardContent>
                  </Card>
                  <Card className="bg-green-50 border-green-100">
                    <CardContent className="p-4">
                      <p className="text-sm font-medium text-green-800">Solar Savings</p>
                      <p className="text-2xl font-bold text-green-700">{formatCurrency(costAnalysis.solarSavings)}</p>
                    </CardContent>
                  </Card>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <Card className="bg-blue-50 border-blue-100">
                    <CardContent className="p-4">
                      <p className="text-sm font-medium text-blue-800">Battery Savings</p>
                      <p className="text-2xl font-bold text-blue-700">{formatCurrency(costAnalysis.batterySavings)}</p>
                    </CardContent>
                  </Card>
                  <Card className="bg-purple-50 border-purple-100">
                    <CardContent className="p-4">
                      <p className="text-sm font-medium text-purple-800">Net Cost</p>
                      <p className="text-2xl font-bold text-purple-700">{formatCurrency(costAnalysis.netCost)}</p>
                    </CardContent>
                  </Card>
                </div>
              </div>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base flex items-center gap-2">
                    <BarChart3 className="h-4 w-4" />
                    Daily Cost Breakdown
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-40 flex items-end gap-4 pt-4">
                    <div className="flex-1 flex flex-col items-center">
                      <div
                        className="w-full bg-red-500 rounded-t-sm"
                        style={{ height: `${(costAnalysis.totalGridCost / 10) * 100}px` }}
                      ></div>
                      <p className="text-xs mt-2">Grid</p>
                    </div>
                    <div className="flex-1 flex flex-col items-center">
                      <div
                        className="w-full bg-green-500 rounded-t-sm"
                        style={{ height: `${(costAnalysis.solarSavings / 10) * 100}px` }}
                      ></div>
                      <p className="text-xs mt-2">Solar</p>
                    </div>
                    <div className="flex-1 flex flex-col items-center">
                      <div
                        className="w-full bg-blue-500 rounded-t-sm"
                        style={{ height: `${(costAnalysis.batterySavings / 10) * 100}px` }}
                      ></div>
                      <p className="text-xs mt-2">Battery</p>
                    </div>
                    <div className="flex-1 flex flex-col items-center">
                      <div
                        className="w-full bg-purple-500 rounded-t-sm"
                        style={{ height: `${(costAnalysis.netCost / 10) * 100}px` }}
                      ></div>
                      <p className="text-xs mt-2">Net</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="annual" className="pt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <Card className="bg-red-50 border-red-100">
                    <CardContent className="p-4">
                      <p className="text-sm font-medium text-red-800">Annual Grid Cost</p>
                      <p className="text-2xl font-bold text-red-700">{formatCurrency(annualGridCost)}</p>
                    </CardContent>
                  </Card>
                  <Card className="bg-green-50 border-green-100">
                    <CardContent className="p-4">
                      <p className="text-sm font-medium text-green-800">Annual Solar Savings</p>
                      <p className="text-2xl font-bold text-green-700">{formatCurrency(annualSolarSavings)}</p>
                    </CardContent>
                  </Card>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <Card className="bg-blue-50 border-blue-100">
                    <CardContent className="p-4">
                      <p className="text-sm font-medium text-blue-800">Annual Battery Savings</p>
                      <p className="text-2xl font-bold text-blue-700">{formatCurrency(annualBatterySavings)}</p>
                    </CardContent>
                  </Card>
                  <Card className="bg-purple-50 border-purple-100">
                    <CardContent className="p-4">
                      <p className="text-sm font-medium text-purple-800">Annual Net Cost</p>
                      <p className="text-2xl font-bold text-purple-700">{formatCurrency(annualNetCost)}</p>
                    </CardContent>
                  </Card>
                </div>
              </div>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base flex items-center gap-2">
                    <BarChart3 className="h-4 w-4" />
                    Annual Cost Breakdown
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-40 flex items-end gap-4 pt-4">
                    <div className="flex-1 flex flex-col items-center">
                      <div
                        className="w-full bg-red-500 rounded-t-sm"
                        style={{ height: `${(annualGridCost / 3000) * 100}px` }}
                      ></div>
                      <p className="text-xs mt-2">Grid</p>
                    </div>
                    <div className="flex-1 flex flex-col items-center">
                      <div
                        className="w-full bg-green-500 rounded-t-sm"
                        style={{ height: `${(annualSolarSavings / 3000) * 100}px` }}
                      ></div>
                      <p className="text-xs mt-2">Solar</p>
                    </div>
                    <div className="flex-1 flex flex-col items-center">
                      <div
                        className="w-full bg-blue-500 rounded-t-sm"
                        style={{ height: `${(annualBatterySavings / 3000) * 100}px` }}
                      ></div>
                      <p className="text-xs mt-2">Battery</p>
                    </div>
                    <div className="flex-1 flex flex-col items-center">
                      <div
                        className="w-full bg-purple-500 rounded-t-sm"
                        style={{ height: `${(annualNetCost / 3000) * 100}px` }}
                      ></div>
                      <p className="text-xs mt-2">Net</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="tenyear" className="pt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <Card className="bg-red-50 border-red-100">
                    <CardContent className="p-4">
                      <p className="text-sm font-medium text-red-800">10-Year Grid Cost</p>
                      <p className="text-2xl font-bold text-red-700">{formatCurrency(tenYearGridCost)}</p>
                    </CardContent>
                  </Card>
                  <Card className="bg-green-50 border-green-100">
                    <CardContent className="p-4">
                      <p className="text-sm font-medium text-green-800">10-Year Solar Savings</p>
                      <p className="text-2xl font-bold text-green-700">{formatCurrency(tenYearSolarSavings)}</p>
                    </CardContent>
                  </Card>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <Card className="bg-blue-50 border-blue-100">
                    <CardContent className="p-4">
                      <p className="text-sm font-medium text-blue-800">10-Year Battery Savings</p>
                      <p className="text-2xl font-bold text-blue-700">{formatCurrency(tenYearBatterySavings)}</p>
                    </CardContent>
                  </Card>
                  <Card className="bg-purple-50 border-purple-100">
                    <CardContent className="p-4">
                      <p className="text-sm font-medium text-purple-800">10-Year Net Cost</p>
                      <p className="text-2xl font-bold text-purple-700">{formatCurrency(tenYearNetCost)}</p>
                    </CardContent>
                  </Card>
                </div>
              </div>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base flex items-center gap-2">
                    <BarChart3 className="h-4 w-4" />
                    10-Year Cost Breakdown
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-40 flex items-end gap-4 pt-4">
                    <div className="flex-1 flex flex-col items-center">
                      <div
                        className="w-full bg-red-500 rounded-t-sm"
                        style={{ height: `${(tenYearGridCost / 30000) * 100}px` }}
                      ></div>
                      <p className="text-xs mt-2">Grid</p>
                    </div>
                    <div className="flex-1 flex flex-col items-center">
                      <div
                        className="w-full bg-green-500 rounded-t-sm"
                        style={{ height: `${(tenYearSolarSavings / 30000) * 100}px` }}
                      ></div>
                      <p className="text-xs mt-2">Solar</p>
                    </div>
                    <div className="flex-1 flex flex-col items-center">
                      <div
                        className="w-full bg-blue-500 rounded-t-sm"
                        style={{ height: `${(tenYearBatterySavings / 30000) * 100}px` }}
                      ></div>
                      <p className="text-xs mt-2">Battery</p>
                    </div>
                    <div className="flex-1 flex flex-col items-center">
                      <div
                        className="w-full bg-purple-500 rounded-t-sm"
                        style={{ height: `${(tenYearNetCost / 30000) * 100}px` }}
                      ></div>
                      <p className="text-xs mt-2">Net</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* ROI and Payback Period */}
        {costAnalysis.roi && costAnalysis.paybackPeriod && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
            <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-100">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-blue-800 mb-2">Return on Investment (ROI)</h3>
                <p className="text-3xl font-bold text-blue-700">{costAnalysis.roi.toFixed(1)}%</p>
                <p className="text-sm text-blue-600 mt-1">Annual return on investment</p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-green-50 to-teal-50 border-green-100">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-green-800 mb-2">Payback Period</h3>
                <p className="text-3xl font-bold text-green-700">{costAnalysis.paybackPeriod.toFixed(1)} years</p>
                <p className="text-sm text-green-600 mt-1">Time to recoup investment</p>
              </CardContent>
            </Card>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
