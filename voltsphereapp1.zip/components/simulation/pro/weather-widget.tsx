"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { SimulationConfig } from "@/lib/simulation/engine"
import { Cloud, Sun, Thermometer, MapPin } from "lucide-react"

interface WeatherWidgetProps {
  config: SimulationConfig
  onChange: (config: SimulationConfig) => void
  weatherData?: {
    temperature: number[]
    irradiance: number[]
    cloudCover: number[]
  }
}

export function WeatherWidget({ config, onChange, weatherData }: WeatherWidgetProps) {
  const updateConfig = (updates: Partial<SimulationConfig>) => {
    onChange({ ...config, ...updates })
  }

  const popularLocations = [
    { name: "Chicago, IL", lat: 41.8781, lng: -87.6298 },
    { name: "Los Angeles, CA", lat: 34.0522, lng: -118.2437 },
    { name: "New York, NY", lat: 40.7128, lng: -74.006 },
    { name: "Miami, FL", lat: 25.7617, lng: -80.1918 },
    { name: "Seattle, WA", lat: 47.6062, lng: -122.3321 },
    { name: "Phoenix, AZ", lat: 33.4484, lng: -112.074 },
  ]

  const handleLocationSelect = (locationName: string) => {
    const location = popularLocations.find((loc) => loc.name === locationName)
    if (location) {
      updateConfig({
        weatherLocation: location.name,
        location: { lat: location.lat, lng: location.lng },
      })
    }
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card className="card-enhanced">
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <MapPin className="h-5 w-5 text-blue-600" />
            Location Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <Label className="font-semibold">Weather Location</Label>
            <div className="flex gap-2 mt-2">
              <Input
                placeholder="e.g., Chicago, IL"
                value={config.weatherLocation || ""}
                onChange={(e) => updateConfig({ weatherLocation: e.target.value })}
              />
              <Button variant="outline">Search</Button>
            </div>
          </div>

          <div>
            <Label className="font-semibold">Popular Locations</Label>
            <Select onValueChange={handleLocationSelect}>
              <SelectTrigger className="mt-2">
                <SelectValue placeholder="Select a location" />
              </SelectTrigger>
              <SelectContent>
                {popularLocations.map((location) => (
                  <SelectItem key={location.name} value={location.name}>
                    {location.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl border-2 border-blue-200">
            <Label htmlFor="weather-toggle" className="flex items-center gap-2 cursor-pointer">
              <Cloud className="h-4 w-4 text-blue-600" />
              <span className="font-semibold text-blue-800">Use Real Weather Data</span>
            </Label>
            <Switch
              id="weather-toggle"
              checked={config.useRealWeather || false}
              onCheckedChange={(checked) => updateConfig({ useRealWeather: checked })}
              className="data-[state=checked]:bg-blue-600"
            />
          </div>

          {config.location && (
            <div className="p-4 bg-gray-50 rounded-lg">
              <p className="text-sm font-medium">Selected Location:</p>
              <p className="text-sm text-gray-600">
                {config.weatherLocation} (Lat: {config.location.lat.toFixed(4)}, Lng: {config.location.lng.toFixed(4)})
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="card-enhanced">
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <Cloud className="h-5 w-5 text-blue-600" />
            Weather Conditions
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {weatherData ? (
            <div className="space-y-6">
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <Thermometer className="h-8 w-8 mx-auto mb-2 text-red-500" />
                  <p className="text-sm font-medium">Avg. Temperature</p>
                  <p className="text-xl font-bold">
                    {(weatherData.temperature.reduce((a, b) => a + b, 0) / weatherData.temperature.length).toFixed(1)}°C
                  </p>
                </div>

                <div className="text-center p-4 bg-yellow-50 rounded-lg">
                  <Sun className="h-8 w-8 mx-auto mb-2 text-yellow-500" />
                  <p className="text-sm font-medium">Peak Irradiance</p>
                  <p className="text-xl font-bold">{Math.max(...weatherData.irradiance).toFixed(0)} W/m²</p>
                </div>

                <div className="text-center p-4 bg-gray-50 rounded-lg">
                  <Cloud className="h-8 w-8 mx-auto mb-2 text-gray-500" />
                  <p className="text-sm font-medium">Avg. Cloud Cover</p>
                  <p className="text-xl font-bold">
                    {(weatherData.cloudCover.reduce((a, b) => a + b, 0) / weatherData.cloudCover.length).toFixed(0)}%
                  </p>
                </div>
              </div>

              <div>
                <Label className="font-semibold">Daily Temperature Profile</Label>
                <div className="h-24 mt-2 flex items-end">
                  {weatherData.temperature.map((temp, i) => (
                    <div
                      key={i}
                      className="flex-1 bg-gradient-to-t from-blue-500 to-red-500 rounded-t"
                      style={{
                        height: `${((temp - 10) / 30) * 100}%`,
                        minHeight: "10%",
                        maxHeight: "100%",
                      }}
                      title={`Hour ${i}: ${temp.toFixed(1)}°C`}
                    ></div>
                  ))}
                </div>
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>12 AM</span>
                  <span>6 AM</span>
                  <span>12 PM</span>
                  <span>6 PM</span>
                  <span>12 AM</span>
                </div>
              </div>

              <div>
                <Label className="font-semibold">Solar Irradiance</Label>
                <div className="h-24 mt-2 flex items-end">
                  {weatherData.irradiance.map((irr, i) => (
                    <div
                      key={i}
                      className="flex-1 bg-gradient-to-t from-yellow-200 to-yellow-500 rounded-t"
                      style={{
                        height: `${(irr / 1000) * 100}%`,
                        minHeight: "0%",
                      }}
                      title={`Hour ${i}: ${irr.toFixed(0)} W/m²`}
                    ></div>
                  ))}
                </div>
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>12 AM</span>
                  <span>6 AM</span>
                  <span>12 PM</span>
                  <span>6 PM</span>
                  <span>12 AM</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-12">
              <Cloud className="h-16 w-16 mx-auto mb-4 text-gray-300" />
              <p className="text-gray-500">
                {config.useRealWeather
                  ? "Run the simulation to fetch weather data"
                  : "Enable real weather data to see conditions"}
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
