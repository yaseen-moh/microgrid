"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useAuth } from "@/lib/auth-context"
import { Zap, Loader2, CheckCircle } from "lucide-react"

interface LoginDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function LoginDialog({ open, onOpenChange }: LoginDialogProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [emailSent, setEmailSent] = useState(false)
  const { login, register } = useAuth()

  const [loginData, setLoginData] = useState({
    email: "",
    password: "",
  })

  const [registerData, setRegisterData] = useState({
    name: "",
    email: "",
    password: "",
  })

  const sendConfirmationEmail = async (email: string, type: string, name?: string) => {
    try {
      const response = await fetch("/api/auth/send-confirmation", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, type, name }),
      })

      const result = await response.json()
      if (result.success) {
        setEmailSent(true)
        console.log("Confirmation email sent to:", email)
      }
    } catch (error) {
      console.error("Failed to send confirmation email:", error)
    }
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")
    setEmailSent(false)

    try {
      const success = await login(loginData.email, loginData.password)
      if (success) {
        // Send confirmation email to the user
        await sendConfirmationEmail(loginData.email, "login")

        // Show success message briefly before closing
        setTimeout(() => {
          onOpenChange(false)
          setLoginData({ email: "", password: "" })
        }, 2000)
      } else {
        setError("Invalid email or password")
      }
    } catch (error) {
      setError("Login failed. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")
    setEmailSent(false)

    try {
      const success = await register(registerData.email, registerData.password, registerData.name)
      if (success) {
        // Send welcome email to the user
        await sendConfirmationEmail(registerData.email, "register", registerData.name)

        // Show success message briefly before closing
        setTimeout(() => {
          onOpenChange(false)
          setRegisterData({ name: "", email: "", password: "" })
        }, 2000)
      } else {
        setError("Registration failed. Please try again.")
      }
    } catch (error) {
      setError("Registration failed. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md bg-white border border-gray-200 shadow-2xl rounded-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader className="text-center pb-6">
          <div className="flex items-center justify-center gap-4 mb-4">
            <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg">
              <Zap className="h-6 w-6 text-white" />
            </div>
            <DialogTitle className="text-3xl font-bold text-gradient">VoltSphere</DialogTitle>
          </div>
          <DialogDescription className="text-gray-700 text-lg">
            Sign in to your account or create a new one to access energy simulation tools.
          </DialogDescription>
        </DialogHeader>

        {emailSent && (
          <div className="mb-6 p-4 bg-green-50 border-2 border-green-200 rounded-2xl">
            <div className="flex items-center justify-center gap-3">
              <CheckCircle className="h-6 w-6 text-green-600" />
              <p className="text-green-700 font-semibold text-center">Confirmation email sent to your inbox!</p>
            </div>
          </div>
        )}

        <Tabs defaultValue="login" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8 bg-gray-100 rounded-2xl p-2">
            <TabsTrigger
              value="login"
              className="font-semibold text-gray-800 data-[state=active]:bg-white data-[state=active]:text-blue-600 rounded-xl py-3"
            >
              Sign In
            </TabsTrigger>
            <TabsTrigger
              value="register"
              className="font-semibold text-gray-800 data-[state=active]:bg-white data-[state=active]:text-blue-600 rounded-xl py-3"
            >
              Sign Up
            </TabsTrigger>
          </TabsList>

          <TabsContent value="login" className="space-y-6">
            <form onSubmit={handleLogin} className="space-y-6">
              <div className="space-y-3">
                <Label htmlFor="login-email" className="text-lg font-semibold text-gray-800">
                  Email Address
                </Label>
                <Input
                  id="login-email"
                  type="email"
                  placeholder="Enter your email"
                  value={loginData.email}
                  onChange={(e) => setLoginData({ ...loginData, email: e.target.value })}
                  className="input-clean h-14 text-lg"
                  required
                />
              </div>

              <div className="space-y-3">
                <Label htmlFor="login-password" className="text-lg font-semibold text-gray-800">
                  Password
                </Label>
                <Input
                  id="login-password"
                  type="password"
                  placeholder="Enter your password"
                  value={loginData.password}
                  onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                  className="input-clean h-14 text-lg"
                  required
                />
              </div>

              {error && (
                <div className="p-4 bg-red-50 border-2 border-red-200 rounded-2xl">
                  <p className="text-red-700 font-semibold text-center">{error}</p>
                </div>
              )}

              <Button type="submit" className="w-full h-14 btn-primary text-lg" disabled={isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="mr-3 h-5 w-5 animate-spin" />
                    Signing In...
                  </>
                ) : (
                  "Sign In"
                )}
              </Button>
            </form>
          </TabsContent>

          <TabsContent value="register" className="space-y-6">
            <form onSubmit={handleRegister} className="space-y-6">
              <div className="space-y-3">
                <Label htmlFor="register-name" className="text-lg font-semibold text-gray-800">
                  Full Name
                </Label>
                <Input
                  id="register-name"
                  type="text"
                  placeholder="Enter your full name"
                  value={registerData.name}
                  onChange={(e) => setRegisterData({ ...registerData, name: e.target.value })}
                  className="input-clean h-14 text-lg"
                  required
                />
              </div>

              <div className="space-y-3">
                <Label htmlFor="register-email" className="text-lg font-semibold text-gray-800">
                  Email Address
                </Label>
                <Input
                  id="register-email"
                  type="email"
                  placeholder="Enter your email"
                  value={registerData.email}
                  onChange={(e) => setRegisterData({ ...registerData, email: e.target.value })}
                  className="input-clean h-14 text-lg"
                  required
                />
              </div>

              <div className="space-y-3">
                <Label htmlFor="register-password" className="text-lg font-semibold text-gray-800">
                  Password
                </Label>
                <Input
                  id="register-password"
                  type="password"
                  placeholder="Create a secure password"
                  value={registerData.password}
                  onChange={(e) => setRegisterData({ ...registerData, password: e.target.value })}
                  className="input-clean h-14 text-lg"
                  required
                />
              </div>

              {error && (
                <div className="p-4 bg-red-50 border-2 border-red-200 rounded-2xl">
                  <p className="text-red-700 font-semibold text-center">{error}</p>
                </div>
              )}

              <Button type="submit" className="w-full h-14 btn-primary text-lg" disabled={isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="mr-3 h-5 w-5 animate-spin" />
                    Creating Account...
                  </>
                ) : (
                  "Create Account"
                )}
              </Button>
            </form>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
