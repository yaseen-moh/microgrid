"use client"

import { useState } from "react"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { SiteHeader } from "@/components/site-header"
import { Zap, Star, Crown, Code, Building } from "lucide-react"
import { useAuth } from "@/lib/auth-context"

export default function SimulationsPage() {
  const { user } = useAuth()
  const [selectedSim, setSelectedSim] = useState<string>("")

  // Determine user access level
  const userTier = user?.subscriptionTier || "free"
  const hasAccess = (requiredTier: string): boolean => {
    if (!user) return requiredTier === "free"

    const tierHierarchy: { [key: string]: string[] } = {
      free: ["free"],
      pro: ["free", "pro"],
      growth: ["free", "pro", "growth"],
      enterprise: ["free", "pro", "growth", "enterprise"],
    }

    const userAccess = tierHierarchy[userTier] || ["free"]
    return userAccess.includes(requiredTier)
  }

  const simulations = [
    {
      id: "free",
      name: "Free Simulation",
      icon: Zap,
      href: "/simulation",
      requiredTier: "free",
    },
    {
      id: "pro",
      name: "Pro Simulation",
      icon: Star,
      href: "/simulation/pro",
      requiredTier: "pro",
    },
    {
      id: "growth",
      name: "Growth Simulation",
      icon: Building,
      href: "/simulation/growth",
      requiredTier: "growth",
    },
    {
      id: "api",
      name: "API Access",
      icon: Code,
      href: "/simulation/api",
      requiredTier: "growth",
    },
    {
      id: "enterprise",
      name: "Enterprise Suite",
      icon: Crown,
      href: "/simulation/enterprise",
      requiredTier: "enterprise",
    },
  ]

  const handleSimulationClick = (sim: any) => {
    if (hasAccess(sim.requiredTier)) {
      window.location.href = sim.href
    }
  }

  return (
    <div className="min-h-screen bg-gradient-primary">
      <SiteHeader />

      <section className="section-spacing">
        <div className="container-clean">
          <div className="text-center mb-20 animate-fade-in">
            <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 mb-8">
              Choose Your <span className="text-gradient">Simulation</span>
            </h1>
            <p className="text-2xl text-gray-700 max-w-4xl mx-auto leading-relaxed">
              Select the simulation tier that fits your needs. Upgrade anytime to unlock more advanced features and
              capabilities.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-8 lg:gap-12 max-w-6xl mx-auto stagger-children">
            {simulations.map((sim) => {
              const available = hasAccess(sim.requiredTier)

              return (
                <Card
                  key={sim.id}
                  className={`card-enhanced text-center transition-smooth ${
                    available
                      ? "cursor-pointer hover:scale-110 hover:shadow-2xl"
                      : "opacity-50 cursor-not-allowed bg-gray-100/50"
                  } ${selectedSim === sim.id ? "ring-4 ring-blue-500 ring-offset-4" : ""}`}
                  onClick={() => {
                    setSelectedSim(sim.id)
                    if (available) {
                      setTimeout(() => handleSimulationClick(sim), 300)
                    }
                  }}
                >
                  <CardContent className="p-10">
                    <div className="flex justify-center mb-8">
                      <div
                        className={`w-20 h-20 rounded-3xl flex items-center justify-center shadow-xl transition-smooth ${
                          available ? "bg-gradient-to-r from-blue-600 to-purple-600 hover:scale-110" : "bg-gray-300"
                        }`}
                      >
                        <sim.icon className={`h-10 w-10 ${available ? "text-white" : "text-gray-500"}`} />
                      </div>
                    </div>
                    <h3 className={`text-xl font-bold mb-4 ${available ? "text-gray-900" : "text-gray-500"}`}>
                      {sim.name}
                    </h3>
                    {!available && (
                      <div className="px-4 py-2 bg-gray-200 rounded-xl">
                        <p className="text-sm text-gray-600 font-medium">Upgrade Required</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )
            })}
          </div>

          {/* Current Plan Display */}
          <div className="text-center mt-20">
            <div className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-blue-50 to-purple-50 border-2 border-blue-200 rounded-2xl shadow-lg">
              <span className="text-blue-800 font-bold text-xl">
                Current Plan: <span className="text-gradient capitalize text-2xl">{userTier}</span>
              </span>
            </div>
          </div>

          {/* Upgrade CTA */}
          {userTier === "free" && (
            <div className="text-center mt-12 animate-fade-in">
              <Link
                href="/pricing"
                className="inline-flex items-center px-10 py-5 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-bold rounded-2xl hover:scale-105 transition-smooth text-xl shadow-xl hover:shadow-2xl"
              >
                Upgrade to Access More Simulations
              </Link>
            </div>
          )}
        </div>
      </section>
    </div>
  )
}
