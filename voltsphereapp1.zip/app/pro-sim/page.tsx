"use client"

import { useState } from "react"

export default function ProSimulationStandalone() {
  const [batteryCapacity, setBatteryCapacity] = useState(15)
  const [batteryEfficiency, setBatteryEfficiency] = useState(92)
  const [batteryType, setBatteryType] = useState("lithium")
  const [loadProfile, setLoadProfile] = useState("residential")
  const [solarEnabled, setSolarEnabled] = useState(true)
  const [weatherEnabled, setWeatherEnabled] = useState(false)
  const [timeOfUseEnabled, setTimeOfUseEnabled] = useState(false)
  const [isRunning, setIsRunning] = useState(false)
  const [simulationData, setSimulationData] = useState<any>(null)
  const [activeTab, setActiveTab] = useState("simulation")

  const runSimulation = () => {
    setIsRunning(true)

    setTimeout(() => {
      const hours = Array.from({ length: 24 }, (_, i) => `${i}:00`)
      const solarProfile = hours.map((_, i) => {
        if (i < 6 || i > 19) return 0
        return Math.max(
          0,
          Math.sin(((i - 6) * Math.PI) / 13) *
            (batteryCapacity * 0.8) *
            (weatherEnabled ? 0.7 + Math.random() * 0.3 : 1),
        )
      })

      const loadProfile = hours.map((_, i) => {
        const baseLoad = batteryCapacity * 0.3
        const peakMultiplier = i >= 17 && i <= 22 ? 1.8 : i >= 6 && i <= 9 ? 1.4 : 1
        return baseLoad * peakMultiplier * (0.8 + Math.random() * 0.4)
      })

      const batteryStorage = hours.map((_, i) => {
        return Math.max(0, Math.min(batteryCapacity, batteryCapacity * (0.3 + 0.4 * Math.sin((i * Math.PI) / 12))))
      })

      const gridUsage = hours.map((_, i) => {
        return Math.max(0, loadProfile[i] - (solarEnabled ? solarProfile[i] : 0))
      })

      setSimulationData({
        hours,
        solar: solarProfile,
        consumption: loadProfile,
        battery: batteryStorage,
        grid: gridUsage,
      })

      setIsRunning(false)
    }, 1500)
  }

  const SimpleChart = ({ data }: { data: any }) => {
    if (!data) return null

    const maxValue = Math.max(...data.solar, ...data.consumption, ...data.battery, ...data.grid)

    return (
      <div className="w-full h-80 bg-white rounded-lg border p-4">
        <h3 className="text-lg font-semibold mb-4">Energy Flow (kW)</h3>
        <div className="relative h-64">
          <svg width="100%" height="100%" viewBox="0 0 800 200">
            {/* Grid lines */}
            {[0, 1, 2, 3, 4].map((i) => (
              <line key={i} x1="0" y1={i * 40} x2="800" y2={i * 40} stroke="#e5e7eb" strokeWidth="1" />
            ))}

            {/* Solar line */}
            <polyline
              fill="none"
              stroke="#f59e0b"
              strokeWidth="3"
              points={data.hours.map((_, i) => `${(i * 800) / 24},${200 - (data.solar[i] / maxValue) * 180}`).join(" ")}
            />

            {/* Consumption line */}
            <polyline
              fill="none"
              stroke="#ef4444"
              strokeWidth="3"
              points={data.hours
                .map((_, i) => `${(i * 800) / 24},${200 - (data.consumption[i] / maxValue) * 180}`)
                .join(" ")}
            />

            {/* Battery line */}
            <polyline
              fill="none"
              stroke="#10b981"
              strokeWidth="3"
              points={data.hours
                .map((_, i) => `${(i * 800) / 24},${200 - (data.battery[i] / maxValue) * 180}`)
                .join(" ")}
            />

            {/* Grid line */}
            <polyline
              fill="none"
              stroke="#6366f1"
              strokeWidth="3"
              points={data.hours.map((_, i) => `${(i * 800) / 24},${200 - (data.grid[i] / maxValue) * 180}`).join(" ")}
            />
          </svg>
        </div>

        <div className="flex justify-center gap-6 mt-4 text-sm">
          <div className="flex items-center gap-2">
            <div className="w-4 h-1 bg-yellow-500"></div>
            <span>Solar</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-1 bg-red-500"></div>
            <span>Consumption</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-1 bg-green-500"></div>
            <span>Battery</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-1 bg-indigo-500"></div>
            <span>Grid</span>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold">V</span>
              </div>
              <h1 className="text-2xl font-bold text-gray-800">VoltSphere Pro</h1>
              <span className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-3 py-1 rounded-full text-sm font-semibold">
                PRO
              </span>
            </div>
            <a href="/" className="text-gray-600 hover:text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-100">
              Back to Home
            </a>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">Pro Simulation Suite</h2>
          <p className="text-lg text-gray-600 max-w-4xl mx-auto">
            Advanced microgrid simulation with weather integration, multiple battery types, and comprehensive analytics.
          </p>
        </div>

        {/* Tabs */}
        <div className="flex justify-center mb-8">
          <div className="bg-white rounded-lg p-1 shadow-sm border">
            {[
              { id: "simulation", label: "Simulation" },
              { id: "advanced", label: "Advanced" },
              { id: "analytics", label: "Analytics" },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-6 py-3 rounded-md font-medium transition-all ${
                  activeTab === tab.id
                    ? "bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-md"
                    : "text-gray-600 hover:text-gray-800 hover:bg-gray-50"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Simulation Tab */}
        {activeTab === "simulation" && (
          <div className="grid lg:grid-cols-4 gap-6">
            <div className="lg:col-span-1">
              <div className="bg-white rounded-xl shadow-lg border p-6">
                <h3 className="text-xl font-semibold mb-6 flex items-center gap-2">Pro Controls</h3>

                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Battery Capacity: {batteryCapacity} kWh
                    </label>
                    <input
                      type="range"
                      min="5"
                      max="100"
                      value={batteryCapacity}
                      onChange={(e) => setBatteryCapacity(Number(e.target.value))}
                      className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Battery Type</label>
                    <select
                      value={batteryType}
                      onChange={(e) => setBatteryType(e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    >
                      <option value="lithium">Lithium-ion (92% efficiency)</option>
                      <option value="lead-acid">Lead-acid (85% efficiency)</option>
                      <option value="flow">Flow Battery (88% efficiency)</option>
                      <option value="sodium">Sodium-ion (90% efficiency)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Battery Efficiency: {batteryEfficiency}%
                    </label>
                    <input
                      type="range"
                      min="70"
                      max="98"
                      value={batteryEfficiency}
                      onChange={(e) => setBatteryEfficiency(Number(e.target.value))}
                      className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Load Profile</label>
                    <select
                      value={loadProfile}
                      onChange={(e) => setLoadProfile(e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    >
                      <option value="residential">Residential Home</option>
                      <option value="commercial">Commercial Building</option>
                      <option value="industrial">Industrial Facility</option>
                    </select>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-xl">
                    <label className="flex items-center gap-2 font-semibold text-yellow-800">Solar Power</label>
                    <input
                      type="checkbox"
                      checked={solarEnabled}
                      onChange={(e) => setSolarEnabled(e.target.checked)}
                      className="w-5 h-5 text-yellow-600 rounded focus:ring-yellow-500"
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl">
                    <label className="flex items-center gap-2 font-semibold text-blue-800">Real Weather Data</label>
                    <input
                      type="checkbox"
                      checked={weatherEnabled}
                      onChange={(e) => setWeatherEnabled(e.target.checked)}
                      className="w-5 h-5 text-blue-600 rounded focus:ring-blue-500"
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 bg-gradient-to-r from-green-50 to-teal-50 rounded-xl">
                    <label className="flex items-center gap-2 font-semibold text-green-800">Time-of-Use Rates</label>
                    <input
                      type="checkbox"
                      checked={timeOfUseEnabled}
                      onChange={(e) => setTimeOfUseEnabled(e.target.checked)}
                      className="w-5 h-5 text-green-600 rounded focus:ring-green-500"
                    />
                  </div>

                  <button
                    onClick={runSimulation}
                    disabled={isRunning}
                    className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-bold py-4 px-6 rounded-xl transition-all transform hover:scale-105 disabled:opacity-50 disabled:transform-none"
                  >
                    {isRunning ? "Running Pro Simulation..." : "Run Pro Simulation"}
                  </button>
                </div>
              </div>
            </div>

            <div className="lg:col-span-3">
              {simulationData ? (
                <div className="bg-white rounded-xl shadow-lg border p-6">
                  <h3 className="text-xl font-semibold mb-4">Pro Simulation Results</h3>
                  <p className="text-gray-600 mb-6">
                    {batteryType} battery • {batteryCapacity}kWh capacity • {batteryEfficiency}% efficiency
                  </p>
                  <SimpleChart data={simulationData} />
                </div>
              ) : (
                <div className="bg-white rounded-xl shadow-lg border p-6 flex items-center justify-center h-96">
                  <div className="text-center">
                    {isRunning ? (
                      <>
                        <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-purple-600 mx-auto mb-4"></div>
                        <h3 className="text-xl font-semibold text-gray-600 mb-2">Running Pro Simulation...</h3>
                        <p className="text-gray-500">Calculating advanced energy flows with weather data</p>
                      </>
                    ) : (
                      <>
                        <div className="text-6xl mb-4">⚡</div>
                        <h3 className="text-xl font-semibold text-gray-600 mb-2">Ready for Pro Simulation</h3>
                        <p className="text-gray-500">Configure your advanced settings and run the simulation</p>
                      </>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Advanced Tab */}
        {activeTab === "advanced" && (
          <div className="bg-white rounded-xl shadow-lg border p-6">
            <h3 className="text-xl font-semibold mb-6">Advanced Configuration</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Weather Location</label>
                <select className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                  <option>San Francisco, CA</option>
                  <option>New York, NY</option>
                  <option>Chicago, IL</option>
                  <option>Austin, TX</option>
                  <option>Miami, FL</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Simulation Duration</label>
                <select className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                  <option>24 Hours</option>
                  <option>7 Days</option>
                  <option>30 Days</option>
                  <option>1 Year</option>
                </select>
              </div>
            </div>
          </div>
        )}

        {/* Analytics Tab */}
        {activeTab === "analytics" && (
          <div className="bg-white rounded-xl shadow-lg border p-6">
            <h3 className="text-xl font-semibold mb-6">Pro Cost Analysis</h3>
            {simulationData ? (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-blue-50 p-6 rounded-lg border border-blue-100">
                    <h4 className="text-lg font-semibold text-blue-700 mb-2">Daily Savings</h4>
                    <p className="text-3xl font-bold text-blue-800">${Math.round(batteryCapacity * 0.15)}</p>
                    <p className="text-sm text-blue-600 mt-1">From solar and battery optimization</p>
                  </div>
                  <div className="bg-green-50 p-6 rounded-lg border border-green-100">
                    <h4 className="text-lg font-semibold text-green-700 mb-2">Monthly Savings</h4>
                    <p className="text-3xl font-bold text-green-800">${Math.round(batteryCapacity * 0.15 * 30)}</p>
                    <p className="text-sm text-green-600 mt-1">Projected for 30 days</p>
                  </div>
                  <div className="bg-purple-50 p-6 rounded-lg border border-purple-100">
                    <h4 className="text-lg font-semibold text-purple-700 mb-2">Annual Savings</h4>
                    <p className="text-3xl font-bold text-purple-800">${Math.round(batteryCapacity * 0.15 * 365)}</p>
                    <p className="text-sm text-purple-600 mt-1">Projected for 365 days</p>
                  </div>
                </div>

                <div className="bg-gray-50 p-6 rounded-lg border border-gray-200">
                  <h4 className="text-lg font-semibold text-gray-700 mb-4">Advanced ROI Analysis</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">System Cost ({batteryType})</span>
                      <span className="font-semibold">${(batteryCapacity * 1200).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Annual Savings</span>
                      <span className="font-semibold text-green-600">
                        ${Math.round(batteryCapacity * 0.15 * 365).toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Payback Period</span>
                      <span className="font-semibold">
                        {Math.round((batteryCapacity * 1200) / (batteryCapacity * 0.15 * 365))} years
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">10-Year Net Savings</span>
                      <span className="font-semibold text-green-600">
                        ${Math.round(batteryCapacity * 0.15 * 365 * 10 - batteryCapacity * 1200).toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Carbon Offset (Annual)</span>
                      <span className="font-semibold text-green-600">{Math.round(batteryCapacity * 2.5)} tons CO₂</span>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-center h-64">
                <div className="text-center">
                  <div className="text-6xl mb-4">📊</div>
                  <p className="text-gray-500">Run a Pro simulation to see advanced cost analytics</p>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
