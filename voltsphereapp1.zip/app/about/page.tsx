"use client"

import { SiteHeader } from "@/components/site-header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Heart, Users, Lightbulb, Target, ArrowRight, Zap } from "lucide-react"

export default function AboutPage() {
  const values = [
    {
      icon: <Heart className="h-8 w-8 text-red-500" />,
      title: "Simple & Friendly",
      description:
        "We believe energy planning shouldn't be complicated. Our tools are designed to be intuitive and accessible for everyone, from beginners to experts.",
    },
    {
      icon: <Users className="h-8 w-8 text-blue-500" />,
      title: "For Everyone",
      description:
        "Whether you're a homeowner planning solar installation or an energy professional designing microgrids, our platform scales to meet your specific needs.",
    },
    {
      icon: <Lightbulb className="h-8 w-8 text-yellow-500" />,
      title: "Innovation First",
      description:
        "We're constantly improving our simulation engine with the latest AI and machine learning technologies to give you the most accurate and reliable results.",
    },
    {
      icon: <Target className="h-8 w-8 text-green-500" />,
      title: "Results Focused",
      description:
        "Every feature we build is designed to help you make better energy decisions, reduce costs, and optimize performance for maximum efficiency.",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-primary">
      <SiteHeader />

      {/* Hero Section */}
      <section className="section-spacing">
        <div className="container-clean">
          <div className="text-center max-w-5xl mx-auto content-spacing animate-fade-in">
            <div className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-blue-100 to-purple-100 border border-blue-200 rounded-2xl mb-12">
              <span className="text-blue-800 font-bold text-xl">About VoltSphere</span>
            </div>

            <h1 className="text-5xl lg:text-7xl font-bold mb-12 text-gray-900 leading-tight">
              Making Energy Planning
              <span className="text-gradient block mt-4">Simple & Powerful</span>
            </h1>

            <p className="text-2xl lg:text-3xl text-gray-700 leading-relaxed max-w-4xl mx-auto">
              We started VoltSphere because energy planning was too complicated. Our mission is to make clean energy
              accessible to everyone through simple, powerful, and intelligent simulation tools.
            </p>
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="section-spacing bg-gradient-secondary">
        <div className="container-clean">
          <div className="grid lg:grid-cols-2 gap-16 lg:gap-24 items-center">
            <div className="content-spacing animate-slide-up">
              <h2 className="text-4xl lg:text-5xl font-bold mb-12 text-gray-900">Our Story</h2>
              <div className="space-y-8 text-gray-700 leading-relaxed">
                <p className="text-xl lg:text-2xl">
                  Energy simulation used to require expensive software and weeks of training. We thought there had to be
                  a better way to democratize access to these powerful tools.
                </p>
                <p className="text-xl lg:text-2xl">
                  So we built VoltSphere - a platform that makes energy modeling as easy as using a calculator. No
                  complex setup, no confusing interfaces, just results you can understand and act upon immediately.
                </p>
                <p className="text-xl lg:text-2xl">
                  Today, thousands of people use VoltSphere to plan everything from home solar systems to large
                  commercial microgrids. And we're just getting started on our journey to transform the energy industry!
                </p>
              </div>
            </div>

            <div className="animate-scale-in">
              <Card className="border-0 shadow-2xl bg-gradient-to-br from-blue-600 to-purple-600 text-white rounded-3xl">
                <CardContent className="p-12 text-center">
                  <div className="space-y-12">
                    <div>
                      <div className="text-5xl lg:text-6xl font-bold mb-4">10,000+</div>
                      <div className="text-xl opacity-90">Happy Users Worldwide</div>
                    </div>
                    <div>
                      <div className="text-5xl lg:text-6xl font-bold mb-4">50,000+</div>
                      <div className="text-xl opacity-90">Simulations Completed</div>
                    </div>
                    <div>
                      <div className="text-5xl lg:text-6xl font-bold mb-4">99%</div>
                      <div className="text-xl opacity-90">Customer Satisfaction</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="section-spacing bg-gradient-accent">
        <div className="container-clean">
          <div className="text-center mb-20 animate-fade-in">
            <h2 className="text-4xl lg:text-5xl font-bold mb-8 text-gray-900">What We Believe</h2>
            <p className="text-2xl text-gray-700 max-w-4xl mx-auto leading-relaxed">
              Our core values guide everything we do, from product design to customer support, ensuring we deliver the
              best possible experience.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-16 stagger-children">
            {values.map((value, index) => (
              <Card key={index} className="card-enhanced hover-lift">
                <CardHeader className="p-10">
                  <div className="flex items-center gap-6 mb-6">
                    <div className="w-16 h-16 rounded-2xl bg-gray-50 flex items-center justify-center shadow-lg">
                      {value.icon}
                    </div>
                    <CardTitle className="text-2xl lg:text-3xl font-bold text-gray-900">{value.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="px-10 pb-10">
                  <p className="text-gray-700 leading-relaxed text-lg lg:text-xl">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-spacing bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600">
        <div className="container-clean">
          <div className="text-center text-white max-w-5xl mx-auto content-spacing animate-fade-in">
            <h2 className="text-4xl lg:text-5xl font-bold mb-8">Ready to Try VoltSphere?</h2>
            <p className="text-2xl lg:text-3xl mb-16 opacity-90 leading-relaxed">
              Join thousands of people who've simplified their energy planning with our powerful and intuitive platform.
            </p>
            <div className="flex flex-col sm:flex-row gap-8 justify-center">
              <Button
                asChild
                size="lg"
                className="bg-white text-blue-600 hover:bg-gray-100 font-bold px-12 py-6 rounded-2xl text-xl shadow-xl hover:shadow-2xl transition-smooth"
              >
                <Link href="/simulations">
                  Start Free Trial
                  <ArrowRight className="ml-3 h-6 w-6" />
                </Link>
              </Button>
              <Button
                asChild
                variant="outline"
                size="lg"
                className="border-2 border-white text-white hover:bg-white hover:text-blue-600 font-bold px-12 py-6 rounded-2xl text-xl transition-smooth"
              >
                <Link href="/contact">Contact Us</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white section-spacing-sm">
        <div className="container-clean">
          <div className="grid md:grid-cols-4 gap-12 mb-12">
            <div className="space-y-6">
              <div className="flex items-center space-x-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-r from-blue-600 to-purple-600">
                  <Zap className="h-6 w-6 text-white" />
                </div>
                <span className="text-2xl font-bold">VoltSphere</span>
              </div>
              <p className="text-gray-400 text-lg leading-relaxed">
                Advanced energy simulation and optimization platform for professionals worldwide.
              </p>
            </div>

            <div>
              <h3 className="font-bold mb-6 text-xl">Product</h3>
              <ul className="space-y-3 text-gray-400">
                <li>
                  <Link href="/simulations" className="hover:text-white transition-smooth text-lg">
                    Simulations
                  </Link>
                </li>
                <li>
                  <Link href="/pricing" className="hover:text-white transition-smooth text-lg">
                    Pricing
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-bold mb-6 text-xl">Company</h3>
              <ul className="space-y-3 text-gray-400">
                <li>
                  <Link href="/about" className="hover:text-white transition-smooth text-lg">
                    About
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="hover:text-white transition-smooth text-lg">
                    Contact
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-bold mb-6 text-xl">Support</h3>
              <ul className="space-y-3 text-gray-400">
                <li>
                  <Link href="/help" className="hover:text-white transition-smooth text-lg">
                    Help Center
                  </Link>
                </li>
                <li>
                  <Link href="/docs" className="hover:text-white transition-smooth text-lg">
                    Documentation
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-8 text-center text-gray-400">
            <p className="text-lg">&copy; 2024 VoltSphere. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
