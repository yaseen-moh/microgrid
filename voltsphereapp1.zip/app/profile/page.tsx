"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useAuth } from "@/lib/auth-context"
import { User, Settings, CreditCard, Star, Zap, Code } from "lucide-react"

export default function ProfilePage() {
  const { user, isLoading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    // Redirect if not logged in
    if (!isLoading && !user) {
      router.push("/")
    }
  }, [user, isLoading, router])

  if (isLoading) {
    return <div className="flex justify-center items-center h-screen">Loading...</div>
  }

  if (!user) {
    return null // Will redirect in useEffect
  }

  const getSubscriptionDetails = () => {
    switch (user.subscriptionTier) {
      case "pro":
        return {
          name: "Pro",
          description: "Advanced simulation with weather integration and project management",
          badge: <Badge className="bg-gradient-to-r from-blue-600 to-purple-600">Pro</Badge>,
          icon: <Star className="h-5 w-5 text-purple-600" />,
        }
      case "starter":
        return {
          name: "Starter API",
          description: "API access with 5,000 calls per month",
          badge: <Badge className="bg-gradient-to-r from-green-600 to-blue-600">Starter API</Badge>,
          icon: <Code className="h-5 w-5 text-green-600" />,
        }
      case "growth":
        return {
          name: "Growth API",
          description: "Enhanced API access with 50,000 calls per month",
          badge: <Badge className="bg-gradient-to-r from-purple-600 to-pink-600">Growth API</Badge>,
          icon: <Code className="h-5 w-5 text-pink-600" />,
        }
      case "enterprise":
        return {
          name: "Enterprise",
          description: "Full access to all features with unlimited API calls",
          badge: <Badge className="bg-gradient-to-r from-yellow-600 to-red-600">Enterprise</Badge>,
          icon: <Star className="h-5 w-5 text-yellow-600" />,
        }
      default:
        return {
          name: "Free",
          description: "Basic simulation with limited features",
          badge: <Badge variant="outline">Free</Badge>,
          icon: <Zap className="h-5 w-5 text-gray-600" />,
        }
    }
  }

  const subscriptionDetails = getSubscriptionDetails()

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      {/* Header */}
      <header className="glass-effect border-b sticky top-0 z-40 backdrop-enhanced">
        <nav className="container mx-auto mobile-padding py-3 sm:py-4 flex justify-between items-center">
          <div className="text-xl sm:text-2xl font-bold gradient-text font-display">My Profile</div>
          <Button variant="outline" onClick={() => router.push("/")}>
            Back to Home
          </Button>
        </nav>
      </header>

      <div className="container mx-auto mobile-padding py-8">
        <div className="max-w-3xl mx-auto">
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <User className="h-5 w-5 text-blue-600" />
                Account Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <div className="text-sm text-gray-500">Name</div>
                  <div className="font-medium">{user.name || "Not provided"}</div>
                </div>
                <div>
                  <div className="text-sm text-gray-500">Email</div>
                  <div className="font-medium">{user.email}</div>
                </div>
                <div>
                  <div className="text-sm text-gray-500">Account Type</div>
                  <div className="font-medium flex items-center gap-2">
                    {user.role === "admin" ? "Administrator" : "User"}
                    {user.role === "admin" && <Badge className="bg-red-600">Admin</Badge>}
                  </div>
                </div>
                <div>
                  <div className="text-sm text-gray-500">Member Since</div>
                  <div className="font-medium">June 10, 2024</div>
                </div>
              </div>

              <div className="flex justify-end">
                <Button variant="outline" className="flex items-center gap-2">
                  <Settings className="h-4 w-4" />
                  Edit Profile
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                {subscriptionDetails.icon}
                Subscription
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xl font-semibold flex items-center gap-2">
                    {subscriptionDetails.name} Plan
                    {subscriptionDetails.badge}
                  </div>
                  <div className="text-gray-500">{subscriptionDetails.description}</div>
                </div>

                {user.subscriptionTier === "free" && (
                  <Button
                    className="bg-gradient-to-r from-blue-600 to-purple-600"
                    onClick={() => router.push("/pricing")}
                  >
                    Upgrade
                  </Button>
                )}
              </div>

              {user.subscriptionTier !== "free" && (
                <div className="border-t pt-4 mt-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <div className="font-medium">Billing Information</div>
                      <div className="text-sm text-gray-500">Your next payment is on July 10, 2024</div>
                    </div>
                    <Button
                      variant="outline"
                      className="flex items-center gap-2"
                      onClick={() => router.push("/billing")}
                    >
                      <CreditCard className="h-4 w-4" />
                      Manage Billing
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Simulation Access</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Button
                  variant="outline"
                  className="flex items-center gap-2 justify-center h-auto py-4"
                  onClick={() => router.push("/simulation")}
                >
                  <Zap className="h-4 w-4" />
                  Basic Simulation
                </Button>

                <Button
                  variant={
                    user.subscriptionTier === "pro" || user.subscriptionTier === "enterprise" || user.role === "admin"
                      ? "outline"
                      : "ghost"
                  }
                  className="flex items-center gap-2 justify-center h-auto py-4"
                  disabled={
                    !(
                      user.subscriptionTier === "pro" ||
                      user.subscriptionTier === "enterprise" ||
                      user.role === "admin"
                    )
                  }
                  onClick={() => router.push("/simulation/pro")}
                >
                  <Star className="h-4 w-4" />
                  Pro Simulation
                  {!(
                    user.subscriptionTier === "pro" ||
                    user.subscriptionTier === "enterprise" ||
                    user.role === "admin"
                  ) && (
                    <Badge variant="outline" className="ml-2">
                      Locked
                    </Badge>
                  )}
                </Button>

                <Button
                  variant={
                    user.subscriptionTier === "starter" ||
                    user.subscriptionTier === "growth" ||
                    user.subscriptionTier === "enterprise" ||
                    user.role === "admin"
                      ? "outline"
                      : "ghost"
                  }
                  className="flex items-center gap-2 justify-center h-auto py-4"
                  disabled={
                    !(
                      user.subscriptionTier === "starter" ||
                      user.subscriptionTier === "growth" ||
                      user.subscriptionTier === "enterprise" ||
                      user.role === "admin"
                    )
                  }
                  onClick={() => router.push("/simulation/api")}
                >
                  <Code className="h-4 w-4" />
                  API Playground
                  {!(
                    user.subscriptionTier === "starter" ||
                    user.subscriptionTier === "growth" ||
                    user.subscriptionTier === "enterprise" ||
                    user.role === "admin"
                  ) && (
                    <Badge variant="outline" className="ml-2">
                      Locked
                    </Badge>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
