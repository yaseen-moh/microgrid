"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { SiteHeader } from "@/components/site-header"
import { Zap, BarChart3, Shield, Battery, ArrowRight, CheckCircle, Users, TrendingUp, Award } from "lucide-react"

export default function HomePage() {
  const features = [
    {
      icon: BarChart3,
      title: "Advanced Analytics",
      description:
        "Real-time monitoring and predictive analytics for optimal energy management and performance tracking",
    },
    {
      icon: Shield,
      title: "Enterprise Security",
      description: "Bank-grade security with end-to-end encryption and compliance standards for your data protection",
    },
    {
      icon: Battery,
      title: "Smart Storage",
      description: "Intelligent battery management with predictive charging and discharging optimization algorithms",
    },
  ]

  const stats = [
    { icon: Users, value: "10,000+", label: "Active Users" },
    { icon: Zap, value: "50MW", label: "Energy Managed" },
    { icon: TrendingUp, value: "35%", label: "Efficiency Gain" },
    { icon: Award, value: "99.9%", label: "Uptime" },
  ]

  const plans = [
    {
      name: "Free",
      description: "Perfect for getting started with basic simulations",
      features: ["Basic simulations", "Standard components", "Community support", "Export to PDF"],
      href: "/simulation/starter",
    },
    {
      name: "Professional",
      description: "Advanced features for energy professionals",
      features: [
        "Advanced analytics",
        "Custom components",
        "Priority support",
        "Export capabilities",
        "Weather data",
        "Cost analysis",
      ],
      href: "/simulation/pro",
      popular: true,
    },
    {
      name: "Enterprise",
      description: "Full-scale enterprise solutions with unlimited access",
      features: [
        "Unlimited simulations",
        "API access",
        "Custom integrations",
        "Dedicated support",
        "White-label options",
        "Advanced AI",
      ],
      href: "/simulation/enterprise",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-primary">
      <SiteHeader />

      {/* Hero Section */}
      <section className="section-spacing">
        <div className="container-clean">
          <div className="text-center max-w-5xl mx-auto content-spacing animate-fade-in">
            <h1 className="text-5xl lg:text-7xl font-bold text-gray-900 mb-8 leading-tight">
              Transform Your Energy Future with <span className="text-gradient">VoltSphere</span>
            </h1>
            <p className="text-2xl lg:text-3xl text-gray-700 mb-12 max-w-4xl mx-auto leading-relaxed">
              Experience the power of AI-driven microgrid simulation and optimization. Reduce costs, increase
              efficiency, and build a sustainable energy future with our cutting-edge platform.
            </p>
            <div className="flex flex-col sm:flex-row gap-6 justify-center">
              <Button asChild size="lg" className="btn-primary text-xl">
                <Link href="/simulations">
                  Start Free Simulation
                  <ArrowRight className="ml-3 h-6 w-6" />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="btn-outline text-xl">
                <Link href="/about">Learn More</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="section-spacing-sm bg-gradient-secondary">
        <div className="container-clean">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12 stagger-children">
            {stats.map((stat, index) => (
              <div key={index} className="text-center group">
                <div className="flex justify-center mb-6">
                  <div className="w-20 h-20 bg-gradient-to-r from-blue-600 to-purple-600 rounded-3xl flex items-center justify-center group-hover:scale-110 transition-transform-smooth shadow-xl">
                    <stat.icon className="h-10 w-10 text-white" />
                  </div>
                </div>
                <div className="text-4xl lg:text-5xl font-bold text-gradient mb-3">{stat.value}</div>
                <div className="text-gray-700 font-semibold text-lg">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="section-spacing bg-gradient-accent">
        <div className="container-clean">
          <div className="text-center mb-20 animate-fade-in">
            <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-8">Powerful Features</h2>
            <p className="text-2xl text-gray-700 max-w-3xl mx-auto leading-relaxed">
              Everything you need to model, analyze, and optimize your energy systems with precision and confidence
            </p>
          </div>

          <div className="grid-responsive stagger-children">
            {features.map((feature, index) => (
              <Card key={index} className="card-enhanced text-center hover-lift">
                <CardHeader className="pb-6">
                  <div className="flex justify-center mb-6">
                    <div className="w-20 h-20 bg-gradient-to-r from-blue-600 to-purple-600 rounded-3xl flex items-center justify-center shadow-xl">
                      <feature.icon className="h-10 w-10 text-white" />
                    </div>
                  </div>
                  <CardTitle className="text-2xl font-bold text-gray-900 mb-4">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent className="px-8 pb-8">
                  <p className="text-gray-700 text-lg leading-relaxed">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Plans Section */}
      <section className="section-spacing bg-gradient-primary">
        <div className="container-clean">
          <div className="text-center mb-20 animate-fade-in">
            <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-8">Choose Your Plan</h2>
            <p className="text-2xl text-gray-700 max-w-3xl mx-auto leading-relaxed">
              From basic modeling to enterprise-grade simulations, we have the perfect solution for your energy needs
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8 lg:gap-12 stagger-children">
            {plans.map((plan, index) => (
              <Card
                key={index}
                className={`card-enhanced relative hover-lift ${plan.popular ? "ring-4 ring-blue-500 ring-offset-4 scale-105" : ""}`}
              >
                {plan.popular && (
                  <div className="absolute -top-6 left-1/2 transform -translate-x-1/2">
                    <span className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-2 rounded-full text-lg font-bold shadow-lg">
                      Most Popular
                    </span>
                  </div>
                )}
                <CardHeader className="text-center pb-6">
                  <CardTitle className="text-3xl font-bold text-gray-900 mb-4">{plan.name}</CardTitle>
                  <p className="text-gray-700 text-lg leading-relaxed px-4">{plan.description}</p>
                </CardHeader>
                <CardContent className="px-8 pb-8 space-y-8">
                  <ul className="space-y-4">
                    {plan.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center gap-4">
                        <CheckCircle className="h-6 w-6 text-blue-600 flex-shrink-0" />
                        <span className="text-gray-700 text-lg">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button asChild className="w-full btn-primary text-lg">
                    <Link href={plan.href}>
                      Get Started
                      <ArrowRight className="ml-3 h-5 w-5" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-spacing bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <div className="container-clean text-center animate-fade-in">
          <h2 className="text-4xl lg:text-5xl font-bold mb-8">Ready to Get Started?</h2>
          <p className="text-2xl mb-12 max-w-3xl mx-auto opacity-90 leading-relaxed">
            Join thousands of energy professionals who trust VoltSphere for their simulation and optimization needs.
          </p>
          <Button
            asChild
            size="lg"
            className="bg-white text-blue-600 hover:bg-gray-100 font-bold px-12 py-6 rounded-2xl transition-smooth text-xl shadow-xl hover:shadow-2xl"
          >
            <Link href="/simulations">
              Start Free Trial
              <ArrowRight className="ml-3 h-6 w-6" />
            </Link>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white section-spacing-sm">
        <div className="container-clean">
          <div className="grid md:grid-cols-4 gap-12 mb-12">
            <div className="space-y-6">
              <div className="flex items-center space-x-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-r from-blue-600 to-purple-600">
                  <Zap className="h-6 w-6 text-white" />
                </div>
                <span className="text-2xl font-bold">VoltSphere</span>
              </div>
              <p className="text-gray-400 text-lg leading-relaxed">
                Advanced energy simulation and optimization platform for professionals worldwide.
              </p>
            </div>

            <div>
              <h3 className="font-bold mb-6 text-xl">Product</h3>
              <ul className="space-y-3 text-gray-400">
                <li>
                  <Link href="/simulations" className="hover:text-white transition-smooth text-lg">
                    Simulations
                  </Link>
                </li>
                <li>
                  <Link href="/pricing" className="hover:text-white transition-smooth text-lg">
                    Pricing
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-bold mb-6 text-xl">Company</h3>
              <ul className="space-y-3 text-gray-400">
                <li>
                  <Link href="/about" className="hover:text-white transition-smooth text-lg">
                    About
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="hover:text-white transition-smooth text-lg">
                    Contact
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-bold mb-6 text-xl">Support</h3>
              <ul className="space-y-3 text-gray-400">
                <li>
                  <Link href="/help" className="hover:text-white transition-smooth text-lg">
                    Help Center
                  </Link>
                </li>
                <li>
                  <Link href="/docs" className="hover:text-white transition-smooth text-lg">
                    Documentation
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-8 text-center text-gray-400">
            <p className="text-lg">&copy; 2024 VoltSphere. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
