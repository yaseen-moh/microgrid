"use client"

import { SiteHeader } from "@/components/site-header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import {
  Calculator,
  BarChart3,
  Settings,
  Users,
  ArrowRight,
  CheckCircle,
  MessageCircle,
  BookOpen,
  Wrench,
} from "lucide-react"

export default function ServicesPage() {
  const services = [
    {
      icon: <Calculator className="h-8 w-8 text-blue-500" />,
      title: "Energy Simulation",
      description: "Model your energy systems with our easy-to-use simulation platform.",
      features: ["Solar & battery modeling", "Load forecasting", "Cost analysis", "Weather integration"],
      cta: "Try Free Simulation",
      link: "/simulation",
    },
    {
      icon: <BarChart3 className="h-8 w-8 text-green-500" />,
      title: "Custom Analysis",
      description: "Get detailed reports and insights tailored to your specific needs.",
      features: ["Custom reporting", "ROI analysis", "Performance optimization", "Trend analysis"],
      cta: "Contact Us",
      link: "/contact",
    },
    {
      icon: <Settings className="h-8 w-8 text-purple-500" />,
      title: "API Integration",
      description: "Connect VoltSphere with your existing systems and workflows.",
      features: ["RESTful API", "Real-time data", "Custom integrations", "Developer support"],
      cta: "View API Docs",
      link: "/simulation/api",
    },
    {
      icon: <Users className="h-8 w-8 text-orange-500" />,
      title: "Training & Support",
      description: "Get the most out of VoltSphere with our training and support services.",
      features: ["Live training sessions", "24/7 support", "Best practices guide", "Community access"],
      cta: "Get Support",
      link: "/contact",
    },
  ]

  const supportOptions = [
    {
      icon: <MessageCircle className="h-6 w-6 text-blue-500" />,
      title: "Live Chat",
      description: "Get instant help from our support team",
      availability: "24/7",
    },
    {
      icon: <BookOpen className="h-6 w-6 text-green-500" />,
      title: "Documentation",
      description: "Comprehensive guides and tutorials",
      availability: "Always available",
    },
    {
      icon: <Wrench className="h-6 w-6 text-purple-500" />,
      title: "Custom Setup",
      description: "We'll help configure VoltSphere for your needs",
      availability: "By appointment",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50/50 via-white to-purple-50/50">
      <SiteHeader />

      {/* Hero Section */}
      <section className="section-padding">
        <div className="container-padding">
          <div className="text-center max-w-3xl mx-auto animate-fade-in">
            <Badge className="mb-6 bg-gradient-to-r from-blue-500 to-purple-500 text-white px-4 py-2">
              Our Services
            </Badge>

            <h1 className="text-4xl md:text-5xl font-bold mb-6 text-gray-900">
              Everything You Need for
              <span className="bg-gradient-to-r from-blue-500 to-purple-500 bg-clip-text text-transparent">
                {" "}
                Energy Success
              </span>
            </h1>

            <p className="text-lg md:text-xl text-gray-600 leading-relaxed">
              From simple simulations to enterprise integrations, we've got you covered.
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="section-padding bg-white/70">
        <div className="container-padding">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {services.map((service, index) => (
              <Card
                key={index}
                className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 bg-white/80 backdrop-blur-sm animate-scale-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <CardHeader>
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-16 h-16 rounded-xl bg-gray-50 flex items-center justify-center">
                      {service.icon}
                    </div>
                    <div>
                      <CardTitle className="text-2xl font-bold text-gray-900">{service.title}</CardTitle>
                    </div>
                  </div>
                  <p className="text-gray-600 leading-relaxed">{service.description}</p>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 mb-6">
                    {service.features.map((feature, featureIndex) => (
                      <div key={featureIndex} className="flex items-center gap-3">
                        <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                        <span className="text-gray-700">{feature}</span>
                      </div>
                    ))}
                  </div>
                  <Button
                    asChild
                    className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
                  >
                    <Link href={service.link}>
                      {service.cta}
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Support Section */}
      <section className="section-padding">
        <div className="container-padding">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900">We're Here to Help</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Multiple ways to get the support you need, when you need it.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {supportOptions.map((option, index) => (
              <Card
                key={index}
                className="border-0 shadow-lg bg-white/80 backdrop-blur-sm text-center animate-scale-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <CardContent className="p-8">
                  <div className="w-16 h-16 rounded-xl bg-gray-50 flex items-center justify-center mx-auto mb-4">
                    {option.icon}
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{option.title}</h3>
                  <p className="text-gray-600 mb-4">{option.description}</p>
                  <Badge variant="secondary" className="bg-blue-50 text-blue-700">
                    {option.availability}
                  </Badge>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding bg-gradient-to-r from-blue-500 via-purple-500 to-indigo-500">
        <div className="container-padding">
          <div className="text-center text-white max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Get Started?</h2>
            <p className="text-lg md:text-xl mb-8 opacity-90">
              Choose the service that's right for you, or contact us to discuss your specific needs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="bg-white text-blue-600 hover:bg-gray-100 font-semibold px-8">
                <Link href="/simulation">
                  Start Free Trial
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="border-white/30 text-white hover:bg-white/10 px-8">
                <Link href="/contact">Talk to Us</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
