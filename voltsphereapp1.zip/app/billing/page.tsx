"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { CreditCard, Download, Zap, TrendingUp, Settings, ExternalLink } from "lucide-react"

// Mock user data - replace with actual user context
const mockUser = {
  email: "user@example.com",
  subscription: {
    tier: "pro" as const,
    status: "active" as const,
    currentPeriodStart: new Date("2024-01-01"),
    currentPeriodEnd: new Date("2024-02-01"),
    cancelAtPeriodEnd: false,
    stripeCustomerId: "cus_example123",
  },
  usage: {
    simulationsToday: 15,
    simulationsThisMonth: 245,
    apiCallsThisMonth: 0,
  },
}

export default function BillingPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [user] = useState(mockUser) // Replace with actual user context

  const handleManageSubscription = async () => {
    setIsLoading(true)

    try {
      const response = await fetch("/api/create-portal-session", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          customerId: user.subscription.stripeCustomerId,
        }),
      })

      const { url, error } = await response.json()

      if (error) {
        throw new Error(error)
      }

      if (url) {
        window.location.href = url
      }
    } catch (error) {
      console.error("Error creating portal session:", error)
      alert("Failed to open billing portal. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800"
      case "past_due":
        return "bg-yellow-100 text-yellow-800"
      case "canceled":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getTierName = (tier: string) => {
    switch (tier) {
      case "pro":
        return "Pro Tier"
      case "starter":
        return "Starter API"
      case "growth":
        return "Growth API"
      case "enterprise":
        return "Enterprise"
      default:
        return "Free Tier"
    }
  }

  const simulationLimit = user.subscription.tier === "free" ? 3 : -1
  const simulationProgress = simulationLimit > 0 ? (user.usage.simulationsToday / simulationLimit) * 100 : 0

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 animate-fade-in">
      {/* Header */}
      <header className="glass-effect border-b sticky top-0 z-40 backdrop-enhanced">
        <nav className="container mx-auto mobile-padding py-3 sm:py-4 flex justify-between items-center">
          <Link
            href="/"
            className="text-xl sm:text-2xl font-bold gradient-text hover:scale-105 transition-transform duration-300 font-display"
          >
            VoltSphere
          </Link>
          <div className="hidden md:flex gap-6 lg:gap-8">
            <Link href="/" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">
              Home
            </Link>
            <Link href="/simulation" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">
              Simulation
            </Link>
            <span className="text-blue-600 font-semibold">Billing</span>
          </div>
        </nav>
      </header>

      <div className="container mx-auto mobile-padding py-12 sm:py-16">
        {/* Page Header */}
        <div className="mb-8 sm:mb-12">
          <h1 className="mobile-heading-xl mb-4 text-gray-800 font-display">Billing & Usage</h1>
          <p className="mobile-body-lg text-gray-600">Manage your subscription and monitor your usage</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-8">
          {/* Current Plan */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="card-enhanced">
              <CardHeader>
                <CardTitle className="flex items-center gap-3 mobile-heading-md font-display">
                  <CreditCard className="h-6 w-6 text-blue-600" />
                  Current Plan
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-2xl font-bold text-gray-800 font-display">
                      {getTierName(user.subscription.tier)}
                    </h3>
                    <p className="text-gray-600 mobile-body-md">
                      {user.subscription.tier === "free" ? "Free forever" : "$5.99/month"}
                    </p>
                  </div>
                  <Badge className={getStatusColor(user.subscription.status)}>
                    {user.subscription.status.charAt(0).toUpperCase() + user.subscription.status.slice(1)}
                  </Badge>
                </div>

                {user.subscription.tier !== "free" && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Current billing period</span>
                      <span className="font-medium">
                        {user.subscription.currentPeriodStart.toLocaleDateString()} -{" "}
                        {user.subscription.currentPeriodEnd.toLocaleDateString()}
                      </span>
                    </div>
                    {user.subscription.cancelAtPeriodEnd && (
                      <p className="text-yellow-600 text-sm font-medium">
                        Your subscription will cancel on {user.subscription.currentPeriodEnd.toLocaleDateString()}
                      </p>
                    )}
                  </div>
                )}

                <div className="flex gap-4">
                  {user.subscription.tier === "free" ? (
                    <Link href="/pricing">
                      <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 mobile-btn mobile-rounded font-semibold touch-target">
                        Upgrade Plan
                      </Button>
                    </Link>
                  ) : (
                    <>
                      <Button
                        onClick={handleManageSubscription}
                        disabled={isLoading}
                        className="mobile-btn mobile-rounded font-semibold touch-target"
                      >
                        <Settings className="h-4 w-4 mr-2" />
                        {isLoading ? "Loading..." : "Manage Subscription"}
                      </Button>
                      <Link href="/pricing">
                        <Button variant="outline" className="mobile-btn mobile-rounded font-semibold touch-target">
                          Change Plan
                        </Button>
                      </Link>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Usage Statistics */}
            <Card className="card-enhanced">
              <CardHeader>
                <CardTitle className="flex items-center gap-3 mobile-heading-md font-display">
                  <TrendingUp className="h-6 w-6 text-green-600" />
                  Usage This Month
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Simulations */}
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-medium text-gray-700">Daily Simulations</span>
                    <span className="text-sm text-gray-600">
                      {user.usage.simulationsToday}
                      {simulationLimit > 0 ? ` / ${simulationLimit}` : ""}
                    </span>
                  </div>
                  {simulationLimit > 0 && <Progress value={simulationProgress} className="h-2" />}
                  <p className="text-xs text-gray-500 mt-1">
                    {simulationLimit > 0
                      ? `${simulationLimit - user.usage.simulationsToday} simulations remaining today`
                      : "Unlimited simulations"}
                  </p>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-medium text-gray-700">Monthly Simulations</span>
                    <span className="text-sm text-gray-600">{user.usage.simulationsThisMonth}</span>
                  </div>
                </div>

                {user.subscription.tier !== "free" && user.subscription.tier !== "pro" && (
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium text-gray-700">API Calls</span>
                      <span className="text-sm text-gray-600">
                        {user.usage.apiCallsThisMonth} / {user.subscription.tier === "starter" ? "5,000" : "50,000"}
                      </span>
                    </div>
                    <Progress
                      value={
                        (user.usage.apiCallsThisMonth / (user.subscription.tier === "starter" ? 5000 : 50000)) * 100
                      }
                      className="h-2"
                    />
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Quick Actions */}
          <div className="space-y-6">
            <Card className="card-enhanced">
              <CardHeader>
                <CardTitle className="mobile-heading-md font-display">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Link href="/simulation">
                  <Button variant="outline" className="w-full justify-start mobile-btn mobile-rounded touch-target">
                    <Zap className="h-4 w-4 mr-2" />
                    Run Simulation
                  </Button>
                </Link>

                {user.subscription.tier !== "free" && (
                  <Button variant="outline" className="w-full justify-start mobile-btn mobile-rounded touch-target">
                    <Download className="h-4 w-4 mr-2" />
                    Download Reports
                  </Button>
                )}

                <Link href="/pricing">
                  <Button variant="outline" className="w-full justify-start mobile-btn mobile-rounded touch-target">
                    <ExternalLink className="h-4 w-4 mr-2" />
                    View All Plans
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Plan Features */}
            <Card className="card-enhanced">
              <CardHeader>
                <CardTitle className="mobile-heading-md font-display">Your Plan Includes</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {user.subscription.tier === "free" ? (
                  <>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-sm">3 simulations per day</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-sm">Basic solar/load profiles</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-gray-300 rounded-full"></div>
                      <span className="text-sm text-gray-500">No data export</span>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-sm">Unlimited simulations</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-sm">Data export (CSV/PNG)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-sm">Save projects</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-sm">Priority support</span>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
