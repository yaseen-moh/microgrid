"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Check } from "lucide-react"
import { useAuth } from "@/lib/auth-context"
import { LoginDialog } from "@/components/auth/login-dialog"
import { useRouter } from "next/navigation"
import { toast } from "sonner"

export default function PricingPage() {
  const [billingInterval, setBillingInterval] = useState<"monthly" | "yearly">("monthly")
  const { user } = useAuth()
  const [showLoginDialog, setShowLoginDialog] = useState(false)
  const [processingTier, setProcessingTier] = useState<string | null>(null)
  const router = useRouter()

  const handlePurchase = async (tier: string) => {
    if (!user) {
      setShowLoginDialog(true)
      return
    }

    setProcessingTier(tier)

    try {
      const response = await fetch("/api/create-checkout-session", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          tier,
          billing: billingInterval,
          successUrl: `${window.location.origin}/billing/success?session_id={CHECKOUT_SESSION_ID}`,
          cancelUrl: `${window.location.origin}/pricing`,
        }),
      })

      const { url, error } = await response.json()

      if (error) {
        toast.error(error)
        return
      }

      if (url) {
        // Step 2: Redirect to Stripe checkout
        window.location.href = url
      } else {
        toast.error("Failed to create checkout session")
      }
    } catch (error) {
      console.error("Error creating checkout session:", error)
      toast.error("Failed to create checkout session")
    } finally {
      setProcessingTier(null)
    }
  }

  const plans = [
    {
      id: "free",
      name: "Free",
      description: "Basic access to energy simulation tools",
      price: { monthly: 0, yearly: 0 },
      features: ["Basic simulation models", "Standard visualization", "Limited data export", "Community support"],
    },
    {
      id: "pro",
      name: "Pro",
      description: "Advanced simulation tools for professionals",
      price: {
        monthly: 5.99,
        yearly: 599.99,
      },
      features: [
        "Everything in Free",
        "Advanced simulation models",
        "Enhanced visualization",
        "Full data export",
        "Priority email support",
      ],
      popular: true,
    },
    {
      id: "growth",
      name: "Growth",
      description: "Enterprise-grade simulation platform",
      price: {
        monthly: 99,
        yearly: 990,
      },
      features: [
        "Everything in Pro",
        "Custom simulation models",
        "Advanced analytics",
        "API access",
        "Dedicated support",
      ],
    },
  ]

  return (
    <div className="container max-w-6xl px-4 py-16 md:py-24">
      <div className="mx-auto text-center mb-16">
        <h1 className="text-4xl md:text-5xl font-bold mb-6">Simple, Transparent Pricing</h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Choose the plan that best fits your needs. All plans include access to our core simulation features.
        </p>

        <div className="mt-10 flex justify-center">
          <Tabs
            defaultValue="monthly"
            value={billingInterval}
            onValueChange={(value) => setBillingInterval(value as "monthly" | "yearly")}
            className="w-full max-w-md"
          >
            <TabsList className="grid w-full grid-cols-2 bg-gray-100 rounded-xl p-1">
              <TabsTrigger
                value="monthly"
                className="rounded-lg data-[state=active]:bg-white data-[state=active]:text-blue-600 data-[state=active]:shadow-sm py-3"
              >
                Monthly
              </TabsTrigger>
              <TabsTrigger
                value="yearly"
                className="rounded-lg data-[state=active]:bg-white data-[state=active]:text-blue-600 data-[state=active]:shadow-sm py-3"
              >
                Yearly <span className="ml-1 text-sm text-green-600 font-medium">Save 17%</span>
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {plans.map((plan) => (
          <Card
            key={plan.id}
            className={`border-2 rounded-3xl shadow-lg hover:shadow-xl transition-all duration-300 ${
              plan.popular
                ? "border-blue-200 relative shadow-xl hover:shadow-2xl"
                : "border-gray-200 hover:border-gray-300"
            }`}
          >
            {plan.popular && (
              <div className="absolute top-0 right-0 transform translate-x-2 -translate-y-2">
                <span className="bg-blue-600 text-white text-sm font-semibold px-4 py-1 rounded-full shadow-lg">
                  Popular
                </span>
              </div>
            )}
            <CardHeader className="pb-8 pt-8">
              <CardTitle className="text-2xl">{plan.name}</CardTitle>
              <div className="mt-4 flex items-baseline text-gray-900">
                <span className="text-5xl font-extrabold tracking-tight">
                  ${billingInterval === "monthly" ? plan.price.monthly : plan.price.yearly}
                </span>
                {plan.price.monthly > 0 && (
                  <span className="ml-1 text-xl font-semibold">
                    /{billingInterval === "monthly" ? "month" : "year"}
                  </span>
                )}
              </div>
              <CardDescription className="mt-4 text-gray-500">{plan.description}</CardDescription>
            </CardHeader>
            <CardContent className="pb-8">
              <ul className="space-y-4">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
            <CardFooter>
              {plan.id === "free" ? (
                <Button
                  variant="outline"
                  className="w-full py-6 text-lg rounded-xl border-2 hover:bg-gray-50"
                  onClick={() => router.push("/simulation")}
                >
                  Get Started
                </Button>
              ) : (
                <Button
                  className={`w-full py-6 text-lg rounded-xl ${
                    plan.popular ? "bg-blue-600 hover:bg-blue-700" : "bg-gray-800 hover:bg-gray-900"
                  }`}
                  onClick={() => handlePurchase(plan.id)}
                  disabled={processingTier === plan.id}
                >
                  {processingTier === plan.id ? (
                    <>
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                      Processing...
                    </>
                  ) : user ? (
                    "Upgrade Now"
                  ) : (
                    "Sign In to Purchase"
                  )}
                </Button>
              )}
            </CardFooter>
          </Card>
        ))}
      </div>

      <LoginDialog open={showLoginDialog} onOpenChange={setShowLoginDialog} />
    </div>
  )
}
