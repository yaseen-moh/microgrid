"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { SiteHeader } from "@/components/site-header"
import { SimulationNav } from "@/components/simulation/simulation-nav"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Zap, Key, Book, Activity, Copy, CheckCircle, ChevronLeft, ChevronRight, TrendingUp } from "lucide-react"
import { useAuth } from "@/lib/auth-context"

// Static code examples to avoid template literal issues
const CURL_EXAMPLE = `curl -X POST https://api.voltsphere.com/v1/simulate \\
-H "Authorization: Bearer vs_sk_growth_1234567890abcdef" \\
-H "Content-Type: application/json" \\
-d '{
  "sites": [
    {
      "id": "site_1",
      "batteryCapacity": 100,
      "solarCapacity": 60,
      "loadProfile": "commercial",
      "location": "San Francisco, CA"
    },
    {
      "id": "site_2", 
      "batteryCapacity": 80,
      "solarCapacity": 50,
      "loadProfile": "commercial",
      "location": "Los Angeles, CA"
    }
  ],
  "portfolioOptimization": true,
  "demandResponse": true,
  "duration": "30d"
}'`

const JS_EXAMPLE = `const response = await fetch('https://api.voltsphere.com/v1/simulate', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer vs_sk_growth_1234567890abcdef',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    sites: [
      {
        id: "site_1",
        batteryCapacity: 100,
        solarCapacity: 60,
        loadProfile: "commercial",
        location: "San Francisco, CA"
      },
      {
        id: "site_2",
        batteryCapacity: 80,
        solarCapacity: 50,
        loadProfile: "commercial",
        location: "Los Angeles, CA"
      }
    ],
    portfolioOptimization: true,
    demandResponse: true,
    duration: "30d"
  })
});

const data = await response.json();
console.log(data);`

const PYTHON_EXAMPLE = `import requests

url = "https://api.voltsphere.com/v1/simulate"
headers = {
  "Authorization": f"Bearer vs_sk_growth_1234567890abcdef",
  "Content-Type": "application/json"
}
data = {
  "sites": [
    {
      "id": "site_1",
      "batteryCapacity": 100,
      "solarCapacity": 60,
      "loadProfile": "commercial",
      "location": "San Francisco, CA"
    },
    {
      "id": "site_2", 
      "batteryCapacity": 80,
      "solarCapacity": 50,
      "loadProfile": "commercial",
      "location": "Los Angeles, CA"
    }
  ],
  "portfolioOptimization": True,
  "demandResponse": True,
  "duration": "30d"
}

response = requests.post(url, headers=headers, json=data)
result = response.json()
print(result)`

// Static API examples
const GROWTH_EXAMPLES = [
  {
    title: "Multi-Site Commercial Portfolio",
    description: "Analyze multiple commercial buildings as a portfolio",
    code: `{
  "sites": [
    {
      "id": "site_1",
      "batteryCapacity": 100,
      "solarCapacity": 60,
      "loadProfile": "commercial",
      "location": "San Francisco, CA"
    },
    {
      "id": "site_2", 
      "batteryCapacity": 80,
      "solarCapacity": 50,
      "loadProfile": "commercial",
      "location": "Los Angeles, CA"
    }
  ],
  "portfolioOptimization": true,
  "demandResponse": true,
  "duration": "30d"
}`,
  },
  {
    title: "Industrial Facility with Peak Shaving",
    description: "Large manufacturing plant with demand management",
    code: `{
  "batteryCapacity": 200,
  "solarCapacity": 120,
  "windCapacity": 50,
  "loadProfile": "industrial",
  "peakShaving": true,
  "demandChargeOptimization": true,
  "timeOfUseRates": true,
  "shiftSchedule": "3x8",
  "location": "Chicago, IL",
  "duration": "7d"
}`,
  },
]

export default function GrowthAPIPage() {
  const { user, isLoading } = useAuth()
  const router = useRouter()
  const [apiKey] = useState("vs_sk_growth_1234567890abcdef")
  const [copied, setCopied] = useState(false)
  const [currentExample, setCurrentExample] = useState(0)

  // Check access - Growth tier or higher
  useEffect(() => {
    if (
      !isLoading &&
      user?.subscriptionTier !== "growth" &&
      user?.subscriptionTier !== "enterprise" &&
      user?.role !== "admin"
    ) {
      router.push("/pricing")
    }
  }, [user, isLoading, router])

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50">
        <SiteHeader />
        <div className="container mx-auto py-8">
          <div className="flex items-center justify-center h-96">
            <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600"></div>
          </div>
        </div>
      </div>
    )
  }

  if (user?.subscriptionTier !== "growth" && user?.subscriptionTier !== "enterprise" && user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50">
        <SiteHeader />
        <div className="container mx-auto py-8">
          <div className="text-center">
            <div className="flex items-center justify-center gap-2 mb-4">
              <Zap className="h-8 w-8 text-purple-600" />
              <h1 className="text-3xl font-bold text-gray-800">Growth API</h1>
              <Badge className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">Growth</Badge>
            </div>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto mb-8">
              Access to Growth API requires a Growth subscription or higher.
            </p>
            <Button
              onClick={() => router.push("/pricing")}
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
            >
              Upgrade to Growth
            </Button>
          </div>
        </div>
      </div>
    )
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const nextExample = () => {
    setCurrentExample((prev) => (prev + 1) % GROWTH_EXAMPLES.length)
  }

  const prevExample = () => {
    setCurrentExample((prev) => (prev - 1 + GROWTH_EXAMPLES.length) % GROWTH_EXAMPLES.length)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50">
      <SiteHeader />

      <div className="container mx-auto py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Zap className="h-8 w-8 text-purple-600" />
            <h1 className="text-3xl font-bold text-gray-800">Growth API</h1>
            <Badge className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">Growth</Badge>
          </div>
          <p className="text-lg text-gray-600 max-w-4xl mx-auto">
            Advanced API capabilities for complex simulations, multi-site analysis, and enterprise-grade automation.
          </p>
        </div>

        {/* Navigation */}
        <div className="mb-8">
          <SimulationNav userTier={user?.subscriptionTier || "free"} />
        </div>

        {/* Main Content */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <Book className="h-4 w-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="authentication" className="flex items-center gap-2">
              <Key className="h-4 w-4" />
              Authentication
            </TabsTrigger>
            <TabsTrigger value="endpoints" className="flex items-center gap-2">
              <Activity className="h-4 w-4" />
              Endpoints
            </TabsTrigger>
            <TabsTrigger value="examples" className="flex items-center gap-2">
              <Zap className="h-4 w-4" />
              Examples
            </TabsTrigger>
            <TabsTrigger value="advanced" className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Advanced
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="h-5 w-5 text-purple-600" />
                    Growth Features
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600">
                    The Growth API unlocks advanced simulation capabilities for complex projects:
                  </p>
                  <ul className="space-y-2 text-gray-600">
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      50,000 API calls per month
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      Multi-site portfolio analysis
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-pink-600" />
                    Enhanced Limits
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center p-3 bg-purple-50 rounded-lg">
                      <span className="font-medium">Monthly Calls</span>
                      <Badge variant="outline">50,000</Badge>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-pink-50 rounded-lg">
                      <span className="font-medium">Rate Limit</span>
                      <Badge variant="outline">200/minute</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Authentication Tab */}
          <TabsContent value="authentication">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Key className="h-5 w-5 text-purple-600" />
                  Growth API Authentication
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-3">Your Growth API Key</h3>
                  <div className="flex items-center gap-2">
                    <Input value={apiKey} readOnly className="font-mono text-sm" />
                    <Button onClick={() => copyToClipboard(apiKey)} variant="outline" size="sm">
                      {copied ? <CheckCircle className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Endpoints Tab */}
          <TabsContent value="endpoints">
            <Card>
              <CardHeader>
                <CardTitle>POST /simulate</CardTitle>
                <p className="text-gray-600">Advanced microgrid simulation with Growth tier features</p>
              </CardHeader>
              <CardContent>
                <p>See documentation for details</p>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Examples Tab */}
          <TabsContent value="examples">
            <Card>
              <CardHeader>
                <CardTitle>Growth Code Examples</CardTitle>
                <p className="text-gray-600">Advanced simulation examples for complex use cases</p>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="curl" className="space-y-4">
                  <TabsList>
                    <TabsTrigger value="curl">cURL</TabsTrigger>
                    <TabsTrigger value="javascript">JavaScript</TabsTrigger>
                    <TabsTrigger value="python">Python</TabsTrigger>
                  </TabsList>

                  <TabsContent value="curl">
                    <div className="relative">
                      <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg text-sm overflow-x-auto">
                        <code>{CURL_EXAMPLE}</code>
                      </pre>
                      <Button
                        onClick={() => copyToClipboard(CURL_EXAMPLE)}
                        variant="outline"
                        size="sm"
                        className="absolute top-2 right-2"
                      >
                        {copied ? <CheckCircle className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                  </TabsContent>

                  <TabsContent value="javascript">
                    <div className="relative">
                      <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg text-sm overflow-x-auto">
                        <code>{JS_EXAMPLE}</code>
                      </pre>
                      <Button
                        onClick={() => copyToClipboard(JS_EXAMPLE)}
                        variant="outline"
                        size="sm"
                        className="absolute top-2 right-2"
                      >
                        {copied ? <CheckCircle className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                  </TabsContent>

                  <TabsContent value="python">
                    <div className="relative">
                      <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg text-sm overflow-x-auto">
                        <code>{PYTHON_EXAMPLE}</code>
                      </pre>
                      <Button
                        onClick={() => copyToClipboard(PYTHON_EXAMPLE)}
                        variant="outline"
                        size="sm"
                        className="absolute top-2 right-2"
                      >
                        {copied ? <CheckCircle className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                  </TabsContent>
                </Tabs>

                {/* Use Cases Carousel */}
                <div className="mt-8">
                  <Card className="border-2 border-purple-200">
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between">
                        <span>Growth Use Cases</span>
                        <div className="flex items-center gap-2">
                          <Button onClick={prevExample} variant="outline" size="sm">
                            <ChevronLeft className="h-4 w-4" />
                          </Button>
                          <span className="text-sm text-gray-500">
                            {currentExample + 1} of {GROWTH_EXAMPLES.length}
                          </span>
                          <Button onClick={nextExample} variant="outline" size="sm">
                            <ChevronRight className="h-4 w-4" />
                          </Button>
                        </div>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="text-center">
                          <h3 className="text-xl font-semibold text-gray-800 mb-2">
                            {GROWTH_EXAMPLES[currentExample].title}
                          </h3>
                          <p className="text-gray-600 mb-4">{GROWTH_EXAMPLES[currentExample].description}</p>
                        </div>

                        <div className="relative">
                          <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg text-sm overflow-x-auto max-h-96">
                            <code>{GROWTH_EXAMPLES[currentExample].code}</code>
                          </pre>
                          <Button
                            onClick={() => copyToClipboard(GROWTH_EXAMPLES[currentExample].code)}
                            variant="outline"
                            size="sm"
                            className="absolute top-2 right-2"
                          >
                            {copied ? <CheckCircle className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Advanced Features Tab */}
          <TabsContent value="advanced">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-purple-600" />
                    Advanced Capabilities
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="p-3 bg-purple-50 rounded-lg">
                      <h4 className="font-semibold text-purple-800">Multi-Site Portfolio Analysis</h4>
                      <p className="text-sm text-purple-600">Analyze up to 50 sites as a unified portfolio</p>
                    </div>
                    <div className="p-3 bg-blue-50 rounded-lg">
                      <h4 className="font-semibold text-blue-800">Demand Response Optimization</h4>
                      <p className="text-sm text-blue-600">Automated participation in utility programs</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="h-5 w-5 text-pink-600" />
                    Optimization Features
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="p-3 bg-pink-50 rounded-lg">
                      <h4 className="font-semibold text-pink-800">Multi-Objective Optimization</h4>
                      <p className="text-sm text-pink-600">Cost, emissions, and resilience optimization</p>
                    </div>
                    <div className="p-3 bg-indigo-50 rounded-lg">
                      <h4 className="font-semibold text-indigo-800">Time-of-Use Rate Optimization</h4>
                      <p className="text-sm text-indigo-600">Dynamic pricing and demand charge management</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
