"use client"

import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import {
  Crown,
  Book,
  TrendingUp,
  Zap,
  Building2,
  Users,
  Shield,
  Database,
  Cloud,
  BarChart3,
  Download,
  Share2,
} from "lucide-react"

export default function EnterprisePage() {
  const { user } = useAuth()
  const [activeTab, setActiveTab] = useState("overview")
  const [simulationData, setSimulationData] = useState({
    capacity: [5000],
    efficiency: [95],
    location: "",
    weatherPattern: "realistic",
    loadProfile: "commercial",
    batteryType: "lithium-ion",
    gridConnection: true,
    backupPower: true,
    peakShaving: true,
    demandResponse: true,
  })

  const enterpriseFeatures = [
    {
      icon: Building2,
      title: "Multi-Site Management",
      description:
        "Manage and simulate multiple microgrid installations across different locations with centralized control.",
    },
    {
      icon: Users,
      title: "Team Collaboration",
      description: "Advanced user management with role-based access control and team collaboration features.",
    },
    {
      icon: Shield,
      title: "Enterprise Security",
      description: "SOC 2 compliance, SSO integration, and advanced security features for enterprise environments.",
    },
    {
      icon: Database,
      title: "Advanced Analytics",
      description: "Deep dive analytics with custom reporting, data export, and integration with BI tools.",
    },
    {
      icon: Cloud,
      title: "API & Integrations",
      description: "Full API access with webhooks, third-party integrations, and custom development support.",
    },
    {
      icon: BarChart3,
      title: "Custom Modeling",
      description: "Build custom simulation models with advanced parameters and proprietary algorithms.",
    },
  ]

  const simulationResults = {
    annualGeneration: 8750,
    costSavings: 125000,
    co2Reduction: 4.2,
    paybackPeriod: 6.8,
    roi: 18.5,
    peakDemandReduction: 35,
  }

  return (
    <div className="page-container">
      <div className="section-padding">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Crown className="h-8 w-8 text-yellow-500" />
            <Badge
              variant="secondary"
              className="bg-gradient-to-r from-yellow-100 to-orange-100 text-yellow-800 border-yellow-200"
            >
              Enterprise
            </Badge>
          </div>
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-gray-900 to-gray-600 bg-clip-text text-transparent">
            Enterprise Microgrid Simulation
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto text-content">
            Advanced simulation platform for large-scale microgrid deployments with enterprise-grade features and
            unlimited customization.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {enterpriseFeatures.map((feature, index) => (
            <Card key={index} className="border-2 hover:border-yellow-200 transition-colors">
              <CardHeader className="card-padding-sm">
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-2 bg-yellow-100 rounded-lg">
                    <feature.icon className="h-5 w-5 text-yellow-600" />
                  </div>
                  <CardTitle className="text-lg">{feature.title}</CardTitle>
                </div>
                <CardDescription className="text-content">{feature.description}</CardDescription>
              </CardHeader>
            </Card>
          ))}
        </div>

        {/* Main Simulation Interface */}
        <Card className="border-2">
          <CardHeader className="card-padding">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-2xl flex items-center gap-2">
                  <Zap className="h-6 w-6 text-yellow-500" />
                  Enterprise Simulation Console
                </CardTitle>
                <CardDescription className="text-content">
                  Advanced microgrid modeling with enterprise-grade features
                </CardDescription>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
                <Button variant="outline" size="sm">
                  <Share2 className="h-4 w-4 mr-2" />
                  Share
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="card-padding">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-4 mb-6">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="configuration">Configuration</TabsTrigger>
                <TabsTrigger value="analytics">Analytics</TabsTrigger>
                <TabsTrigger value="reports">Reports</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-6">
                {/* Key Metrics */}
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                  <Card>
                    <CardContent className="card-padding-sm text-center">
                      <div className="text-2xl font-bold text-green-600">
                        {simulationResults.annualGeneration.toLocaleString()}
                      </div>
                      <div className="text-sm text-gray-600">kWh/year</div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="card-padding-sm text-center">
                      <div className="text-2xl font-bold text-blue-600">
                        ${simulationResults.costSavings.toLocaleString()}
                      </div>
                      <div className="text-sm text-gray-600">Annual Savings</div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="card-padding-sm text-center">
                      <div className="text-2xl font-bold text-purple-600">{simulationResults.co2Reduction}</div>
                      <div className="text-sm text-gray-600">tons CO₂/year</div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="card-padding-sm text-center">
                      <div className="text-2xl font-bold text-orange-600">{simulationResults.paybackPeriod}</div>
                      <div className="text-sm text-gray-600">years payback</div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="card-padding-sm text-center">
                      <div className="text-2xl font-bold text-red-600">{simulationResults.roi}%</div>
                      <div className="text-sm text-gray-600">ROI</div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="card-padding-sm text-center">
                      <div className="text-2xl font-bold text-indigo-600">{simulationResults.peakDemandReduction}%</div>
                      <div className="text-sm text-gray-600">Peak Reduction</div>
                    </CardContent>
                  </Card>
                </div>

                {/* Chart Placeholder */}
                <Card>
                  <CardHeader className="card-padding-sm">
                    <CardTitle>Energy Flow Analysis</CardTitle>
                  </CardHeader>
                  <CardContent className="card-padding">
                    <div className="h-64 bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg flex items-center justify-center">
                      <div className="text-center text-content">
                        <BarChart3 className="h-12 w-12 text-gray-400 mx-auto mb-2" />
                        <p className="text-gray-600">Advanced energy flow visualization</p>
                        <p className="text-sm text-gray-500">Real-time data integration available</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="configuration" className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader className="card-padding-sm">
                      <CardTitle>System Configuration</CardTitle>
                    </CardHeader>
                    <CardContent className="card-padding space-y-4">
                      <div>
                        <Label htmlFor="capacity">System Capacity (kW)</Label>
                        <Slider
                          id="capacity"
                          min={1000}
                          max={50000}
                          step={500}
                          value={simulationData.capacity}
                          onValueChange={(value) => setSimulationData({ ...simulationData, capacity: value })}
                          className="mt-2"
                        />
                        <div className="text-sm text-gray-600 mt-1">
                          {simulationData.capacity[0].toLocaleString()} kW
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="efficiency">System Efficiency (%)</Label>
                        <Slider
                          id="efficiency"
                          min={80}
                          max={98}
                          step={1}
                          value={simulationData.efficiency}
                          onValueChange={(value) => setSimulationData({ ...simulationData, efficiency: value })}
                          className="mt-2"
                        />
                        <div className="text-sm text-gray-600 mt-1">{simulationData.efficiency[0]}%</div>
                      </div>

                      <div>
                        <Label htmlFor="location">Location</Label>
                        <Select
                          value={simulationData.location}
                          onValueChange={(value) => setSimulationData({ ...simulationData, location: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select location" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="california">California, USA</SelectItem>
                            <SelectItem value="texas">Texas, USA</SelectItem>
                            <SelectItem value="florida">Florida, USA</SelectItem>
                            <SelectItem value="germany">Germany</SelectItem>
                            <SelectItem value="australia">Australia</SelectItem>
                            <SelectItem value="custom">Custom Location</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="card-padding-sm">
                      <CardTitle>Advanced Features</CardTitle>
                    </CardHeader>
                    <CardContent className="card-padding space-y-4">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="grid-connection">Grid Connection</Label>
                        <Switch
                          id="grid-connection"
                          checked={simulationData.gridConnection}
                          onCheckedChange={(checked) =>
                            setSimulationData({ ...simulationData, gridConnection: checked })
                          }
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <Label htmlFor="backup-power">Backup Power</Label>
                        <Switch
                          id="backup-power"
                          checked={simulationData.backupPower}
                          onCheckedChange={(checked) => setSimulationData({ ...simulationData, backupPower: checked })}
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <Label htmlFor="peak-shaving">Peak Shaving</Label>
                        <Switch
                          id="peak-shaving"
                          checked={simulationData.peakShaving}
                          onCheckedChange={(checked) => setSimulationData({ ...simulationData, peakShaving: checked })}
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <Label htmlFor="demand-response">Demand Response</Label>
                        <Switch
                          id="demand-response"
                          checked={simulationData.demandResponse}
                          onCheckedChange={(checked) =>
                            setSimulationData({ ...simulationData, demandResponse: checked })
                          }
                        />
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="analytics" className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader className="card-padding-sm">
                      <CardTitle>Performance Analytics</CardTitle>
                    </CardHeader>
                    <CardContent className="card-padding">
                      <div className="h-48 bg-gradient-to-br from-blue-50 to-indigo-100 rounded-lg flex items-center justify-center">
                        <div className="text-center text-content">
                          <TrendingUp className="h-8 w-8 text-blue-500 mx-auto mb-2" />
                          <p className="text-blue-700">Advanced Performance Metrics</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="card-padding-sm">
                      <CardTitle>Financial Analysis</CardTitle>
                    </CardHeader>
                    <CardContent className="card-padding">
                      <div className="h-48 bg-gradient-to-br from-green-50 to-emerald-100 rounded-lg flex items-center justify-center">
                        <div className="text-center text-content">
                          <BarChart3 className="h-8 w-8 text-green-500 mx-auto mb-2" />
                          <p className="text-green-700">ROI & Cost Analysis</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="reports" className="space-y-6">
                <Card>
                  <CardHeader className="card-padding-sm">
                    <CardTitle>Custom Reports</CardTitle>
                    <CardDescription className="text-content">
                      Generate detailed reports for stakeholders and compliance
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="card-padding">
                    <div className="grid md:grid-cols-3 gap-4">
                      <Button variant="outline" className="h-24 flex-col">
                        <Book className="h-6 w-6 mb-2" />
                        Technical Report
                      </Button>
                      <Button variant="outline" className="h-24 flex-col">
                        <BarChart3 className="h-6 w-6 mb-2" />
                        Financial Analysis
                      </Button>
                      <Button variant="outline" className="h-24 flex-col">
                        <Shield className="h-6 w-6 mb-2" />
                        Compliance Report
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* CTA Section */}
        <Card className="bg-gradient-to-r from-yellow-50 to-orange-50 border-yellow-200 mt-12">
          <CardContent className="card-padding text-center">
            <Crown className="h-12 w-12 text-yellow-500 mx-auto mb-4" />
            <h3 className="text-2xl font-bold mb-4">Ready for Enterprise-Grade Simulation?</h3>
            <p className="text-gray-600 mb-6 max-w-2xl mx-auto text-content">
              Contact our enterprise team to discuss custom implementations, dedicated support, and volume pricing.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="button-primary">
                <Users className="h-5 w-5 mr-2" />
                Contact Enterprise Sales
              </Button>
              <Button variant="outline" size="lg" className="button-outline">
                <Book className="h-5 w-5 mr-2" />
                View Documentation
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
