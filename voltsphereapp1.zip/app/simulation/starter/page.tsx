"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { SiteHeader } from "@/components/site-header"
import { SimulationNav } from "@/components/simulation/simulation-nav"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Key, Book, Activity, Copy, CheckCircle, ChevronLeft, ChevronRight, Code } from "lucide-react"
import { useAuth } from "@/lib/auth-context"

// Static code examples to avoid template literal issues
const CURL_EXAMPLE = `curl -X POST https://api.voltsphere.com/v1/simulate \\
-H "Authorization: Bearer vs_sk_starter_1234567890abcdef" \\
-H "Content-Type: application/json" \\
-d '{
  "batteryCapacity": 15,
  "solarCapacity": 8,
  "loadProfile": "residential",
  "location": "San Francisco, CA",
  "duration": "24h"
}'`

const JS_EXAMPLE = `const response = await fetch('https://api.voltsphere.com/v1/simulate', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer vs_sk_starter_1234567890abcdef',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    batteryCapacity: 15,
    solarCapacity: 8,
    loadProfile: "residential",
    location: "San Francisco, CA",
    duration: "24h"
  })
});

const data = await response.json();
console.log(data);`

// Static API examples
const STARTER_EXAMPLES = [
  {
    title: "Basic Residential Simulation",
    description: "Simple home energy system with solar and battery",
    code: `{
  "batteryCapacity": 15,
  "solarCapacity": 8,
  "loadProfile": "residential",
  "location": "San Francisco, CA",
  "duration": "24h"
}`,
  },
  {
    title: "Commercial Building Analysis",
    description: "Office building with peak demand management",
    code: `{
  "batteryCapacity": 50,
  "solarCapacity": 25,
  "loadProfile": "commercial",
  "timeOfUseRates": true,
  "peakShaving": true,
  "location": "New York, NY"
}`,
  },
]

export default function StarterAPIPage() {
  const { user, isLoading } = useAuth()
  const router = useRouter()
  const [apiKey] = useState("vs_sk_starter_1234567890abcdef")
  const [copied, setCopied] = useState(false)
  const [currentExample, setCurrentExample] = useState(0)

  // Check access - Starter tier or higher
  useEffect(() => {
    if (
      !isLoading &&
      user?.subscriptionTier !== "starter" &&
      user?.subscriptionTier !== "growth" &&
      user?.subscriptionTier !== "enterprise" &&
      user?.role !== "admin"
    ) {
      router.push("/pricing")
    }
  }, [user, isLoading, router])

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50">
        <SiteHeader />
        <div className="container mx-auto py-8">
          <div className="flex items-center justify-center h-96">
            <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600"></div>
          </div>
        </div>
      </div>
    )
  }

  if (
    user?.subscriptionTier !== "starter" &&
    user?.subscriptionTier !== "growth" &&
    user?.subscriptionTier !== "enterprise" &&
    user?.role !== "admin"
  ) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50">
        <SiteHeader />
        <div className="container mx-auto py-8">
          <div className="text-center">
            <div className="flex items-center justify-center gap-2 mb-4">
              <Code className="h-8 w-8 text-blue-600" />
              <h1 className="text-3xl font-bold text-gray-800">Starter API</h1>
              <Badge className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">API</Badge>
            </div>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto mb-8">
              Access to Starter API requires a Starter subscription or higher.
            </p>
            <Button
              onClick={() => router.push("/pricing")}
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
            >
              Upgrade to Starter
            </Button>
          </div>
        </div>
      </div>
    )
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const nextExample = () => {
    setCurrentExample((prev) => (prev + 1) % STARTER_EXAMPLES.length)
  }

  const prevExample = () => {
    setCurrentExample((prev) => (prev - 1 + STARTER_EXAMPLES.length) % STARTER_EXAMPLES.length)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50">
      <SiteHeader />

      <div className="container mx-auto py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Code className="h-8 w-8 text-blue-600" />
            <h1 className="text-3xl font-bold text-gray-800">Starter API</h1>
            <Badge className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">API</Badge>
          </div>
          <p className="text-lg text-gray-600 max-w-4xl mx-auto">
            Begin your API integration journey with our Starter tier. Perfect for small projects and testing.
          </p>
        </div>

        {/* Navigation */}
        <div className="mb-8">
          <SimulationNav userTier={user?.subscriptionTier || "free"} />
        </div>

        {/* Main Content */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <Book className="h-4 w-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="authentication" className="flex items-center gap-2">
              <Key className="h-4 w-4" />
              Authentication
            </TabsTrigger>
            <TabsTrigger value="examples" className="flex items-center gap-2">
              <Code className="h-4 w-4" />
              Examples
            </TabsTrigger>
            <TabsTrigger value="documentation" className="flex items-center gap-2">
              <Activity className="h-4 w-4" />
              Documentation
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Code className="h-5 w-5 text-blue-600" />
                    Starter Features
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600">
                    The Starter API provides essential simulation capabilities for your projects:
                  </p>
                  <ul className="space-y-2 text-gray-600">
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      5,000 API calls per month
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      Basic simulation parameters
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      Up to 100kWh battery capacity
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      Standard support
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Key className="h-5 w-5 text-blue-600" />
                    API Limits
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                      <span className="font-medium">Monthly Calls</span>
                      <Badge variant="outline">5,000</Badge>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                      <span className="font-medium">Rate Limit</span>
                      <Badge variant="outline">100/minute</Badge>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                      <span className="font-medium">Max Battery Size</span>
                      <Badge variant="outline">100 kWh</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Authentication Tab */}
          <TabsContent value="authentication">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Key className="h-5 w-5 text-blue-600" />
                  API Authentication
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-3">Your Starter API Key</h3>
                  <div className="flex items-center gap-2">
                    <Input value={apiKey} readOnly className="font-mono text-sm" />
                    <Button onClick={() => copyToClipboard(apiKey)} variant="outline" size="sm">
                      {copied ? <CheckCircle className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                    </Button>
                  </div>
                  <p className="text-sm text-gray-600 mt-2">Keep your API key secure and never share it publicly.</p>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-3">Authentication Method</h3>
                  <p className="text-gray-600 mb-4">
                    Include your API key in the Authorization header of every request:
                  </p>
                  <div className="bg-gray-900 text-gray-100 p-4 rounded-lg font-mono text-sm">
                    Authorization: Bearer {apiKey}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Examples Tab */}
          <TabsContent value="examples">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Code Examples</CardTitle>
                  <p className="text-gray-600">Ready-to-use code snippets in popular languages</p>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="curl" className="space-y-4">
                    <TabsList>
                      <TabsTrigger value="curl">cURL</TabsTrigger>
                      <TabsTrigger value="javascript">JavaScript</TabsTrigger>
                    </TabsList>

                    <TabsContent value="curl">
                      <div className="relative">
                        <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg text-sm overflow-x-auto">
                          <code>{CURL_EXAMPLE}</code>
                        </pre>
                        <Button
                          onClick={() => copyToClipboard(CURL_EXAMPLE)}
                          variant="outline"
                          size="sm"
                          className="absolute top-2 right-2"
                        >
                          {copied ? <CheckCircle className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                        </Button>
                      </div>
                    </TabsContent>

                    <TabsContent value="javascript">
                      <div className="relative">
                        <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg text-sm overflow-x-auto">
                          <code>{JS_EXAMPLE}</code>
                        </pre>
                        <Button
                          onClick={() => copyToClipboard(JS_EXAMPLE)}
                          variant="outline"
                          size="sm"
                          className="absolute top-2 right-2"
                        >
                          {copied ? <CheckCircle className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                        </Button>
                      </div>
                    </TabsContent>
                  </Tabs>

                  {/* Use Cases Carousel */}
                  <div className="mt-8">
                    <Card className="border-2 border-blue-200">
                      <CardHeader>
                        <CardTitle className="flex items-center justify-between">
                          <span>Starter Use Cases</span>
                          <div className="flex items-center gap-2">
                            <Button onClick={prevExample} variant="outline" size="sm">
                              <ChevronLeft className="h-4 w-4" />
                            </Button>
                            <span className="text-sm text-gray-500">
                              {currentExample + 1} of {STARTER_EXAMPLES.length}
                            </span>
                            <Button onClick={nextExample} variant="outline" size="sm">
                              <ChevronRight className="h-4 w-4" />
                            </Button>
                          </div>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div className="text-center">
                            <h3 className="text-xl font-semibold text-gray-800 mb-2">
                              {STARTER_EXAMPLES[currentExample].title}
                            </h3>
                            <p className="text-gray-600 mb-4">{STARTER_EXAMPLES[currentExample].description}</p>
                          </div>

                          <div className="relative">
                            <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg text-sm overflow-x-auto max-h-96">
                              <code>{STARTER_EXAMPLES[currentExample].code}</code>
                            </pre>
                            <Button
                              onClick={() => copyToClipboard(STARTER_EXAMPLES[currentExample].code)}
                              variant="outline"
                              size="sm"
                              className="absolute top-2 right-2"
                            >
                              {copied ? <CheckCircle className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Documentation Tab */}
          <TabsContent value="documentation">
            <Card>
              <CardHeader>
                <CardTitle>API Documentation</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">
                  For complete API documentation, please refer to our developer portal.
                </p>
                <Button className="bg-blue-600 hover:bg-blue-700">
                  <Book className="mr-2 h-4 w-4" />
                  View Documentation
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
