"use client"

import { useState } from "react"
import { SiteHeader } from "@/components/site-header"
import { SimulationNav } from "@/components/simulation/simulation-nav"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Code, Key, Book, Activity, Copy, CheckCircle, ChevronLeft, ChevronRight } from "lucide-react"
import { useAuth } from "@/lib/auth-context"

// Static code examples to avoid template literal issues
const CURL_EXAMPLE = `curl -X POST https://api.voltsphere.com/v1/simulate \\
-H "Authorization: Bearer vs_sk_1234567890abcdef" \\
-H "Content-Type: application/json" \\
-d '{
  "batteryCapacity": 15,
  "solarCapacity": 8,
  "loadProfile": "residential",
  "location": "San Francisco, CA",
  "duration": "24h"
}'`

const JS_EXAMPLE = `const response = await fetch('https://api.voltsphere.com/v1/simulate', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer vs_sk_1234567890abcdef',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    batteryCapacity: 15,
    solarCapacity: 8,
    loadProfile: "residential",
    location: "San Francisco, CA",
    duration: "24h"
  })
});

const data = await response.json();
console.log(data);`

const PYTHON_EXAMPLE = `import requests

url = "https://api.voltsphere.com/v1/simulate"
headers = {
  "Authorization": f"Bearer vs_sk_1234567890abcdef",
  "Content-Type": "application/json"
}
data = {
  "batteryCapacity": 15,
  "solarCapacity": 8,
  "loadProfile": "residential",
  "location": "San Francisco, CA",
  "duration": "24h"
}

response = requests.post(url, headers=headers, json=data)
result = response.json()
print(result)`

// Static API examples
const API_EXAMPLES = [
  {
    title: "Basic Residential Simulation",
    description: "Simple home energy system with solar and battery",
    code: `{
  "batteryCapacity": 15,
  "solarCapacity": 8,
  "loadProfile": "residential",
  "location": "San Francisco, CA",
  "duration": "24h"
}`,
  },
  {
    title: "Commercial Building Analysis",
    description: "Office building with peak demand management",
    code: `{
  "batteryCapacity": 50,
  "solarCapacity": 25,
  "loadProfile": "commercial",
  "timeOfUseRates": true,
  "peakShaving": true,
  "location": "New York, NY"
}`,
  },
]

export default function APIPage() {
  const { user } = useAuth()
  const [apiKey] = useState("vs_sk_1234567890abcdef")
  const [copied, setCopied] = useState(false)
  const [currentExample, setCurrentExample] = useState(0)

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const nextExample = () => {
    setCurrentExample((prev) => (prev + 1) % API_EXAMPLES.length)
  }

  const prevExample = () => {
    setCurrentExample((prev) => (prev - 1 + API_EXAMPLES.length) % API_EXAMPLES.length)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50">
      <SiteHeader />

      <div className="container mx-auto py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Code className="h-8 w-8 text-blue-600" />
            <h1 className="text-3xl font-bold text-gray-800">VoltSphere API</h1>
            <Badge className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">API</Badge>
          </div>
          <p className="text-lg text-gray-600 max-w-4xl mx-auto">
            Integrate powerful microgrid simulation capabilities directly into your applications with our RESTful API.
          </p>
        </div>

        {/* Navigation */}
        <div className="mb-8">
          <SimulationNav userTier={user?.subscriptionTier || "free"} />
        </div>

        {/* Main Content */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <Book className="h-4 w-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="authentication" className="flex items-center gap-2">
              <Key className="h-4 w-4" />
              Authentication
            </TabsTrigger>
            <TabsTrigger value="endpoints" className="flex items-center gap-2">
              <Activity className="h-4 w-4" />
              Endpoints
            </TabsTrigger>
            <TabsTrigger value="examples" className="flex items-center gap-2">
              <Code className="h-4 w-4" />
              Examples
            </TabsTrigger>
            <TabsTrigger value="scenarios" className="flex items-center gap-2">
              <Activity className="h-4 w-4" />
              Use Cases
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="h-5 w-5 text-blue-600" />
                    Getting Started
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600">
                    The VoltSphere API allows you to run microgrid simulations programmatically.
                  </p>
                  <ul className="space-y-2 text-gray-600">
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      Batch processing multiple scenarios
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      Integration with existing workflows
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Key className="h-5 w-5 text-purple-600" />
                    API Limits
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                      <span className="font-medium">Starter Plan</span>
                      <Badge variant="outline">5,000 calls/month</Badge>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-purple-50 rounded-lg">
                      <span className="font-medium">Growth Plan</span>
                      <Badge variant="outline">50,000 calls/month</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Authentication Tab */}
          <TabsContent value="authentication">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Key className="h-5 w-5 text-blue-600" />
                  API Authentication
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-3">Your API Key</h3>
                  <div className="flex items-center gap-2">
                    <Input value={apiKey} readOnly className="font-mono text-sm" />
                    <Button onClick={() => copyToClipboard(apiKey)} variant="outline" size="sm">
                      {copied ? <CheckCircle className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Endpoints Tab */}
          <TabsContent value="endpoints">
            <Card>
              <CardHeader>
                <CardTitle>POST /simulate</CardTitle>
                <p className="text-gray-600">Run a microgrid simulation with specified parameters</p>
              </CardHeader>
              <CardContent>
                <p>See documentation for details</p>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Examples Tab */}
          <TabsContent value="examples">
            <Card>
              <CardHeader>
                <CardTitle>Code Examples</CardTitle>
                <p className="text-gray-600">Ready-to-use code snippets in popular languages</p>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="curl" className="space-y-4">
                  <TabsList>
                    <TabsTrigger value="curl">cURL</TabsTrigger>
                    <TabsTrigger value="javascript">JavaScript</TabsTrigger>
                    <TabsTrigger value="python">Python</TabsTrigger>
                  </TabsList>

                  <TabsContent value="curl">
                    <div className="relative">
                      <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg text-sm overflow-x-auto">
                        <code>{CURL_EXAMPLE}</code>
                      </pre>
                      <Button
                        onClick={() => copyToClipboard(CURL_EXAMPLE)}
                        variant="outline"
                        size="sm"
                        className="absolute top-2 right-2"
                      >
                        {copied ? <CheckCircle className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                  </TabsContent>

                  <TabsContent value="javascript">
                    <div className="relative">
                      <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg text-sm overflow-x-auto">
                        <code>{JS_EXAMPLE}</code>
                      </pre>
                      <Button
                        onClick={() => copyToClipboard(JS_EXAMPLE)}
                        variant="outline"
                        size="sm"
                        className="absolute top-2 right-2"
                      >
                        {copied ? <CheckCircle className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                  </TabsContent>

                  <TabsContent value="python">
                    <div className="relative">
                      <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg text-sm overflow-x-auto">
                        <code>{PYTHON_EXAMPLE}</code>
                      </pre>
                      <Button
                        onClick={() => copyToClipboard(PYTHON_EXAMPLE)}
                        variant="outline"
                        size="sm"
                        className="absolute top-2 right-2"
                      >
                        {copied ? <CheckCircle className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Use Cases Carousel Tab */}
          <TabsContent value="scenarios">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>API Use Case Examples</span>
                  <div className="flex items-center gap-2">
                    <Button onClick={prevExample} variant="outline" size="sm">
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <span className="text-sm text-gray-500">
                      {currentExample + 1} of {API_EXAMPLES.length}
                    </span>
                    <Button onClick={nextExample} variant="outline" size="sm">
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center">
                    <h3 className="text-xl font-semibold text-gray-800 mb-2">{API_EXAMPLES[currentExample].title}</h3>
                    <p className="text-gray-600 mb-4">{API_EXAMPLES[currentExample].description}</p>
                  </div>

                  <div className="relative">
                    <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg text-sm overflow-x-auto">
                      <code>{API_EXAMPLES[currentExample].code}</code>
                    </pre>
                    <Button
                      onClick={() => copyToClipboard(API_EXAMPLES[currentExample].code)}
                      variant="outline"
                      size="sm"
                      className="absolute top-2 right-2"
                    >
                      {copied ? <CheckCircle className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
