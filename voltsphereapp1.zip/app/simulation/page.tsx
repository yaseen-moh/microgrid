"use client"

import { useState, useRef } from "react"
import { SiteHeader } from "@/components/site-header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { SimulationConfig } from "@/lib/simulation/engine"
import { Battery, Sun, Zap, Play, Settings, Lock } from "lucide-react"
import { SimulationEngine } from "@/lib/simulation/engine"
import { MicrogridChart } from "@/components/microgrid-chart"
import { useAuth } from "@/lib/auth-context"
import { LoginDialog } from "@/components/auth/login-dialog"

export default function SimulationPage() {
  const { user, loading } = useAuth() // FIXED: Get loading state
  const [showLoginDialog, setShowLoginDialog] = useState(false)
  const resultsRef = useRef<HTMLDivElement>(null)

  const [config, setConfig] = useState<SimulationConfig>({
    batteryCapacity: 15,
    batteryEfficiency: 90,
    solarEnabled: true,
    batteryType: "lithium",
    loadProfileType: "residential",
    useRealWeather: false,
    weatherLocation: "San Francisco, CA",
    timeOfUseRates: false,
    simulationDuration: "24h",
    solarCapacity: 10,
    inverterEfficiency: 96,
    systemLosses: 14,
    gridCostPerKwh: 0.15,
    solarCostPerWatt: 3.0,
    batteryCostPerKwh: 500,
    discountRate: 0.06,
    systemLifespan: 25,
  })

  const [isRunning, setIsRunning] = useState(false)
  const [results, setResults] = useState<any>(null)

  // FIXED: Completely prevent auto-login - require manual authentication
  const handleSimulationAccess = () => {
    console.log("handleSimulationAccess called, user:", user) // Debug log

    // FIXED: Explicitly check if user is null or undefined
    if (!user) {
      console.log("No user found, showing login dialog") // Debug log
      setShowLoginDialog(true)
      return
    }

    console.log("User found, running simulation") // Debug log
    runSimulation()
  }

  const runSimulation = async () => {
    // FIXED: Double-check user exists before running simulation
    if (!user) {
      setShowLoginDialog(true)
      return
    }

    setIsRunning(true)
    try {
      await new Promise((resolve) => setTimeout(resolve, 2000))
      const simulationResults = await SimulationEngine.runSimulation(config)
      setResults(simulationResults)

      setTimeout(() => {
        resultsRef.current?.scrollIntoView({
          behavior: "smooth",
          block: "start",
        })
      }, 500)
    } catch (error) {
      console.error("Simulation error:", error)
    } finally {
      setIsRunning(false)
    }
  }

  const updateConfig = (updates: Partial<SimulationConfig>) => {
    setConfig((prev) => ({ ...prev, ...updates }))
  }

  // FIXED: Show loading state while checking authentication
  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-primary">
        <SiteHeader />
        <div className="container mx-auto px-8 py-12 text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-primary">
      <SiteHeader />

      <section className="section-spacing-sm">
        <div className="container-clean">
          <div className="text-center mb-16 animate-fade-in">
            <div className="flex items-center justify-center gap-6 mb-8">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-blue-400 to-purple-500 rounded-3xl blur-lg opacity-30 animate-float"></div>
                <div className="relative p-6 bg-gradient-to-r from-blue-600 to-purple-600 rounded-3xl text-white shadow-2xl hover-lift animate-float">
                  <Zap className="h-12 w-12" />
                </div>
              </div>
              <div>
                <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 mb-4">Free Simulation</h1>
                <div className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-blue-100 to-purple-100 text-blue-800 font-bold rounded-2xl border border-blue-200">
                  <Zap className="h-5 w-5 mr-2" />
                  Always Free
                </div>
              </div>
            </div>
            <p className="text-2xl text-gray-700 max-w-3xl mx-auto leading-relaxed">
              Design your perfect microgrid in seconds with our powerful simulation engine
            </p>

            {/* FIXED: Show authentication status clearly */}
            {!user && (
              <div className="mt-8 p-6 bg-yellow-50 border border-yellow-200 rounded-2xl max-w-2xl mx-auto">
                <div className="flex items-center justify-center gap-3 text-yellow-800">
                  <Lock className="h-6 w-6" />
                  <span className="text-lg font-semibold">Sign in required to run simulations</span>
                </div>
              </div>
            )}
          </div>

          {/* Configuration Cards */}
          <div className="max-w-6xl mx-auto mb-20 animate-fade-in">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 lg:gap-12 stagger-children">
              {/* Battery Card */}
              <Card className="card-enhanced hover-lift">
                <CardHeader className="pb-6">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="p-4 bg-gradient-to-r from-green-100 to-emerald-100 rounded-2xl">
                      <Battery className="h-8 w-8 text-green-600" />
                    </div>
                    <div>
                      <CardTitle className="text-2xl font-bold text-gray-900">Battery Storage</CardTitle>
                      <p className="text-gray-600 text-lg">Energy storage capacity</p>
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="px-8 pb-8 space-y-8">
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <span className="text-lg font-semibold text-gray-800">Capacity</span>
                      <div className="px-4 py-2 bg-gray-100 rounded-xl font-bold text-gray-900 text-lg">
                        {config.batteryCapacity} kWh
                      </div>
                    </div>
                    <Slider
                      value={[config.batteryCapacity]}
                      onValueChange={([value]) => updateConfig({ batteryCapacity: value })}
                      max={50}
                      min={5}
                      step={5}
                      className="w-full"
                    />
                    <div className="flex justify-between text-gray-500 font-medium">
                      <span>5 kWh</span>
                      <span>50 kWh</span>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <Label className="text-lg font-semibold text-gray-800">Battery Type</Label>
                    <Select
                      value={config.batteryType}
                      onValueChange={(value: any) => updateConfig({ batteryType: value })}
                    >
                      <SelectTrigger className="input-clean">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="lithium">Lithium-ion (High efficiency)</SelectItem>
                        <SelectItem value="lead-acid">Lead-acid (Budget friendly)</SelectItem>
                        <SelectItem value="flow">Flow Battery (Long duration)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>

              {/* Solar Card */}
              <Card className="card-enhanced hover-lift">
                <CardHeader className="pb-6">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="p-4 bg-gradient-to-r from-yellow-100 to-orange-100 rounded-2xl">
                      <Sun className="h-8 w-8 text-yellow-600" />
                    </div>
                    <div>
                      <CardTitle className="text-2xl font-bold text-gray-900">Solar Power</CardTitle>
                      <p className="text-gray-600 text-lg">Clean energy generation</p>
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="px-8 pb-8 space-y-8">
                  <div className="flex items-center justify-between p-6 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-2xl border-2 border-yellow-200">
                    <Label htmlFor="solar-toggle" className="flex items-center gap-3 cursor-pointer">
                      <Sun className="h-6 w-6 text-yellow-600" />
                      <span className="font-bold text-yellow-800 text-lg">Enable Solar Power</span>
                    </Label>
                    <Switch
                      id="solar-toggle"
                      checked={config.solarEnabled}
                      onCheckedChange={(checked) => updateConfig({ solarEnabled: checked })}
                      className="data-[state=checked]:bg-yellow-600"
                    />
                  </div>

                  {config.solarEnabled && (
                    <div className="space-y-6 animate-fade-in">
                      <div className="flex items-center justify-between">
                        <span className="text-lg font-semibold text-gray-800">Capacity</span>
                        <div className="px-4 py-2 bg-gray-100 rounded-xl font-bold text-gray-900 text-lg">
                          {config.solarCapacity} kW
                        </div>
                      </div>
                      <Slider
                        value={[config.solarCapacity]}
                        onValueChange={([value]) => updateConfig({ solarCapacity: value })}
                        max={25}
                        min={5}
                        step={5}
                        className="w-full"
                      />
                      <div className="flex justify-between text-gray-500 font-medium">
                        <span>5 kW</span>
                        <span>25 kW</span>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Load Card */}
              <Card className="card-enhanced hover-lift">
                <CardHeader className="pb-6">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="p-4 bg-gradient-to-r from-blue-100 to-indigo-100 rounded-2xl">
                      <Settings className="h-8 w-8 text-blue-600" />
                    </div>
                    <div>
                      <CardTitle className="text-2xl font-bold text-gray-900">Energy Usage</CardTitle>
                      <p className="text-gray-600 text-lg">Power demand profile</p>
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="px-8 pb-8 space-y-8">
                  <div className="space-y-4">
                    <Label className="text-lg font-semibold text-gray-800">Load Profile Type</Label>
                    <div className="grid grid-cols-2 gap-4">
                      <Button
                        variant={config.loadProfileType === "residential" ? "default" : "outline"}
                        onClick={() => updateConfig({ loadProfileType: "residential" })}
                        className={`h-16 text-lg font-semibold rounded-2xl transition-smooth ${
                          config.loadProfileType === "residential"
                            ? "bg-gradient-to-r from-blue-600 to-purple-600 text-white"
                            : "btn-outline"
                        }`}
                      >
                        Home
                      </Button>
                      <Button
                        variant={config.loadProfileType === "commercial" ? "default" : "outline"}
                        onClick={() => updateConfig({ loadProfileType: "commercial" })}
                        className={`h-16 text-lg font-semibold rounded-2xl transition-smooth ${
                          config.loadProfileType === "commercial"
                            ? "bg-gradient-to-r from-blue-600 to-purple-600 text-white"
                            : "btn-outline"
                        }`}
                      >
                        Business
                      </Button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-6 bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl border-2 border-blue-200">
                    <Label htmlFor="tou-toggle" className="flex items-center gap-3 cursor-pointer">
                      <Zap className="h-6 w-6 text-blue-600" />
                      <span className="font-bold text-blue-800 text-lg">Time-of-Use Rates</span>
                    </Label>
                    <Switch
                      id="tou-toggle"
                      checked={config.timeOfUseRates}
                      onCheckedChange={(checked) => updateConfig({ timeOfUseRates: checked })}
                      className="data-[state=checked]:bg-blue-600"
                    />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Run Simulation Button */}
            <div className="text-center mt-16 animate-scale-in">
              <Button
                onClick={handleSimulationAccess}
                disabled={isRunning}
                className="h-20 px-16 btn-primary text-2xl rounded-3xl shadow-2xl hover:shadow-3xl hover-lift"
              >
                {/* FIXED: Show different states based on authentication */}
                {!user ? (
                  <>
                    <Lock className="mr-4 h-8 w-8" />
                    Sign In to Run Simulation
                  </>
                ) : isRunning ? (
                  <>
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mr-4"></div>
                    Running Simulation...
                  </>
                ) : (
                  <>
                    <Play className="mr-4 h-8 w-8" />
                    Run Free Simulation
                  </>
                )}
              </Button>
            </div>
          </div>

          {/* Results Section - FIXED: Only show if user is authenticated */}
          {user && (
            <div ref={resultsRef} className="max-w-7xl mx-auto scroll-mt-20">
              {results ? (
                <div className="space-y-12 animate-fade-in">
                  {/* Results content here */}
                  <Card className="card-enhanced animate-slide-up">
                    <CardHeader className="p-8">
                      <CardTitle className="text-3xl font-bold text-center text-gray-900 mb-4">
                        Simulation Results
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-8">
                      <MicrogridChart data={results} showSolar={config.solarEnabled} />
                    </CardContent>
                  </Card>
                </div>
              ) : (
                <Card className="card-enhanced opacity-60">
                  <CardContent className="flex items-center justify-center h-80">
                    <div className="text-center">
                      <div className="p-8 bg-gray-100 rounded-full w-24 h-24 flex items-center justify-center mx-auto mb-6">
                        <Play className="h-12 w-12 text-gray-400" />
                      </div>
                      <h3 className="text-2xl font-bold text-gray-500 mb-4">Ready to Simulate</h3>
                      <p className="text-gray-500 text-lg">Configure your system above and click run to see results</p>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          )}
        </div>
      </section>

      {/* FIXED: Login dialog for manual authentication */}
      <LoginDialog open={showLoginDialog} onOpenChange={setShowLoginDialog} />
    </div>
  )
}
