"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { SiteHeader } from "@/components/site-header"
import { SimulationNav } from "@/components/simulation/simulation-nav"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Crown, Activity, Settings, BarChart3, Battery, Sun, Cloud, DollarSign, Globe } from "lucide-react"
import { SimulationEngine, type SimulationConfig } from "@/lib/simulation/engine"
import { ProChart } from "@/components/simulation/pro-chart"
import { useAuth } from "@/lib/auth-context"
import { canAccessPro } from "@/lib/auth"

export default function ProSimulationPage() {
  const { user, isLoading } = useAuth()
  const router = useRouter()
  const [config, setConfig] = useState<SimulationConfig>({
    batteryCapacity: 15,
    batteryEfficiency: 92,
    solarEnabled: true,
    batteryType: "lithium",
    loadProfileType: "residential",
    useRealWeather: false,
    weatherLocation: "San Francisco, CA",
    timeOfUseRates: false,
    simulationDuration: "24h",
    solarCapacity: 12,
    inverterEfficiency: 96,
    systemLosses: 14,
    gridCostPerKwh: 0.15,
    solarCostPerWatt: 3.0,
    batteryCostPerKwh: 500,
    discountRate: 0.06,
    systemLifespan: 25,
  })

  const [isRunning, setIsRunning] = useState(false)
  const [results, setResults] = useState<any>(null)

  // Check access on component mount - allow admin users regardless of subscription
  useEffect(() => {
    if (!isLoading && !canAccessPro(user) && user?.role !== "admin") {
      router.push("/pricing")
    }
  }, [user, isLoading, router])

  // Show loading while checking auth
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50">
        <SiteHeader />
        <div className="container mx-auto mobile-padding py-8">
          <div className="flex items-center justify-center h-96">
            <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600"></div>
          </div>
        </div>
      </div>
    )
  }

  // Show access denied if user doesn't have pro access and is not admin
  if (!canAccessPro(user) && user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50">
        <SiteHeader />
        <div className="container mx-auto mobile-padding py-8">
          <div className="text-center">
            <div className="flex items-center justify-center gap-2 mb-4">
              <Crown className="h-8 w-8 text-purple-600" />
              <h1 className="mobile-heading-xl text-gray-800">Pro Simulation</h1>
              <Badge className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">Pro</Badge>
            </div>
            <p className="mobile-body-lg text-gray-600 max-w-2xl mx-auto mb-8">
              Access to Pro Simulation requires a Pro subscription or higher.
            </p>
            <Button
              onClick={() => router.push("/pricing")}
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 mobile-btn"
            >
              Upgrade to Pro
            </Button>
          </div>
        </div>
      </div>
    )
  }

  const runSimulation = async () => {
    setIsRunning(true)
    try {
      await new Promise((resolve) => setTimeout(resolve, 2000))
      const simulationResults = await SimulationEngine.runSimulation(config)
      setResults(simulationResults)
    } catch (error) {
      console.error("Simulation error:", error)
    } finally {
      setIsRunning(false)
    }
  }

  const updateConfig = (updates: Partial<SimulationConfig>) => {
    setConfig((prev) => ({ ...prev, ...updates }))
  }

  const cities = [
    "San Francisco, CA",
    "New York, NY",
    "Chicago, IL",
    "Austin, TX",
    "Miami, FL",
    "Phoenix, AZ",
    "Seattle, WA",
    "Denver, CO",
    "Los Angeles, CA",
    "Boston, MA",
    "Atlanta, GA",
    "Dallas, TX",
  ]

  // Determine the effective tier for the user - admin gets enterprise tier
  const effectiveTier = user?.role === "admin" ? "enterprise" : user?.subscriptionTier || "free"

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50">
      <SiteHeader />

      <div className="container mx-auto mobile-padding py-8">
        {/* Header */}
        <div className="text-center mb-8 animate-fade-in">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Crown className="h-8 w-8 text-purple-600" />
            <h1 className="mobile-heading-xl text-gray-800">Pro Simulation Suite</h1>
            <Badge className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">Pro</Badge>
          </div>
          <p className="mobile-body-lg text-gray-600 max-w-4xl mx-auto">
            Advanced microgrid simulation with weather integration, multiple battery types, and comprehensive analytics.
          </p>
        </div>

        {/* Navigation */}
        <div className="mb-8">
          <SimulationNav userTier={effectiveTier} />
        </div>

        {/* Main Content */}
        <Tabs defaultValue="simulation" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 mobile-rounded">
            <TabsTrigger value="simulation" className="flex items-center gap-2">
              <Activity className="h-4 w-4" />
              Simulation
            </TabsTrigger>
            <TabsTrigger value="advanced" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Advanced Settings
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Cost Analytics
            </TabsTrigger>
          </TabsList>

          {/* Simulation Tab */}
          <TabsContent value="simulation">
            <div className="grid lg:grid-cols-4 gap-6">
              {/* Controls */}
              <div className="lg:col-span-1">
                <Card className="card-enhanced mobile-rounded">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                      <Settings className="h-5 w-5 text-blue-600" />
                      Pro Controls
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-3">
                      <Label className="flex items-center gap-2 font-semibold">
                        <Battery className="h-4 w-4 text-green-600" />
                        Battery Capacity: {config.batteryCapacity} kWh
                      </Label>
                      <Slider
                        value={[config.batteryCapacity]}
                        onValueChange={([value]) => updateConfig({ batteryCapacity: value })}
                        max={100}
                        min={5}
                        step={1}
                        className="w-full"
                      />
                    </div>

                    <div className="space-y-3">
                      <Label className="font-semibold">Battery Type</Label>
                      <Select
                        value={config.batteryType}
                        onValueChange={(value) => updateConfig({ batteryType: value })}
                      >
                        <SelectTrigger className="mobile-rounded">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="lithium">Lithium-ion (92% efficiency)</SelectItem>
                          <SelectItem value="lead-acid">Lead-acid (85% efficiency)</SelectItem>
                          <SelectItem value="flow">Flow Battery (88% efficiency)</SelectItem>
                          <SelectItem value="sodium">Sodium-ion (90% efficiency)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-3">
                      <Label className="font-semibold">Solar Capacity: {config.solarCapacity} kW</Label>
                      <Slider
                        value={[config.solarCapacity]}
                        onValueChange={([value]) => updateConfig({ solarCapacity: value })}
                        max={50}
                        min={0}
                        step={1}
                        className="w-full"
                      />
                    </div>

                    <div className="space-y-3">
                      <Label className="font-semibold">Load Profile</Label>
                      <Select
                        value={config.loadProfileType}
                        onValueChange={(value) => updateConfig({ loadProfileType: value })}
                      >
                        <SelectTrigger className="mobile-rounded">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="residential">Residential Home</SelectItem>
                          <SelectItem value="commercial">Commercial Building</SelectItem>
                          <SelectItem value="industrial">Industrial Facility</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-xl">
                      <Label htmlFor="solar" className="flex items-center gap-2">
                        <Sun className="h-4 w-4 text-yellow-600" />
                        Solar Power
                      </Label>
                      <Switch
                        id="solar"
                        checked={config.solarEnabled}
                        onCheckedChange={(checked) => updateConfig({ solarEnabled: checked })}
                      />
                    </div>

                    <div className="flex items-center justify-between p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl">
                      <Label htmlFor="weather" className="flex items-center gap-2">
                        <Cloud className="h-4 w-4 text-blue-600" />
                        Real Weather Data
                      </Label>
                      <Switch
                        id="weather"
                        checked={config.useRealWeather}
                        onCheckedChange={(checked) => updateConfig({ useRealWeather: checked })}
                      />
                    </div>

                    <div className="flex items-center justify-between p-4 bg-gradient-to-r from-green-50 to-teal-50 rounded-xl">
                      <Label htmlFor="tou" className="flex items-center gap-2">
                        <Activity className="h-4 w-4 text-green-600" />
                        Time-of-Use Rates
                      </Label>
                      <Switch
                        id="tou"
                        checked={config.timeOfUseRates}
                        onCheckedChange={(checked) => updateConfig({ timeOfUseRates: checked })}
                      />
                    </div>

                    <Button
                      onClick={runSimulation}
                      disabled={isRunning}
                      className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 mobile-btn mobile-rounded font-semibold"
                    >
                      {isRunning ? "Running Pro Simulation..." : "Run Pro Simulation"}
                    </Button>
                  </CardContent>
                </Card>
              </div>

              {/* Results */}
              <div className="lg:col-span-3">
                {results ? (
                  <div className="space-y-6">
                    {/* Chart */}
                    <Card className="card-enhanced mobile-rounded">
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <BarChart3 className="h-5 w-5 text-purple-600" />
                          Pro Energy Analysis
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ProChart data={results} config={config} />
                      </CardContent>
                    </Card>

                    {/* Summary Stats */}
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <Card className="card-enhanced mobile-rounded">
                        <CardContent className="p-6">
                          <div className="flex items-center gap-3 mb-2">
                            <Sun className="h-5 w-5 text-yellow-600" />
                            <span className="font-semibold">Solar</span>
                          </div>
                          <p className="text-2xl font-bold text-yellow-700">{results.summary.totalSolar} kWh</p>
                          <p className="text-sm text-gray-600">{results.summary.solarUtilization}% utilization</p>
                        </CardContent>
                      </Card>

                      <Card className="card-enhanced mobile-rounded">
                        <CardContent className="p-6">
                          <div className="flex items-center gap-3 mb-2">
                            <Battery className="h-5 w-5 text-green-600" />
                            <span className="font-semibold">Battery</span>
                          </div>
                          <p className="text-2xl font-bold text-green-700">{results.summary.avgBattery}%</p>
                          <p className="text-sm text-gray-600">Average SOC</p>
                        </CardContent>
                      </Card>

                      <Card className="card-enhanced mobile-rounded">
                        <CardContent className="p-6">
                          <div className="flex items-center gap-3 mb-2">
                            <Activity className="h-5 w-5 text-blue-600" />
                            <span className="font-semibold">Grid Independence</span>
                          </div>
                          <p className="text-2xl font-bold text-blue-700">{results.summary.gridIndependence}%</p>
                          <p className="text-sm text-gray-600">Self-sufficiency</p>
                        </CardContent>
                      </Card>

                      <Card className="card-enhanced mobile-rounded">
                        <CardContent className="p-6">
                          <div className="flex items-center gap-3 mb-2">
                            <DollarSign className="h-5 w-5 text-purple-600" />
                            <span className="font-semibold">Daily Cost</span>
                          </div>
                          <p className="text-2xl font-bold text-purple-700">${results.economics.dailyCost}</p>
                          <p className="text-sm text-gray-600">Grid electricity</p>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                ) : (
                  <Card className="card-enhanced mobile-rounded">
                    <CardContent className="flex items-center justify-center h-96">
                      <div className="text-center">
                        {isRunning ? (
                          <>
                            <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-purple-600 mx-auto mb-4"></div>
                            <h3 className="text-xl font-semibold text-gray-600 mb-2">Running Pro Simulation...</h3>
                            <p className="text-gray-500">Calculating advanced energy flows with weather data</p>
                          </>
                        ) : (
                          <>
                            <Crown className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                            <h3 className="text-xl font-semibold text-gray-600 mb-2">Ready for Pro Simulation</h3>
                            <p className="text-gray-500">Configure your advanced settings and run the simulation</p>
                          </>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>
          </TabsContent>

          {/* Advanced Settings Tab */}
          <TabsContent value="advanced">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Weather & Location */}
              <Card className="card-enhanced mobile-rounded">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3">
                    <Globe className="h-5 w-5 text-blue-600" />
                    Weather & Location
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label className="font-semibold">Weather Location</Label>
                    <Select
                      value={config.weatherLocation}
                      onValueChange={(value) => updateConfig({ weatherLocation: value })}
                    >
                      <SelectTrigger className="mt-2 mobile-rounded">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {cities.map((city) => (
                          <SelectItem key={city} value={city}>
                            {city}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="font-semibold">Simulation Duration</Label>
                    <Select
                      value={config.simulationDuration}
                      onValueChange={(value) => updateConfig({ simulationDuration: value })}
                    >
                      <SelectTrigger className="mt-2 mobile-rounded">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="24h">24 Hours</SelectItem>
                        <SelectItem value="7d">7 Days</SelectItem>
                        <SelectItem value="30d">30 Days</SelectItem>
                        <SelectItem value="1y">1 Year</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="font-semibold">Inverter Efficiency: {config.inverterEfficiency}%</Label>
                    <Slider
                      value={[config.inverterEfficiency]}
                      onValueChange={([value]) => updateConfig({ inverterEfficiency: value })}
                      max={99}
                      min={90}
                      step={0.5}
                      className="mt-2"
                    />
                  </div>

                  <div>
                    <Label className="font-semibold">System Losses: {config.systemLosses}%</Label>
                    <Slider
                      value={[config.systemLosses]}
                      onValueChange={([value]) => updateConfig({ systemLosses: value })}
                      max={25}
                      min={5}
                      step={1}
                      className="mt-2"
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Economic Parameters */}
              <Card className="card-enhanced mobile-rounded">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3">
                    <DollarSign className="h-5 w-5 text-green-600" />
                    Economic Parameters
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="font-semibold">Grid Cost ($/kWh)</Label>
                      <Input
                        type="number"
                        step="0.01"
                        value={config.gridCostPerKwh}
                        onChange={(e) => updateConfig({ gridCostPerKwh: Number.parseFloat(e.target.value) || 0.15 })}
                        className="mt-1"
                      />
                    </div>

                    <div>
                      <Label className="font-semibold">Solar Cost ($/W)</Label>
                      <Input
                        type="number"
                        step="0.1"
                        value={config.solarCostPerWatt}
                        onChange={(e) => updateConfig({ solarCostPerWatt: Number.parseFloat(e.target.value) || 3.0 })}
                        className="mt-1"
                      />
                    </div>

                    <div>
                      <Label className="font-semibold">Battery Cost ($/kWh)</Label>
                      <Input
                        type="number"
                        step="10"
                        value={config.batteryCostPerKwh}
                        onChange={(e) => updateConfig({ batteryCostPerKwh: Number.parseFloat(e.target.value) || 500 })}
                        className="mt-1"
                      />
                    </div>

                    <div>
                      <Label className="font-semibold">Discount Rate (%)</Label>
                      <Input
                        type="number"
                        step="0.1"
                        value={config.discountRate * 100}
                        onChange={(e) => updateConfig({ discountRate: (Number.parseFloat(e.target.value) || 6) / 100 })}
                        className="mt-1"
                      />
                    </div>
                  </div>

                  <div>
                    <Label className="font-semibold">System Lifespan: {config.systemLifespan} years</Label>
                    <Slider
                      value={[config.systemLifespan]}
                      onValueChange={([value]) => updateConfig({ systemLifespan: value })}
                      max={30}
                      min={15}
                      step={1}
                      className="mt-2"
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics">
            <Card className="card-enhanced mobile-rounded">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-purple-600" />
                  Pro Cost Analysis
                </CardTitle>
              </CardHeader>
              <CardContent>
                {results ? (
                  <div className="space-y-6">
                    {/* Financial Summary */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="bg-blue-50 p-6 rounded-lg border border-blue-100">
                        <h4 className="text-lg font-semibold text-blue-700 mb-2">Daily Savings</h4>
                        <p className="text-3xl font-bold text-blue-800">${results.economics.dailyCost}</p>
                        <p className="text-sm text-blue-600 mt-1">Current grid cost</p>
                      </div>
                      <div className="bg-green-50 p-6 rounded-lg border border-green-100">
                        <h4 className="text-lg font-semibold text-green-700 mb-2">Annual Savings</h4>
                        <p className="text-3xl font-bold text-green-800">${results.economics.totalSavings}</p>
                        <p className="text-sm text-green-600 mt-1">Projected savings</p>
                      </div>
                      <div className="bg-purple-50 p-6 rounded-lg border border-purple-100">
                        <h4 className="text-lg font-semibold text-purple-700 mb-2">Payback Period</h4>
                        <p className="text-3xl font-bold text-purple-800">{results.economics.paybackPeriod} years</p>
                        <p className="text-sm text-purple-600 mt-1">Return on investment</p>
                      </div>
                    </div>

                    {/* Detailed Analysis */}
                    <div className="bg-gray-50 p-6 rounded-lg border border-gray-200">
                      <h4 className="text-lg font-semibold text-gray-700 mb-4">Advanced Financial Analysis</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-3">
                          <div className="flex justify-between items-center">
                            <span className="text-gray-600">Monthly Cost</span>
                            <span className="font-semibold">${results.economics.monthlyCost}</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-gray-600">Annual Cost</span>
                            <span className="font-semibold">${results.economics.annualCost}</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-gray-600">ROI</span>
                            <span className="font-semibold text-green-600">{results.economics.roi}%</span>
                          </div>
                        </div>
                        <div className="space-y-3">
                          <div className="flex justify-between items-center">
                            <span className="text-gray-600">Net Present Value</span>
                            <span className="font-semibold">${results.economics.netPresentValue}</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-gray-600">CO₂ Saved (Annual)</span>
                            <span className="font-semibold text-green-600">{results.environmental.co2Saved} kg</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-gray-600">Trees Equivalent</span>
                            <span className="font-semibold text-green-600">
                              {results.environmental.treesEquivalent}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-64">
                    <div className="text-center">
                      <BarChart3 className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                      <p className="text-gray-500">Run a Pro simulation to see advanced cost analytics</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
