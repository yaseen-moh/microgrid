"use client"

import type React from "react"

export default function SimulationLayout({
  children,
}: {
  children: React.ReactNode
}) {
  // Removed all redirects and auth checks
  return <>{children}</>
}
