import { NextResponse } from "next/server"
import { stripe, webhookSecret, isStripeConfigured } from "@/lib/stripe"
import { headers } from "next/headers"

export async function POST(request: Request) {
  try {
    // Check if Stripe is configured
    if (!isStripeConfigured() || !webhookSecret) {
      console.log("Stripe not configured or webhook secret missing")
      return NextResponse.json({ received: false }, { status: 503 })
    }

    const body = await request.text()
    const signature = headers().get("stripe-signature") as string

    let event

    try {
      event = stripe!.webhooks.constructEvent(body, signature, webhookSecret)
    } catch (err: any) {
      console.error(`Webhook signature verification failed: ${err.message}`)
      return NextResponse.json({ error: err.message }, { status: 400 })
    }

    // Handle the event
    switch (event.type) {
      case "checkout.session.completed":
        const session = event.data.object as any
        console.log(`Checkout session completed: ${session.id}`)

        // Here you would typically update your database with the subscription info
        // For example, update the user's subscription status, tier, etc.

        break
      case "customer.subscription.updated":
      case "customer.subscription.deleted":
        const subscription = event.data.object as any
        console.log(`Subscription ${event.type}: ${subscription.id}`)

        // Update the subscription status in your database

        break
      default:
        console.log(`Unhandled event type: ${event.type}`)
    }

    return NextResponse.json({ received: true })
  } catch (error) {
    console.error("Error handling webhook:", error)
    return NextResponse.json({ error: "Webhook handler failed" }, { status: 500 })
  }
}
