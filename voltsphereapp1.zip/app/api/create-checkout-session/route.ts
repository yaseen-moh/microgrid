import { NextResponse } from "next/server"
import { stripe, getPriceId, isStripeConfigured } from "@/lib/stripe"
import { config } from "@/lib/config"
import { getCurrentUser } from "@/lib/auth-server"

export async function POST(request: Request) {
  try {
    // Check if Stripe is configured
    if (!isStripeConfigured()) {
      return NextResponse.json(
        { error: "Payment processing is not configured. Please contact support." },
        { status: 503 },
      )
    }

    // Get the current user
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Parse the request body
    const body = await request.json()
    const { tier = "pro", billing = "monthly" } = body

    // Get the price ID for the selected tier and billing interval
    const priceId = getPriceId(tier, billing)
    if (!priceId) {
      return NextResponse.json({ error: "Invalid tier or billing interval" }, { status: 400 })
    }

    // Create a checkout session
    const session = await stripe!.checkout.sessions.create({
      payment_method_types: ["card"],
      billing_address_collection: "auto",
      customer_email: user.email,
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      mode: "subscription",
      allow_promotion_codes: true,
      success_url: `${config.url}/billing/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${config.url}/pricing`,
      metadata: {
        userId: user.id,
        tier,
        billing,
      },
    })

    return NextResponse.json({ url: session.url })
  } catch (error) {
    console.error("Error creating checkout session:", error)
    return NextResponse.json({ error: "Failed to create checkout session" }, { status: 500 })
  }
}
