import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    // Check API key
    const authHeader = request.headers.get("authorization")
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ error: "Missing or invalid API key" }, { status: 401 })
    }

    const apiKey = authHeader.substring(7)

    // In production, get actual usage from database
    // For demo, return mock data
    const usage = {
      apiKey: apiKey.substring(0, 8) + "...",
      tier: apiKey.includes("starter") ? "starter" : "growth",
      currentPeriod: {
        start: "2024-01-01T00:00:00Z",
        end: "2024-01-31T23:59:59Z",
        callsUsed: Math.floor(Math.random() * 1000),
        callsRemaining: 5000 - Math.floor(Math.random() * 1000),
        limit: 5000,
      },
      lastCall: new Date().toISOString(),
      endpoints: {
        "/api/simulate": Math.floor(Math.random() * 800),
        "/api/usage": Math.floor(Math.random() * 50),
        "/api/locations": Math.floor(Math.random() * 20),
      },
    }

    return NextResponse.json(usage)
  } catch (error) {
    console.error("API usage error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
