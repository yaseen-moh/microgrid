import { NextResponse } from "next/server"
import { stripe, isStripeConfigured } from "@/lib/stripe"
import { config } from "@/lib/config"
import { getCurrentUser } from "@/lib/auth-server"

export async function POST(request: Request) {
  try {
    // Check if Stripe is configured
    if (!isStripeConfigured()) {
      return NextResponse.json(
        { error: "Payment processing is not configured. Please contact support." },
        { status: 503 },
      )
    }

    // Get the current user
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Parse the request body
    const body = await request.json()
    const { customerId } = body

    if (!customerId) {
      return NextResponse.json({ error: "Customer ID is required" }, { status: 400 })
    }

    // Create a billing portal session
    const session = await stripe!.billingPortal.sessions.create({
      customer: customerId,
      return_url: `${config.url}/billing`,
    })

    return NextResponse.json({ url: session.url })
  } catch (error) {
    console.error("Error creating portal session:", error)
    return NextResponse.json({ error: "Failed to create portal session" }, { status: 500 })
  }
}
