import { type NextRequest, NextResponse } from "next/server"
import { getCurrentUser } from "@/lib/auth-server"

export async function GET(request: NextRequest) {
  try {
    // FIXED: Only return user if there's a valid session cookie
    const user = await getCurrentUser()

    if (!user) {
      // FIXED: Return explicit failure when no user found
      return NextResponse.json(
        {
          success: false,
          user: null,
          message: "No active session",
        },
        { status: 401 },
      )
    }

    // FIXED: Only return user data if user exists
    return NextResponse.json({
      success: true,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        subscriptionTier: user.subscriptionTier,
      },
    })
  } catch (error) {
    console.error("Auth check error:", error)
    // FIXED: Return explicit failure on error
    return NextResponse.json(
      {
        success: false,
        user: null,
        message: "Authentication check failed",
      },
      { status: 500 },
    )
  }
}
