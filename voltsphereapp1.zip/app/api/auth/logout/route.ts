import { type NextRequest, NextResponse } from "next/server"
import { deleteSession } from "@/lib/auth-server"

export async function POST(request: NextRequest) {
  try {
    // FIXED: Always delete session on logout
    await deleteSession()

    return NextResponse.json({
      success: true,
      message: "Logged out successfully",
    })
  } catch (error) {
    console.error("Logout error:", error)
    // FIXED: Still return success even if error (user should be logged out)
    return NextResponse.json({
      success: true,
      message: "Logged out",
    })
  }
}
