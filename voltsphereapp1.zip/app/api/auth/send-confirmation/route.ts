import { NextResponse } from "next/server"
import { Resend } from "resend"

const resend = new Resend("re_K1BrrnLC_EQYezUg6HguC8RJe9uxyug5m")

export async function POST(request: Request) {
  try {
    const { email, type, name } = await request.json()

    if (!email) {
      return NextResponse.json({ success: false, message: "Email is required" }, { status: 400 })
    }

    let subject = ""
    let htmlContent = ""

    if (type === "login") {
      subject = "VoltSphere - Login Confirmation"
      htmlContent = `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Login Confirmation</title>
        </head>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; border-radius: 15px; text-align: center; margin-bottom: 30px;">
            <h1 style="color: white; margin: 0; font-size: 28px;">VoltSphere</h1>
            <p style="color: white; margin: 10px 0 0 0; font-size: 16px;">Energy Simulation Platform</p>
          </div>
          
          <div style="background: #f8f9fa; padding: 30px; border-radius: 15px; border-left: 5px solid #667eea;">
            <h2 style="color: #333; margin-top: 0;">Login Confirmation</h2>
            <p style="font-size: 16px; margin-bottom: 20px;">Hello,</p>
            <p style="font-size: 16px; margin-bottom: 20px;">This email confirms that you have successfully logged in to your VoltSphere account.</p>
            <p style="font-size: 16px; margin-bottom: 20px;">If you did not initiate this login, please contact our support team immediately.</p>
            
            <div style="background: white; padding: 20px; border-radius: 10px; margin: 20px 0;">
              <p style="margin: 0; font-weight: bold; color: #667eea;">Login Time: ${new Date().toLocaleString()}</p>
            </div>
            
            <div style="text-align: center; margin-top: 20px;">
              <a href="https://voltsphere.com/simulation" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 12px 25px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">Access Your Account</a>
            </div>
          </div>
          
          <div style="text-align: center; margin-top: 30px; padding: 20px; color: #666;">
            <p>Thank you for using VoltSphere</p>
            <p style="font-size: 14px;">© 2024 VoltSphere. All rights reserved.</p>
          </div>
        </body>
        </html>
      `
    } else if (type === "register") {
      subject = `Welcome to VoltSphere, ${name || "User"}!`
      htmlContent = `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Welcome to VoltSphere</title>
        </head>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; border-radius: 15px; text-align: center; margin-bottom: 30px;">
            <h1 style="color: white; margin: 0; font-size: 28px;">VoltSphere</h1>
            <p style="color: white; margin: 10px 0 0 0; font-size: 16px;">Energy Simulation Platform</p>
          </div>
          
          <div style="background: #f8f9fa; padding: 30px; border-radius: 15px; border-left: 5px solid #667eea;">
            <h2 style="color: #333; margin-top: 0;">Welcome to VoltSphere!</h2>
            <p style="font-size: 16px; margin-bottom: 20px;">Hello ${name || "User"},</p>
            <p style="font-size: 16px; margin-bottom: 20px;">Thank you for creating an account with VoltSphere. We're excited to have you on board!</p>
            <p style="font-size: 16px; margin-bottom: 20px;">You can now access our energy simulation tools and start exploring renewable energy solutions.</p>
            
            <div style="background: white; padding: 20px; border-radius: 10px; margin: 20px 0; text-align: center;">
              <a href="https://voltsphere.com/simulation" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block; margin-bottom: 10px;">Start Your First Simulation</a>
            </div>
            
            <p style="font-size: 16px; margin-bottom: 15px;">What you can do with VoltSphere:</p>
            <ul style="font-size: 16px; padding-left: 20px; margin-bottom: 20px;">
              <li style="margin-bottom: 8px;">Run free energy simulations</li>
              <li style="margin-bottom: 8px;">Analyze renewable energy potential</li>
              <li style="margin-bottom: 8px;">Access professional simulation tools</li>
              <li style="margin-bottom: 8px;">Export detailed reports</li>
            </ul>
            
            <div style="background: #e3f2fd; padding: 15px; border-radius: 8px; margin-top: 20px;">
              <p style="margin: 0; font-size: 14px; color: #1976d2;">
                <strong>Pro Tip:</strong> Start with our free simulation to explore the platform, then upgrade to access advanced features and detailed analytics.
              </p>
            </div>
          </div>
          
          <div style="text-align: center; margin-top: 30px; padding: 20px; color: #666;">
            <p>Thank you for choosing VoltSphere</p>
            <p style="font-size: 14px;">Need help? Contact us at support@voltsphere.com</p>
            <p style="font-size: 14px;">© 2024 VoltSphere. All rights reserved.</p>
          </div>
        </body>
        </html>
      `
    }

    // Send email using Resend
    const { data, error } = await resend.emails.send({
      from: "VoltSphere <onboarding@resend.dev>", // Using Resend's default domain
      to: [email],
      subject: subject,
      html: htmlContent,
    })

    if (error) {
      console.error("Resend error:", error)
      return NextResponse.json(
        {
          success: false,
          message: "Failed to send email",
          error: error,
        },
        { status: 500 },
      )
    }

    console.log("Email sent successfully:", data)

    return NextResponse.json({
      success: true,
      message: "Confirmation email sent successfully",
      emailId: data?.id,
    })
  } catch (error) {
    console.error("Error sending email:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Failed to send email",
      },
      { status: 500 },
    )
  }
}
