import { NextResponse } from "next/server"
import { getCurrentUser } from "@/lib/auth-server"

export async function GET() {
  try {
    const user = await getCurrentUser()

    return NextResponse.json(
      {
        user: user || null,
        authenticated: !!user,
      },
      { status: 200 },
    )
  } catch (error) {
    console.error("Session error:", error)
    return NextResponse.json(
      {
        user: null,
        authenticated: false,
        error: "Session check failed",
      },
      { status: 500 },
    )
  }
}
