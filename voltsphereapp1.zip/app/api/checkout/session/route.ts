import { NextResponse } from "next/server"
import { stripe, isStripeConfigured } from "@/lib/stripe"
import { getCurrentUser } from "@/lib/auth-server"

export async function GET(request: Request) {
  try {
    // Check if Stripe is configured
    if (!isStripeConfigured()) {
      return NextResponse.json(
        { error: "Payment processing is not configured. Please contact support." },
        { status: 503 },
      )
    }

    // Ensure user is authenticated
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get session ID from URL
    const url = new URL(request.url)
    const sessionId = url.searchParams.get("session_id")

    if (!sessionId) {
      return NextResponse.json({ error: "Session ID is required" }, { status: 400 })
    }

    // Retrieve session from Stripe
    const session = await stripe!.checkout.sessions.retrieve(sessionId, {
      expand: ["subscription", "customer"],
    })

    // Extract relevant information
    const subscription = session.subscription as any
    const plan = session.metadata?.tier || "pro"
    const billing = session.metadata?.billing || "monthly"

    return NextResponse.json({
      id: session.id,
      plan: plan.charAt(0).toUpperCase() + plan.slice(1),
      billing: billing.charAt(0).toUpperCase() + billing.slice(1),
      status: subscription?.status || "active",
      currentPeriodEnd: subscription?.current_period_end
        ? new Date(subscription.current_period_end * 1000).toISOString()
        : null,
    })
  } catch (error) {
    console.error("Error retrieving checkout session:", error)
    return NextResponse.json({ error: "Failed to retrieve session details" }, { status: 500 })
  }
}
