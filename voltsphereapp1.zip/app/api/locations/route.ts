import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    // Check API key
    const authHeader = request.headers.get("authorization")
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ error: "Missing or invalid API key" }, { status: 401 })
    }

    const locations = [
      {
        id: "san-francisco",
        name: "San Francisco, CA",
        coordinates: { lat: 37.7749, lng: -122.4194 },
        timezone: "America/Los_Angeles",
        weatherSupport: true,
      },
      {
        id: "new-york",
        name: "New York, NY",
        coordinates: { lat: 40.7128, lng: -74.006 },
        timezone: "America/New_York",
        weatherSupport: true,
      },
      {
        id: "austin",
        name: "Austin, TX",
        coordinates: { lat: 30.2672, lng: -97.7431 },
        timezone: "America/Chicago",
        weatherSupport: true,
      },
      {
        id: "denver",
        name: "Denver, CO",
        coordinates: { lat: 39.7392, lng: -104.9903 },
        timezone: "America/Denver",
        weatherSupport: true,
      },
      {
        id: "phoenix",
        name: "Phoenix, AZ",
        coordinates: { lat: 33.4484, lng: -112.074 },
        timezone: "America/Phoenix",
        weatherSupport: true,
      },
      {
        id: "seattle",
        name: "Seattle, WA",
        coordinates: { lat: 47.6062, lng: -122.3321 },
        timezone: "America/Los_Angeles",
        weatherSupport: true,
      },
    ]

    return NextResponse.json({
      locations,
      total: locations.length,
      weatherEnabled: true,
    })
  } catch (error) {
    console.error("API locations error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
