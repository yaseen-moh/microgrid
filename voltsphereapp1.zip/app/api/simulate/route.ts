import { type NextRequest, NextResponse } from "next/server"
import { SimulationEngine, type SimulationConfig } from "@/lib/simulation/engine"

export async function POST(request: NextRequest) {
  try {
    // Check API key
    const authHeader = request.headers.get("authorization")
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ error: "Missing or invalid API key" }, { status: 401 })
    }

    const apiKey = authHeader.substring(7)

    // In production, validate API key against database
    if (!apiKey.startsWith("vs_")) {
      return NextResponse.json({ error: "Invalid API key format" }, { status: 401 })
    }

    // Parse request body
    const body = await request.json()

    // Validate required fields
    const requiredFields = ["batteryCapacity", "batteryEfficiency", "solarEnabled"]
    for (const field of requiredFields) {
      if (!(field in body)) {
        return NextResponse.json({ error: `Missing required field: ${field}` }, { status: 400 })
      }
    }

    // Create simulation config
    const config: SimulationConfig = {
      batteryCapacity: body.batteryCapacity,
      batteryEfficiency: body.batteryEfficiency,
      solarEnabled: body.solarEnabled,
      batteryType: body.batteryType || "lithium",
      loadProfileType: body.loadProfile || "default",
      useRealWeather: body.weatherEnabled || false,
      weatherLocation: body.location ? `${body.location.lat},${body.location.lng}` : undefined,
      timeOfUseRates: body.timeOfUseRates || false,
      location: body.location,
      equipmentSpecs: body.equipmentSpecs,
      economicParams: body.economicParams,
    }

    // Run simulation
    const results = await SimulationEngine.runSimulation(config)

    // Format response
    const response = {
      simulationId: `sim_${Date.now()}`,
      timestamp: new Date().toISOString(),
      input: config,
      results: {
        energyFlow: {
          solar: results.solarProfile,
          load: results.loadProfile,
          battery: results.batteryStorage,
          grid: results.gridUsage,
        },
        economics: {
          dailyCost: results.costAnalysis.netCost,
          monthlyCost: results.costAnalysis.netCost * 30,
          annualCost: results.costAnalysis.netCost * 365,
          savings: results.costAnalysis.solarSavings + results.costAnalysis.batterySavings,
          paybackPeriod: results.costAnalysis.paybackPeriod,
          roi: results.costAnalysis.irr * 100,
        },
        environmental: {
          co2Saved: results.solarProfile.reduce((sum, solar) => sum + solar, 0) * 0.5, // kg CO2
          treesEquivalent: results.solarProfile.reduce((sum, solar) => sum + solar, 0) * 0.02,
        },
        weather: results.weatherData,
      },
      metadata: {
        processingTime: "1.2s",
        version: "v2.1.0",
      },
    }

    return NextResponse.json(response)
  } catch (error) {
    console.error("API simulation error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function GET() {
  return NextResponse.json({
    message: "VoltSphere Microgrid Simulation API",
    version: "v2.1.0",
    endpoints: {
      "POST /api/simulate": "Run microgrid simulation",
      "GET /api/usage": "Get API usage statistics",
      "GET /api/locations": "Get supported locations",
    },
  })
}
