export interface User {
  id: string
  email: string
  name: string
  role: "user" | "premium" // Changed from admin to premium
  subscriptionTier: "free" | "pro" | "starter" | "growth" | "enterprise"
  subscriptionStatus: "active" | "inactive" | "canceled"
  stripeCustomerId?: string
  stripeSubscriptionId?: string
  createdAt: Date
  updatedAt: Date
}

// All logged-in users get full access (premium customer treatment)
export function canAccessPro(user: User | null): boolean {
  if (!user) return false
  return true // All logged-in users can access Pro
}

export function canAccessAPI(user: User | null): boolean {
  if (!user) return false
  return true // All logged-in users can access API
}

export function canAccessGrowthAPI(user: User | null): boolean {
  if (!user) return false
  return true // All logged-in users can access Growth API
}

export function canAccessEnterprise(user: User | null): boolean {
  if (!user) return false
  return true // All logged-in users can access Enterprise
}

// Return maximum tier level for all logged-in users
export function getUserTierLevel(user: User | null): number {
  if (!user) return 0
  return 5 // Maximum tier level for all logged-in users (premium customer)
}
