// Advanced Simulation Engine for VoltSphere

export interface SimulationConfig {
  // Basic Configuration
  batteryCapacity: number
  batteryEfficiency: number
  solarEnabled: boolean
  batteryType: string
  loadProfileType: string

  // Advanced Configuration
  useRealWeather: boolean
  weatherLocation: string
  timeOfUseRates: boolean
  simulationDuration: string
  solarCapacity: number
  inverterEfficiency: number
  systemLosses: number

  // Economic Parameters
  gridCostPerKwh: number
  solarCostPerWatt: number
  batteryCostPerKwh: number
  discountRate: number
  systemLifespan: number

  // Location
  location?: {
    lat: number
    lng: number
    city: string
    country: string
  }
}

export interface SimulationDataPoint {
  time: string
  hour: number
  solar: number
  consumption: number
  battery: number
  batterySOC: number
  grid: number
  gridCost: number
  weather: {
    temperature: number
    cloudCover: number
    condition: string
    solarIrradiance: number
  }
}

export interface SimulationResult {
  data: SimulationDataPoint[]
  summary: {
    totalSolar: number
    totalConsumption: number
    totalGrid: number
    avgBattery: number
    peakDemand: number
    solarUtilization: number
    gridIndependence: number
  }
  economics: {
    dailyCost: number
    monthlyCost: number
    annualCost: number
    totalSavings: number
    paybackPeriod: number
    roi: number
    netPresentValue: number
  }
  environmental: {
    co2Saved: number
    treesEquivalent: number
    coalAvoided: number
  }
}

export class SimulationEngine {
  private static readonly BATTERY_SPECS = {
    lithium: { efficiency: 0.92, cycleLife: 6000, costPerKwh: 500 },
    "lead-acid": { efficiency: 0.85, cycleLife: 2000, costPerKwh: 200 },
    flow: { efficiency: 0.88, cycleLife: 10000, costPerKwh: 800 },
    sodium: { efficiency: 0.9, cycleLife: 4000, costPerKwh: 400 },
  }

  private static readonly LOAD_PROFILES = {
    residential: [
      2.1, 1.9, 1.7, 1.5, 1.4, 1.8, 2.5, 3.2, 3.8, 3.5, 3.2, 3.0, 3.1, 3.0, 2.9, 3.1, 3.5, 4.2, 5.0, 5.2, 4.8, 4.0, 3.2,
      2.5,
    ],
    commercial: [
      2.0, 1.8, 1.7, 1.6, 1.8, 2.5, 3.5, 5.0, 6.5, 7.0, 7.2, 7.0, 6.8, 7.0, 7.2, 7.0, 6.5, 5.5, 4.5, 3.8, 3.2, 2.8, 2.4,
      2.1,
    ],
    industrial: [
      4.5, 4.2, 4.0, 3.8, 4.0, 4.5, 5.5, 6.8, 7.5, 8.0, 8.2, 8.0, 7.8, 8.0, 8.2, 8.0, 7.5, 6.8, 6.0, 5.5, 5.0, 4.8, 4.6,
      4.5,
    ],
  }

  private static readonly WEATHER_DATA = {
    "San Francisco, CA": { lat: 37.7749, lng: -122.4194, avgTemp: 15, cloudiness: 0.3 },
    "New York, NY": { lat: 40.7128, lng: -74.006, avgTemp: 12, cloudiness: 0.4 },
    "Chicago, IL": { lat: 41.8781, lng: -87.6298, avgTemp: 10, cloudiness: 0.5 },
    "Austin, TX": { lat: 30.2672, lng: -97.7431, avgTemp: 22, cloudiness: 0.2 },
    "Miami, FL": { lat: 25.7617, lng: -80.1918, avgTemp: 25, cloudiness: 0.3 },
    "Phoenix, AZ": { lat: 33.4484, lng: -112.074, avgTemp: 28, cloudiness: 0.1 },
    "Seattle, WA": { lat: 47.6062, lng: -122.3321, avgTemp: 11, cloudiness: 0.6 },
    "Denver, CO": { lat: 39.7392, lng: -104.9903, avgTemp: 10, cloudiness: 0.3 },
    "Los Angeles, CA": { lat: 34.0522, lng: -118.2437, avgTemp: 18, cloudiness: 0.2 },
    "Boston, MA": { lat: 42.3601, lng: -71.0589, avgTemp: 10, cloudiness: 0.4 },
    "Atlanta, GA": { lat: 33.749, lng: -84.388, avgTemp: 16, cloudiness: 0.4 },
    "Dallas, TX": { lat: 32.7767, lng: -96.797, avgTemp: 19, cloudiness: 0.3 },
  }

  static async runSimulation(config: SimulationConfig): Promise<SimulationResult> {
    const hours = this.getSimulationHours(config.simulationDuration)
    const batterySpec = this.BATTERY_SPECS[config.batteryType as keyof typeof this.BATTERY_SPECS]
    const loadProfile = this.LOAD_PROFILES[config.loadProfileType as keyof typeof this.LOAD_PROFILES]
    const weatherData = this.WEATHER_DATA[config.weatherLocation as keyof typeof this.WEATHER_DATA]

    let batterySOC = 50 // Start at 50% state of charge
    const data: SimulationDataPoint[] = []

    for (let i = 0; i < hours; i++) {
      const hour = i % 24
      const day = Math.floor(i / 24)

      // Generate weather conditions
      const weather = this.generateWeatherConditions(hour, day, weatherData, config.useRealWeather)

      // Calculate solar generation
      const solarGeneration = config.solarEnabled
        ? this.calculateSolarGeneration(
            hour,
            config.solarCapacity,
            weather,
            config.inverterEfficiency,
            config.systemLosses,
          )
        : 0

      // Calculate load consumption
      const baseLoad = loadProfile[hour] * (config.batteryCapacity / 15) // Scale based on system size
      const consumption = baseLoad * (0.9 + Math.random() * 0.2) // Add 10% variation

      // Calculate energy balance
      const energyBalance = solarGeneration - consumption

      // Battery and grid calculations
      let gridUsage = 0
      let gridCost = 0

      if (energyBalance < 0) {
        // Need energy - try battery first
        const energyNeeded = -energyBalance
        const maxFromBattery = (batterySOC * config.batteryCapacity) / 100
        const energyFromBattery = Math.min(energyNeeded, maxFromBattery) * batterySpec.efficiency

        batterySOC -= (energyFromBattery / config.batteryCapacity) * 100
        gridUsage = Math.max(0, energyNeeded - energyFromBattery)

        // Calculate grid cost with time-of-use rates
        const electricityRate = config.timeOfUseRates ? this.getTimeOfUseRate(hour) : config.gridCostPerKwh
        gridCost = gridUsage * electricityRate
      } else {
        // Excess energy - charge battery
        const energyAvailable = energyBalance
        const batterySpaceAvailable = ((100 - batterySOC) * config.batteryCapacity) / 100
        const energyToBattery = Math.min(energyAvailable, batterySpaceAvailable) * batterySpec.efficiency

        batterySOC += (energyToBattery / config.batteryCapacity) * 100
      }

      // Ensure battery SOC stays within bounds
      batterySOC = Math.max(0, Math.min(100, batterySOC))

      data.push({
        time: `${String(hour).padStart(2, "0")}:00`,
        hour,
        solar: Math.round(solarGeneration * 100) / 100,
        consumption: Math.round(consumption * 100) / 100,
        battery: Math.round(((batterySOC * config.batteryCapacity) / 100) * 100) / 100,
        batterySOC: Math.round(batterySOC * 100) / 100,
        grid: Math.round(gridUsage * 100) / 100,
        gridCost: Math.round(gridCost * 100) / 100,
        weather,
      })
    }

    // Calculate summary statistics
    const summary = this.calculateSummary(data, config)
    const economics = this.calculateEconomics(data, config, batterySpec)
    const environmental = this.calculateEnvironmentalImpact(data)

    return {
      data,
      summary,
      economics,
      environmental,
    }
  }

  private static getSimulationHours(duration: string): number {
    switch (duration) {
      case "24h":
        return 24
      case "7d":
        return 168
      case "30d":
        return 720
      case "1y":
        return 8760
      default:
        return 24
    }
  }

  private static generateWeatherConditions(hour: number, day: number, weatherData: any, useRealWeather: boolean) {
    if (!useRealWeather || !weatherData) {
      return {
        temperature: 20,
        cloudCover: 20,
        condition: "Clear",
        solarIrradiance: hour >= 6 && hour <= 18 ? 800 : 0,
      }
    }

    // Simulate realistic weather patterns
    const baseTemp = weatherData.avgTemp
    const tempVariation = 5 * Math.sin(((hour - 6) * Math.PI) / 12) // Daily temperature cycle
    const temperature = baseTemp + tempVariation + (Math.random() - 0.5) * 4

    const baseCloudCover = weatherData.cloudiness * 100
    const cloudCover = Math.max(0, Math.min(100, baseCloudCover + (Math.random() - 0.5) * 40))

    const conditions = ["Clear", "Partly Cloudy", "Cloudy", "Overcast"]
    const condition =
      cloudCover < 25
        ? conditions[0]
        : cloudCover < 50
          ? conditions[1]
          : cloudCover < 75
            ? conditions[2]
            : conditions[3]

    const maxIrradiance = 1000 // W/m²
    const solarIrradiance =
      hour >= 6 && hour <= 18 ? maxIrradiance * Math.sin(((hour - 6) * Math.PI) / 12) * (1 - cloudCover / 150) : 0

    return {
      temperature: Math.round(temperature * 10) / 10,
      cloudCover: Math.round(cloudCover),
      condition,
      solarIrradiance: Math.round(solarIrradiance),
    }
  }

  private static calculateSolarGeneration(
    hour: number,
    solarCapacity: number,
    weather: any,
    inverterEfficiency: number,
    systemLosses: number,
  ): number {
    if (hour < 6 || hour > 18) return 0

    const peakSunHours = Math.sin(((hour - 6) * Math.PI) / 12)
    const weatherFactor = weather.solarIrradiance / 1000
    const efficiencyFactor = (inverterEfficiency / 100) * (1 - systemLosses / 100)

    return solarCapacity * peakSunHours * weatherFactor * efficiencyFactor
  }

  private static getTimeOfUseRate(hour: number): number {
    // Peak hours: 4-9 PM
    if (hour >= 16 && hour <= 21) return 0.35
    // Mid-peak hours: 10 AM - 4 PM
    if (hour >= 10 && hour <= 15) return 0.25
    // Off-peak hours: 9 PM - 10 AM
    return 0.15
  }

  private static calculateSummary(data: SimulationDataPoint[], config: SimulationConfig) {
    const totalSolar = data.reduce((sum, point) => sum + point.solar, 0)
    const totalConsumption = data.reduce((sum, point) => sum + point.consumption, 0)
    const totalGrid = data.reduce((sum, point) => sum + point.grid, 0)
    const avgBattery = data.reduce((sum, point) => sum + point.batterySOC, 0) / data.length
    const peakDemand = Math.max(...data.map((point) => point.consumption))
    const solarUtilization = totalConsumption > 0 ? (totalSolar / totalConsumption) * 100 : 0
    const gridIndependence = totalConsumption > 0 ? ((totalConsumption - totalGrid) / totalConsumption) * 100 : 0

    return {
      totalSolar: Math.round(totalSolar * 100) / 100,
      totalConsumption: Math.round(totalConsumption * 100) / 100,
      totalGrid: Math.round(totalGrid * 100) / 100,
      avgBattery: Math.round(avgBattery * 100) / 100,
      peakDemand: Math.round(peakDemand * 100) / 100,
      solarUtilization: Math.round(solarUtilization * 100) / 100,
      gridIndependence: Math.round(gridIndependence * 100) / 100,
    }
  }

  private static calculateEconomics(data: SimulationDataPoint[], config: SimulationConfig, batterySpec: any) {
    const dailyCost = data.reduce((sum, point) => sum + point.gridCost, 0)
    const monthlyCost = dailyCost * 30
    const annualCost = dailyCost * 365

    // Calculate system costs
    const solarSystemCost = config.solarEnabled ? config.solarCapacity * 1000 * config.solarCostPerWatt : 0
    const batterySystemCost = config.batteryCapacity * batterySpec.costPerKwh
    const totalSystemCost = solarSystemCost + batterySystemCost

    // Calculate savings
    const baselineAnnualCost = data.reduce((sum, point) => sum + point.consumption * config.gridCostPerKwh, 0) * 365
    const totalSavings = baselineAnnualCost - annualCost

    // Calculate financial metrics
    const paybackPeriod = totalSavings > 0 ? totalSystemCost / totalSavings : 0
    const roi = totalSavings > 0 ? (totalSavings / totalSystemCost) * 100 : 0

    // Net Present Value calculation
    let npv = -totalSystemCost
    for (let year = 1; year <= config.systemLifespan; year++) {
      npv += totalSavings / Math.pow(1 + config.discountRate, year)
    }

    return {
      dailyCost: Math.round(dailyCost * 100) / 100,
      monthlyCost: Math.round(monthlyCost * 100) / 100,
      annualCost: Math.round(annualCost * 100) / 100,
      totalSavings: Math.round(totalSavings * 100) / 100,
      paybackPeriod: Math.round(paybackPeriod * 100) / 100,
      roi: Math.round(roi * 100) / 100,
      netPresentValue: Math.round(npv * 100) / 100,
    }
  }

  private static calculateEnvironmentalImpact(data: SimulationDataPoint[]) {
    const totalSolar = data.reduce((sum, point) => sum + point.solar, 0)

    // CO2 emissions factor: 0.5 kg CO2 per kWh from grid
    const co2Saved = totalSolar * 0.5

    // Trees equivalent: 1 tree absorbs ~22 kg CO2 per year
    const treesEquivalent = co2Saved / 22

    // Coal avoided: 1 kWh solar = ~0.5 kg coal avoided
    const coalAvoided = totalSolar * 0.5

    return {
      co2Saved: Math.round(co2Saved * 100) / 100,
      treesEquivalent: Math.round(treesEquivalent * 100) / 100,
      coalAvoided: Math.round(coalAvoided * 100) / 100,
    }
  }
}
