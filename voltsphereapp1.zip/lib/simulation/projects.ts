import type { SimulationConfig, SimulationResult } from "./simulationConfig" // Assuming SimulationConfig and SimulationResult are defined in another file

export interface Project {
  id: string
  name: string
  description?: string
  config: SimulationConfig
  results?: SimulationResult
  createdAt: Date
  updatedAt: Date
  userId: string
  isPublic: boolean
  tags: string[]
}

export class ProjectManager {
  static async saveProject(project: Omit<Project, "id" | "createdAt" | "updatedAt">): Promise<Project> {
    const newProject: Project = {
      ...project,
      id: this.generateId(),
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    // In production, save to database
    const projects = this.getStoredProjects()
    projects.push(newProject)
    localStorage.setItem("voltsphere_projects", JSON.stringify(projects))

    return newProject
  }

  static async getProjects(userId: string): Promise<Project[]> {
    // In production, fetch from database
    const projects = this.getStoredProjects()
    return projects.filter((p) => p.userId === userId)
  }

  static async getProject(id: string): Promise<Project | null> {
    const projects = this.getStoredProjects()
    return projects.find((p) => p.id === id) || null
  }

  static async updateProject(id: string, updates: Partial<Project>): Promise<Project | null> {
    const projects = this.getStoredProjects()
    const index = projects.findIndex((p) => p.id === id)

    if (index === -1) return null

    projects[index] = {
      ...projects[index],
      ...updates,
      updatedAt: new Date(),
    }

    localStorage.setItem("voltsphere_projects", JSON.stringify(projects))
    return projects[index]
  }

  static async deleteProject(id: string): Promise<boolean> {
    const projects = this.getStoredProjects()
    const filteredProjects = projects.filter((p) => p.id !== id)

    if (filteredProjects.length === projects.length) return false

    localStorage.setItem("voltsphere_projects", JSON.stringify(filteredProjects))
    return true
  }

  private static getStoredProjects(): Project[] {
    if (typeof window === "undefined") return []

    try {
      const stored = localStorage.getItem("voltsphere_projects")
      return stored ? JSON.parse(stored) : []
    } catch {
      return []
    }
  }

  private static generateId(): string {
    return Math.random().toString(36).substr(2, 9)
  }
}
