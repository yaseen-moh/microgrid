// Re-export types from engine.ts to fix import issues
export type { SimulationConfig, SimulationResult } from "./engine"
