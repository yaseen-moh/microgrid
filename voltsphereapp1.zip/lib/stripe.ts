import Stripe from "stripe"
import { config } from "./config"

// Initialize stripe only if the secret key is available
let stripeInstance: Stripe | null = null

if (typeof process !== "undefined" && process.env.STRIPE_SECRET_KEY) {
  stripeInstance = new Stripe(process.env.STRIPE_SECRET_KEY, {
    apiVersion: "2024-06-20",
    typescript: true,
  })
} else if (config.stripe.secretKey) {
  stripeInstance = new Stripe(config.stripe.secretKey, {
    apiVersion: "2024-06-20",
    typescript: true,
  })
}

export const stripe = stripeInstance

export const webhookSecret = config.stripe.webhookSecret

// Stripe Product IDs
export const STRIPE_PRODUCTS = {
  starter: "prod_SSsFu4AsGI7SNy",
  pro: "prod_SSsCk4SnLK47w5",
  growth: "prod_SSsGm02p67BVi8",
  enterprise: "prod_enterprise_placeholder", // Add when available
}

// Stripe Price IDs with Monthly and Yearly options - FIXED STRUCTURE
export const STRIPE_PRICES = {
  starter: {
    monthly: "price_1RXwUlRrbGbUFaw4ZDUrkDuw", // $29/month
    yearly: "price_1RXxFvRrbGbUFaw4sy7qC10I", // $290/year
  },
  pro: {
    monthly: "price_1RXwSZRrbGbUFaw4b6XcsfzZ", // $5.99/month
    yearly: "price_1RXxGpRrbGbUFaw4QSy8Onqo", // $599.99/year
  },
  growth: {
    monthly: "price_1RXwVWRrbGbUFaw45MImf6dO", // $99/month
    yearly: "price_1RXxELRrbGbUFaw40CcIvd2f", // $990/year
  },
  enterprise: {
    monthly: "price_enterprise_monthly", // Add when available
    yearly: "price_enterprise_yearly", // Add when available
  },
}

// Pricing information for display
export const PRICING_INFO = {
  starter: {
    name: "Starter",
    monthly: { price: 29, priceId: "price_1RXwUlRrbGbUFaw4ZDUrkDuw" },
    yearly: { price: 290, priceId: "price_1RXxFvRrbGbUFaw4sy7qC10I", savings: "17%" },
  },
  pro: {
    name: "Pro",
    monthly: { price: 5.99, priceId: "price_1RXwSZRrbGbUFaw4b6XcsfzZ" },
    yearly: { price: 599.99, priceId: "price_1RXxGpRrbGbUFaw4QSy8Onqo", savings: "17%" },
  },
  growth: {
    name: "Growth",
    monthly: { price: 99, priceId: "price_1RXwVWRrbGbUFaw45MImf6dO" },
    yearly: { price: 990, priceId: "price_1RXxELRrbGbUFaw40CcIvd2f", savings: "17%" },
  },
}

// Define the SubscriptionTier type
export type SubscriptionTier = "free" | "starter" | "pro" | "growth" | "enterprise"
export type BillingInterval = "monthly" | "yearly"

// Helper function to get price ID by tier and interval
export function getPriceId(tier: SubscriptionTier, interval: BillingInterval = "monthly"): string | null {
  if (tier === "free") return null

  const tierPrices = STRIPE_PRICES[tier as keyof typeof STRIPE_PRICES]
  if (!tierPrices) return null

  return tierPrices[interval] || null
}

// Helper function to get product ID by tier
export function getProductId(tier: SubscriptionTier): string | null {
  if (tier === "free") return null
  return STRIPE_PRODUCTS[tier as keyof typeof STRIPE_PRODUCTS] || null
}

// Helper function to get pricing info
export function getPricingInfo(tier: SubscriptionTier) {
  if (tier === "free") return null
  return PRICING_INFO[tier as keyof typeof PRICING_INFO] || null
}

// Function to get Stripe for client-side
export function getStripe() {
  return stripe
}

// Check if Stripe is properly initialized
export function isStripeConfigured(): boolean {
  return !!stripe
}
