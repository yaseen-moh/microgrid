import { stripe } from "./stripe"
import { config } from "./config"
import type { SubscriptionTier } from "./stripe"

export async function createCheckoutSession(
  email: string,
  priceId: string,
  tier: SubscriptionTier,
  successUrl?: string,
  cancelUrl?: string,
) {
  try {
    const session = await stripe.checkout.sessions.create({
      customer_email: email,
      payment_method_types: ["card"],
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      mode: "subscription",
      success_url: successUrl || `${config.app.url}/billing/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: cancelUrl || `${config.app.url}/pricing`,
      metadata: {
        tier,
        email,
      },
      subscription_data: {
        metadata: {
          tier,
          email,
        },
      },
    })

    return {
      url: session.url,
      sessionId: session.id,
    }
  } catch (error) {
    console.error("Error creating checkout session:", error)
    throw error
  }
}

// Add the missing createCustomerPortalSession export
export async function createCustomerPortalSession(customerId: string) {
  try {
    const session = await stripe.billingPortal.sessions.create({
      customer: customerId,
      return_url: `${config.app.url}/billing`,
    })

    return { url: session.url }
  } catch (error) {
    console.error("Error creating customer portal session:", error)
    throw error
  }
}

// Keep the existing createPortalSession function for backward compatibility
export async function createPortalSession(customerId: string) {
  return createCustomerPortalSession(customerId)
}

export function getSubscriptionLimits(tier: SubscriptionTier) {
  switch (tier) {
    case "free":
      return {
        simulationsPerDay: 3,
        canExport: false,
        canSaveProjects: false,
        apiCalls: 0,
      }
    case "pro":
      return {
        simulationsPerDay: -1, // unlimited
        canExport: true,
        canSaveProjects: true,
        apiCalls: 0,
      }
    case "starter":
      return {
        simulationsPerDay: -1,
        canExport: true,
        canSaveProjects: true,
        apiCalls: 5000,
      }
    case "growth":
      return {
        simulationsPerDay: -1,
        canExport: true,
        canSaveProjects: true,
        apiCalls: 50000,
      }
    case "enterprise":
      return {
        simulationsPerDay: -1,
        canExport: true,
        canSaveProjects: true,
        apiCalls: -1, // unlimited
      }
    default:
      return getSubscriptionLimits("free")
  }
}
