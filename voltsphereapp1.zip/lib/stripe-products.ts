// Stripe product configuration with your actual product IDs
export const STRIPE_PRODUCT_CONFIG = {
  starter: {
    productId: "prod_SSsFu4AsGI7SNy",
    name: "Starter Plan",
    description: "Perfect for small residential projects",
    features: ["Basic solar simulation", "Up to 5 projects", "Standard weather data", "Email support"],
  },
  pro: {
    productId: "prod_SSsCk4SnLK47w5",
    name: "Pro Plan",
    description: "Advanced features for professionals",
    features: [
      "Advanced simulation engine",
      "Unlimited projects",
      "Real-time weather data",
      "Priority support",
      "Export capabilities",
    ],
  },
  growth: {
    productId: "prod_SSsGm02p67BVi8",
    name: "Growth Plan",
    description: "Comprehensive solution for growing businesses",
    features: ["Everything in Pro", "Team collaboration", "API access", "Custom integrations", "Dedicated support"],
  },
}

// Function to get product config by tier
export function getProductConfig(tier: string) {
  return STRIPE_PRODUCT_CONFIG[tier as keyof typeof STRIPE_PRODUCT_CONFIG]
}
