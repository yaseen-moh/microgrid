// Global error handler for browser extension errors
export function setupGlobalErrorHandler() {
  if (typeof window !== "undefined") {
    // Handle unhandled promise rejections
    window.addEventListener("unhandledrejection", (event) => {
      const error = event.reason

      // Check if it's a browser extension error
      if (
        error?.message?.includes("Receiving end does not exist") ||
        error?.message?.includes("Extension context invalidated") ||
        error?.message?.includes("Could not establish connection") ||
        error?.message?.includes("chrome-extension://") ||
        error?.message?.includes("moz-extension://")
      ) {
        // Prevent the error from being logged to console
        event.preventDefault()
        console.warn("Browser extension error suppressed:", error.message)
        return
      }

      // Log other errors normally
      console.error("Unhandled promise rejection:", error)
    })

    // Handle general errors
    window.addEventListener("error", (event) => {
      const error = event.error

      // Check if it's a browser extension error
      if (
        error?.message?.includes("Receiving end does not exist") ||
        error?.message?.includes("Extension context invalidated") ||
        error?.message?.includes("Could not establish connection") ||
        event.filename?.includes("chrome-extension://") ||
        event.filename?.includes("moz-extension://")
      ) {
        // Prevent the error from being logged
        event.preventDefault()
        console.warn("Browser extension error suppressed:", error?.message || "Unknown extension error")
        return
      }
    })
  }
}
