// Helper function to safely get environment variables
const getEnv = (key: string, defaultValue = ""): string => {
  if (typeof process !== "undefined" && process.env[key]) {
    return process.env[key] || defaultValue
  }
  return defaultValue
}

export const config = {
  stripe: {
    secretKey: getEnv("STRIPE_SECRET_KEY"),
    publishableKey: getEnv("NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY"),
    webhookSecret: getEnv("STRIPE_WEBHOOK_SECRET"),
  },
  url: getEnv("NEXT_PUBLIC_URL", "http://localhost:3000"),
  email: {
    host: getEnv("EMAIL_SERVER_HOST"),
    port: Number(getEnv("EMAIL_SERVER_PORT", "587")),
    user: getEnv("EMAIL_SERVER_USER"),
    pass: getEnv("EMAIL_SERVER_PASSWORD"),
    from: getEnv("EMAIL_FROM", "noreply@voltsphere.com"),
    secure: getEnv("EMAIL_SERVER_SECURE") === "true",
  },
  jwt: {
    secret: getEnv("JWT_SECRET", "default-jwt-secret-for-development-only"),
  },
}
