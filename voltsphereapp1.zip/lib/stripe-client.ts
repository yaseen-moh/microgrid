import { loadStripe } from "@stripe/stripe-js"
import { config } from "./config"

// Initialize Stripe.js with your publishable key
export const stripePromise = loadStripe(config.stripe.publishableKey)

// Helper function to get Stripe instance
export const getStripeInstance = async () => {
  const stripe = await stripePromise
  if (!stripe) {
    throw new Error("Failed to initialize Stripe")
  }
  return stripe
}
