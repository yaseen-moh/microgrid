import { cookies } from "next/headers"
import jwt from "jsonwebtoken"
import { config } from "./config"

// User data structure
export interface User {
  id: string
  email: string
  name?: string
  role: "user" | "admin"
  subscription?: {
    tier: "free" | "starter" | "pro" | "growth" | "enterprise"
    status: "active" | "canceled" | "past_due" | "trialing"
    currentPeriodEnd?: string
  }
}

// Mock user database (replace with actual database in production)
const users: Record<string, User & { password: string }> = {
  "user-1": {
    id: "user-1",
    email: "user@example.com",
    password: "password123", // In production, this would be hashed
    name: "Demo User",
    role: "user",
    subscription: {
      tier: "free",
      status: "active",
    },
  },
  "admin-1": {
    id: "admin-1",
    email: "admin@example.com",
    password: "admin123", // In production, this would be hashed
    name: "Admin User",
    role: "admin",
    subscription: {
      tier: "enterprise",
      status: "active",
    },
  },
}

// Get user by email and password
export async function getUserByCredentials(email: string, password: string): Promise<User | null> {
  // In production, you would query your database and verify the password hash
  const user = Object.values(users).find(
    (u) => u.email.toLowerCase() === email.toLowerCase() && u.password === password,
  )

  if (!user) return null

  // Return user without password
  const { password: _, ...userWithoutPassword } = user
  return userWithoutPassword
}

// Create a new user
export async function createUser(email: string, password: string, name?: string): Promise<User | null> {
  // Check if user already exists
  const existingUser = Object.values(users).find((u) => u.email.toLowerCase() === email.toLowerCase())
  if (existingUser) return null

  // In production, you would hash the password and store in your database
  const id = `user-${Date.now()}`
  const newUser: User & { password: string } = {
    id,
    email,
    password, // In production, this would be hashed
    name,
    role: "user",
    subscription: {
      tier: "free",
      status: "active",
    },
  }

  users[id] = newUser

  // Return user without password
  const { password: _, ...userWithoutPassword } = newUser
  return userWithoutPassword
}

// Create a session for a user
export async function createSession(user: User): Promise<string> {
  // In production, use a proper JWT library with a secure secret
  const token = jwt.sign({ userId: user.id }, config.jwt.secret, { expiresIn: "7d" })

  // Set the token in a cookie
  cookies().set("auth-token", token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 7 * 24 * 60 * 60, // 7 days
    path: "/",
  })

  return token
}

// Get the current user from the session
export async function getCurrentUser(): Promise<User | null> {
  try {
    const token = cookies().get("auth-token")?.value
    if (!token) return null

    // Verify the token
    const decoded = jwt.verify(token, config.jwt.secret) as { userId: string }
    const user = users[decoded.userId]

    if (!user) return null

    // Return user without password
    const { password: _, ...userWithoutPassword } = user
    return userWithoutPassword
  } catch (error) {
    console.error("Error getting current user:", error)
    return null
  }
}

// Clear the session
export async function clearSession(): Promise<void> {
  cookies().delete("auth-token")
}

// Authenticate a user with email and password
export async function authenticateUser(email: string, password: string): Promise<{ user: User; token: string } | null> {
  try {
    // Get user by credentials
    const user = await getUserByCredentials(email, password)
    if (!user) return null

    // Create a session
    const token = await createSession(user)

    return { user, token }
  } catch (error) {
    console.error("Error authenticating user:", error)
    return null
  }
}
